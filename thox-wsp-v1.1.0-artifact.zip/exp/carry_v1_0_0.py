"""Carry the v1.0.0 THOX-measured results (E1-E4, patch-channel tests) into the v1.1.0 evidence file.

The v1.0.0 artifact bundle (exp/results/summary.json and the E1-E4 scripts) was produced on the THOX build VM and was
not available to the v1.1.0 build. Rather than retype numbers, this script:
  1. extracts the machine data embedded in the v1.0.0 demo page (the E1 per-class composed maps and the E3 gain sweep);
  2. records every other carried number together with the exact phrase it appears in, and asserts that each phrase
     occurs in the text of the v1.0.0 PDF (pdftotext -layout output, whitespace-normalised).
A carried number that cannot be found in v1.0.0 fails the build. Usage:

    python -I exp/carry_v1_0_0.py <v1.0.0 pdf text> <v1.0.0 demo html> exp/results/carried_v1_0_0.json
"""
from __future__ import annotations

import json
import re
import sys

CARRIED = {
    "E1": {
        "networks": (30, "We trained 30 multilayer perceptrons (64-48-4)"),
        "reader_acc": ({"R1": 33.3, "R2": 33.3, "R3": 33.3, "R4": 100.0},
                       "R4_effective_per_class Composed map, per-class voting 100.0% 33.3%"),
        "permutation_control_acc": (33.3, "Global marginal of |W1| 33.3% 33.3%"),
        "chance": (33.3, "30 networks, 3 classes, chance 33.3%"),
    },
    "E2": {
        "max_target_error": (2.2e-16, "maximum target error 2.2e-16"),
        "written_catch_standard": (100.0, "catches 100% of balls in the standard regime"),
        "written_catch_hard": (92.1, "92.1% in a hard regime"),
        "random_mean": (4.1, "average 4.1% (best 20.2%)"),
        "random_best": (20.2, "average 4.1% (best 20.2%)"),
        "random_count": (20, "twenty random-weight networks"),
        "oracle_steps": (1200, "1,200 optimisation steps on 4,096 labelled examples"),
        "oracle_examples": (4096, "1,200 optimisation steps on 4,096 labelled examples"),
        "oracle_landing_error": (8.7e-4, "landing error 8.7e-4"),
    },
    "E3": {
        "params": (747, "A 747-parameter policy (2-24-24-3)"),
        "edited_weights": (16, "16 of 747 weights (2.14%)"),
        "edited_share_pct": (2.14, "16 of 747 weights (2.14%)"),
        "success_512": (92.8, "raises success to 92.8% over 512 episodes"),
        "random_edit_success": (0.0, "a random edit of exactly the same size scores 0%"),
        "failed_first_edit_weights": (84, "84 weights changed, success unchanged at 0%"),
    },
    "E4": {
        "params": (70656, "70,656 parameters"),
        "top_composition_score": (0.589, "composition score 0.589 against a 0.05-0.39 spread"),
        "steps": (1400, "after 1,400 training steps"),
        "repeat_loss": (3.19, "3.19 against 3.18 elsewhere"),
        "other_loss": (3.18, "3.19 against 3.18 elsewhere"),
        "attention_range": ([0.048, 0.050], "heads (0.048-0.050)"),
        "max_ablation_delta": (0.022, "most 0.022"),
        "spearman": (0.80, "Spearman 0.80"),
        "interrupted_at": (2000, "interrupted at step 2,000"),
    },
    "patch_channel": {
        "rust_unit_tests": ("3/3 pass", "3/3 pass"),
        "e2e": ("pass", "Pass; applied tensor bit-identical to"),
        "rollback": ("pass", "Pass; active slot returns to A"),
        "tamper": ("rejected", "Correctly rejected: signature verification failed"),
        "wrong_base": ("aborted", "Correctly aborted: base hash mismatch, no switch"),
        "production_patch_issued": ("none", "None. The channel is built and tested; no THOX model has been patched"),
        "toolkit_version": ("thox-wsp v0.1.0", "(thox-wsp v0.1.0)"),
    },
    "context": {
        "catalog_revision": ("2026-11-02.1", "live revision 2026-11-02.1, 94 models"),
        "catalog_models": (94, "live revision 2026-11-02.1, 94 models"),
        "build_host": ("THOX build VM (CPU)", "THOX build VM (CPU) on 2026-11-03"),
    },
}


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def demo_arrays(html: str) -> dict:
    maps = re.search(r"const MAPS = (\{.*?\});\n", html, re.S)
    sens = re.search(r"const SENS = (\{.*?\});\n", html, re.S)
    if not maps or not sens:
        raise ValueError("MAPS or SENS not found in the v1.0.0 demo")
    m = json.loads(maps.group(1))
    s = {float(k): v for k, v in json.loads(sens.group(1)).items()}
    for task in ("col", "row", "diag"):
        grids = m[task]["maps"]
        if len(grids) != 4 or any(len(g) != 8 or any(len(r) != 8 for r in g) for g in grids):
            raise ValueError(f"E1 map {task} is not 4x8x8")
    return {"E1_example_maps": m, "E3_gain_sweep_256": dict(sorted(s.items()))}


def main(pdf_txt: str, demo_html: str, out: str) -> int:
    text = norm(open(pdf_txt, encoding="utf-8").read())
    missing = []
    result = {"source": {"pdf": "Weight-Space-Programming-for-THOX-Edge-Models_v1.0.0.pdf",
                         "demo": "weight-space-programming-demo.html (v1.0.0)",
                         "note": "v1.0.0 bundle not available to the v1.1.0 build; numbers carried with phrase checks"}}
    for group, items in CARRIED.items():
        result[group] = {}
        for k, (val, phrase) in items.items():
            if norm(phrase) not in text:
                missing.append((group, k, phrase))
            result[group][k] = {"value": val, "phrase": phrase}
    result.update(demo_arrays(open(demo_html, encoding="utf-8").read()))
    # consistency checks between the demo data and the PDF
    sweep = result["E3_gain_sweep_256"]
    if round(sweep[1.0] * 100, 1) != 94.1 or round(sweep[0.25] * 100, 1) != 21.9:
        missing.append(("E3", "gain sweep", "demo SENS disagrees with the PDF dose-response"))
    if missing:
        for m in missing:
            print("NOT FOUND in v1.0.0:", m, file=sys.stderr)
        return 1
    with open(out, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=1)
    print(f"carried {sum(len(v) for k, v in CARRIED.items())} values; all phrases found; wrote {out}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(*sys.argv[1:]))
