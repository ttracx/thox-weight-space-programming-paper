# /// script
# requires-python = ">=3.11"
# dependencies = ["numpy", "huggingface_hub"]
# ///
"""analyze_l1: turn the raw L1 generations into the evidence file the v1.1.0 paper is built from.

THOX.ai Research, technical report v1.1.0. Runs as a CPU job on Hugging Face Jobs with the private results dataset
mounted read-only (the raw generations never leave the dataset), or locally against a copy:

    python analyze_l1.py <dataset root containing l1/> <out dir> [--upload]

Writes <out>/l1_summary.json: per-configuration accuracy (mean over samples, standard error over problems), token
cap share, loop share (n-gram window test and the source's end-of-text period test), token statistics, the
decoding-defence results, paired problem-level comparisons with 95% bootstrap intervals (10,000 resamples over
problems, seed 0), a join with the source authors' released per-problem results, and two short loop excerpts. Every
number in the v1.1.0 paper's Section 5 is read from this file.
"""
from __future__ import annotations

import gzip
import json
import os
import sys
import urllib.request

import numpy as np

CONFIGS = {
    # key: (job folder, config folder, thinking, label)
    "base_on": ("J1", "base__think_on", True, "Qwen3.5-0.8B, thinking on (source protocol)"),
    "edit_on": ("J2", "edit__think_on", True, "Released edit, thinking on (source protocol)"),
    "base_off": ("J3a", "base__think_off_nothink35", False, "Qwen3.5-0.8B, thinking off (card setting)"),
    "edit_off": ("J3a", "edit__think_off_nothink35", False, "Released edit, thinking off (card setting)"),
    "base_off_greedy": ("J3a", "base__think_off_greedy", False, "Qwen3.5-0.8B, thinking off, greedy"),
    "edit_off_greedy": ("J3a", "edit__think_off_greedy", False, "Released edit, thinking off, greedy"),
    "thoxedge_greedy": ("J3b", "thoxedge__bare_greedy", False, "ThoxEdge-0.8B, thinking off, greedy, no system prompt"),
    "thoxedge_gated": ("J3b", "thoxedge__gated_greedy", False,
                       "ThoxEdge-0.8B, served configuration (grounding prompt, greedy, 4,096 context)"),
    "thoxedge_off": ("J3b", "thoxedge__bare_nothink35", False, "ThoxEdge-0.8B, thinking off (card setting)"),
    "micro125_greedy": ("J3b", "micro125__greedy", False, "thox-micro-125m-instruct, greedy, 512-token cap"),
}
DEFENCES = {"budget4096": "hard thinking budget 4,096 tokens + forced answer",
            "budget8192": "hard thinking budget 8,192 tokens + forced answer",
            "interrupt": "streaming loop interrupt: rewind to loop onset + forced answer"}
PAIRS = [
    ("base_off", "base_on", "Turning thinking off, no weight change"),
    ("edit_on", "base_on", "The released weight edit, thinking on"),
    ("edit_on", "base_off", "Weight edit (thinking on) against the decoding control"),
    ("edit_off", "base_off", "Weight edit with thinking off"),
    ("base_on+interrupt", "base_on", "Streaming loop interrupt"),
    ("base_on+budget4096", "base_on", "Thinking budget 4,096"),
    ("base_on+budget8192", "base_on", "Thinking budget 8,192"),
    ("edit_on", "base_on+interrupt", "Weight edit against the loop interrupt"),
    ("edit_on+interrupt", "edit_on", "Loop interrupt on top of the edit"),
    ("base_off_greedy", "base_off", "Greedy against card sampling, thinking off"),
    ("edit_off_greedy", "base_off_greedy", "Weight edit, thinking off, greedy"),
    ("thoxedge_greedy", "base_off_greedy", "ThoxEdge fine-tune against its base, greedy"),
    ("thoxedge_gated", "thoxedge_greedy", "ThoxEdge served configuration against bare greedy"),
]
SOURCE_PER_PROBLEM = ("https://raw.githubusercontent.com/RikiyaT/lm_understand-logs/"
                      "4d09ba6d6a7e891dd8063974dfe81b3d78e3494f/exp8_math/eval/{ckpt}/parts/"
                      "math500_s{i}of10/math500_per_problem.json")
RNG_SEED = 0
N_BOOT = 10_000


def read_jsonl_gz(path):
    with gzip.open(path, "rt", encoding="utf-8") as f:
        return [json.loads(line) for line in f]


def per_problem(recs, field="correct"):
    acc = {}
    for r in recs:
        acc.setdefault(r["id"], []).append(float(bool(r[field])))
    return {k: float(np.mean(v)) for k, v in acc.items()}


def mean_se(pp):
    v = np.array(list(pp.values()), dtype=float)
    return float(v.mean()), float(v.std(ddof=1) / np.sqrt(len(v)))


def paired(a, b, rng):
    ids = sorted(set(a) & set(b))
    if len(ids) < 2:
        return {"n_problems": len(ids), "diff": None, "ci95": None, "se": None,
                "problems_better": None, "problems_worse": None}
    x = np.array([a[i] - b[i] for i in ids])
    boots = rng.choice(x, size=(N_BOOT, len(x)), replace=True).mean(axis=1)
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return {"n_problems": len(ids), "diff": float(x.mean()), "ci95": [float(lo), float(hi)],
            "se": float(x.std(ddof=1) / np.sqrt(len(x))),
            "problems_better": int((x > 0).sum()), "problems_worse": int((x < 0).sum())}


def summarise_config(recs, think):
    pp = per_problem(recs)
    acc, se = mean_se(pp)
    toks = np.array([r["n_tokens"] for r in recs])
    loops = [r for r in recs if r["loop"]["looping"]]
    onset = [r["loop"]["onset_word"] for r in loops]
    out = {"n_gens": len(recs), "n_problems": len(pp), "samples_per_problem": len(recs) // max(len(pp), 1),
           "acc": acc, "acc_se": se, "acc_strict": mean_se(per_problem(recs, "correct_strict"))[0],
           "cap_share": float(np.mean([r["cap"] for r in recs])),
           "loop_share": len(loops) / len(recs),
           "verbatim_end_share": float(np.mean([r["verbatim_loop_end"] for r in recs])),
           "tokens_total": int(toks.sum()), "tokens_mean": float(toks.mean()), "tokens_median": float(np.median(toks)),
           "tokens_p90": float(np.percentile(toks, 90)),
           "tokens_per_correct": float(toks.sum() / max(sum(r["correct"] for r in recs), 1)),
           "acc_when_looping": float(np.mean([r["correct"] for r in loops])) if loops else None,
           "acc_when_not_looping": float(np.mean([r["correct"] for r in recs if not r["loop"]["looping"]]))
           if len(loops) < len(recs) else None,
           "loop_onset_words_median": float(np.median(onset)) if onset else None,
           "loop_and_cap_share": float(np.mean([r["cap"] and r["loop"]["looping"] for r in recs])),
           "no_answer_share": float(np.mean([r["pred"] is None for r in recs]))}
    if think:
        out["think_closed_share"] = float(np.mean([r["think_closed"] for r in recs]))
        out["loop_in_reasoning_share"] = float(np.mean([bool(r["loop_reasoning"] and r["loop_reasoning"]["looping"])
                                                        for r in recs]))
    return out, pp


def summarise_defence(drecs, base_recs):
    pp = per_problem(drecs)
    acc, se = mean_se(pp)
    toks = np.array([d["tokens"] for d in drecs])
    return {"acc": acc, "acc_se": se, "forced": int(sum(d["mode"] == "forced" for d in drecs)),
            "cut_answer": int(sum(d["mode"] == "cut_answer" for d in drecs)),
            "natural": int(sum(d["mode"] == "natural" for d in drecs)),
            "tokens_total": int(toks.sum()), "tokens_mean": float(toks.mean()),
            "tokens_per_correct": float(toks.sum() / max(sum(d["correct"] for d in drecs), 1)),
            "rescued": int(sum(d["correct"] and not d["base_correct"] for d in drecs)),
            "lost": int(sum(d["base_correct"] and not d["correct"] for d in drecs)),
            "answer_cap_share_forced": float(np.mean([d["answer_cap"] for d in drecs if d["mode"] == "forced"]))
            if any(d["mode"] == "forced" for d in drecs) else None,
            "answer_loop_share": float(np.mean([d["answer_loop"] for d in drecs]))}, pp


def fetch_source(ckpt):
    rows = []
    for i in range(10):
        url = SOURCE_PER_PROBLEM.format(ckpt=ckpt, i=i)
        with urllib.request.urlopen(url, timeout=60) as r:
            rows += json.loads(r.read())
    return {r["id"]: float(np.mean(r["correct"])) for r in rows}


def excerpt(recs, rng, n=2, width=700):
    loops = [r for r in recs if r["loop"]["looping"] and r["loop"]["onset_char"] and r["loop"]["onset_char"] > width]
    if not loops:
        return []
    picks = rng.choice(len(loops), size=min(n, len(loops)), replace=False)
    out = []
    for k in sorted(int(p) for p in picks):
        r = loops[k]
        c = r["loop"]["onset_char"]
        out.append({"id": r["id"], "onset_word": r["loop"]["onset_word"], "n_words": r["loop"]["n_words"],
                    "n_tokens": r["n_tokens"], "before_onset": r["text"][c - width:c],
                    "after_onset": r["text"][c:c + width]})
    return out


def main(root, out_dir, upload=False):
    rng = np.random.default_rng(RNG_SEED)
    res = {"configs": {}, "defences": {}, "pairs": [], "missing": [], "excerpts": {}}
    pps = {}
    raw = {}
    for key, (job, folder, think, label) in CONFIGS.items():
        d = os.path.join(root, "l1", job, folder)
        g = os.path.join(d, "gens.jsonl.gz")
        if not os.path.exists(g):
            res["missing"].append(key)
            continue
        recs = read_jsonl_gz(g)
        meta = json.load(open(os.path.join(d, "summary.json"))) if os.path.exists(os.path.join(d, "summary.json")) else {}
        s, pp = summarise_config(recs, think)
        s.update({"label": label, "model": meta.get("model"), "revision": meta.get("revision"),
                  "sampling": meta.get("sampling"), "gen_seconds": meta.get("gen_seconds"),
                  "tok_per_s": meta.get("tok_per_s")})
        res["configs"][key] = s
        pps[key] = pp
        raw[key] = recs
        for dname in DEFENCES:
            p = os.path.join(d, f"defence_{dname}.jsonl.gz")
            if os.path.exists(p):
                ds, dpp = summarise_defence(read_jsonl_gz(p), recs)
                ds["label"] = DEFENCES[dname]
                res["defences"][f"{key}+{dname}"] = ds
                pps[f"{key}+{dname}"] = dpp
    for a, b, label in PAIRS:
        if a in pps and b in pps:
            res["pairs"].append({"a": a, "b": b, "label": label, **paired(pps[a], pps[b], rng)})
        else:
            res["missing"].append(f"pair {a} vs {b}")
    # the source authors' released per-problem results (4 samples, thinking on)
    try:
        src_base, src_edit = fetch_source("unedited"), fetch_source("p50c")
        res["source"] = {"base": dict(zip(("acc", "acc_se"), mean_se(src_base))),
                         "edit": dict(zip(("acc", "acc_se"), mean_se(src_edit))),
                         "pair_edit_vs_base": paired(src_edit, src_base, rng)}
        pps["src_base"], pps["src_edit"] = src_base, src_edit
        if "base_off" in pps:
            res["source"]["pair_src_edit_vs_thox_base_off"] = paired(src_edit, pps["base_off"], rng)
            ids = sorted(set(src_edit) & set(pps["base_off"]))
            e = np.array([src_edit[i] for i in ids])
            o = np.array([pps["base_off"][i] for i in ids])
            res["source"]["corr_src_edit_thox_base_off"] = float(np.corrcoef(e, o)[0, 1])
            solved_by_edit = e >= 0.5
            res["source"]["edit_majority_solved"] = int(solved_by_edit.sum())
            res["source"]["of_those_base_off_majority_solved"] = int((solved_by_edit & (o >= 0.5)).sum())
        if "base_on" in pps:
            res["source"]["pair_thox_base_on_vs_src_base"] = paired(pps["base_on"], src_base, rng)
        if "edit_on" in pps:
            res["source"]["pair_thox_edit_on_vs_src_edit"] = paired(pps["edit_on"], src_edit, rng)
    except Exception as e:  # noqa: BLE001
        res["source_error"] = repr(e)
    for key in ("base_on", "base_off_greedy", "thoxedge_greedy"):
        if key in raw:
            res["excerpts"][key] = excerpt(raw[key], rng)
    res["method"] = {"n_boot": N_BOOT, "seed": RNG_SEED, "se": "standard error of the per-problem mean accuracy",
                     "loop_test": "n-gram window (n=8, window=300, frac=0.9), causal; verbatim end period test"}
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "l1_summary.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=1, ensure_ascii=True)
    print(f"wrote {path}; configs {sorted(res['configs'])}; missing {res['missing']}", flush=True)
    if upload:
        from huggingface_hub import HfApi
        HfApi(token=os.environ["HF_TOKEN"]).upload_file(path_or_fileobj=path, path_in_repo="results/l1_summary.json",
                                                        repo_id="Thox-ai/thox-wsp-evals", repo_type="dataset",
                                                        commit_message="l1 analysis summary")
        print("uploaded results/l1_summary.json", flush=True)
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1], sys.argv[2], upload="--upload" in sys.argv[3:]))
