"""E0-R and P1: independent re-verification of the released Experiment 8 edit, and measurement of patch forms.

THOX.ai Research, technical report v1.1.0. Run from any directory:

    python -I exp/e0r_patch_forms.py <path to RikiyaT/lm_understand-logs exp8_math/runs/p50c/edit> exp/results

What it does, with no model download beyond the four tensors involved (HTTP range reads of the safetensors files):

E0-R  1. Reads the two down_proj tensors of Qwen/Qwen3.5-0.8B at the pinned revision and of the released edited
         checkpoint at its pinned revision, and checks every SHA-256 against the authors' edit manifest.
      2. Rebuilds the edited tensors from the authors' sparse edit (edit.npz) and checks they are bit-identical to the
         released checkpoint.
      3. Measures each diff's rank structure (singular values in float64) and relative Frobenius change.

P1    Measures what it takes to ship this edit as a THOX patch:
      a. sparse form: (index, value) pairs, raw and compressed;
      b. factor form W' = W - alpha * outer(u, mask * (u^T W)) with u estimated from the released diff, in float32
         and in bfloat16, applied in float32 and float64 and rounded to bfloat16 with round-to-nearest-even; counts how
         many of the 7.3M entries per tensor come out bit-identical to the released tensor;
      c. factor form plus a sparse residual that makes the result bit-exact, and the size of that residual.

Everything is written to <out>/e0r_patch_forms.json; no number is typed by hand anywhere downstream.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import ssl
import struct
import sys
import time
import urllib.request
import zlib

import numpy as np

BASE = ("Qwen/Qwen3.5-0.8B", "2fc06364715b967f1860aea9cf38778875588b17",
        "model.safetensors-00001-of-00001.safetensors")
EDIT = ("RikiyaT/Qwen3.5-0.8B-weight-space-programming", "d1671a178705bcab7644806d23c535517f35723b",
        "model.safetensors-00001-of-00001.safetensors")
NAMES = ["model.language_model.layers.15.mlp.down_proj.weight", "model.language_model.layers.19.mlp.down_proj.weight"]


def _ctx() -> ssl.SSLContext:
    ca = os.environ.get("SSL_CERT_FILE") or os.environ.get("REQUESTS_CA_BUNDLE")
    return ssl.create_default_context(cafile=ca) if ca and os.path.exists(ca) else ssl.create_default_context()


def _range(url: str, start: int, end: int, tries: int = 4) -> bytes:
    """Inclusive byte range [start, end] of url, with retries."""
    last = None
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers={"Range": f"bytes={start}-{end}",
                                                       "User-Agent": "thox-wsp-e0r/1.1"})
            with urllib.request.urlopen(req, context=_ctx(), timeout=120) as r:
                data = r.read()
            if len(data) != end - start + 1:
                raise IOError(f"short read {len(data)} of {end - start + 1}")
            return data
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"range read failed for {url}: {last!r}")


def read_tensors(repo: str, rev: str, fname: str, names: list[str]) -> dict[str, np.ndarray]:
    url = f"https://huggingface.co/{repo}/resolve/{rev}/{fname}"
    n = struct.unpack("<Q", _range(url, 0, 7))[0]
    if not (0 < n < 50_000_000):
        raise ValueError(f"implausible safetensors header length {n}")
    header = json.loads(_range(url, 8, 8 + n - 1))
    out = {}
    for name in names:
        meta = header[name]
        if meta["dtype"] != "BF16":
            raise ValueError(f"{name}: expected BF16, got {meta['dtype']}")
        a, b = meta["data_offsets"]
        raw = _range(url, 8 + n + a, 8 + n + b - 1)
        out[name] = np.frombuffer(raw, dtype="<u2").reshape(meta["shape"]).copy()
    return out


def bf16_to_f32(bits: np.ndarray) -> np.ndarray:
    return (bits.astype(np.uint32) << 16).view(np.float32)


def f32_to_bf16_rne(x: np.ndarray) -> np.ndarray:
    """float32 -> bfloat16 bits, round to nearest even (NaN-safe enough for finite weights)."""
    u = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    if not np.all(np.isfinite(x)):
        raise ValueError("non-finite values")
    rounding = ((u >> 16) & 1) + np.uint32(0x7FFF)
    return ((u + rounding) >> 16).astype(np.uint16)


def sha(bits: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(bits).tobytes()).hexdigest()


def main(edit_dir: str, out_dir: str) -> int:
    man = json.load(open(os.path.join(edit_dir, "manifest.json"), encoding="utf-8"))
    z = np.load(os.path.join(edit_dir, "edit.npz"), allow_pickle=False)
    t0 = time.time()
    base = read_tensors(*BASE, NAMES)
    edit = read_tensors(*EDIT, NAMES)
    res = {"base": {"repo": BASE[0], "revision": BASE[1]}, "edit": {"repo": EDIT[0], "revision": EDIT[1]},
           "source_manifest": "RikiyaT/lm_understand-logs@4d09ba6d exp8_math/runs/p50c/edit/manifest.json",
           "download_seconds": round(time.time() - t0, 1), "tensors": []}
    npz_bytes = os.path.getsize(os.path.join(edit_dir, "edit.npz"))
    all_ok = True
    for i, t in enumerate(man["tensors"]):
        name = t["name"]
        W, E = base[name], edit[name]
        r = {"name": name, "shape": list(W.shape)}
        r["base_sha256"] = sha(W)
        r["edited_sha256"] = sha(E)
        r["base_hash_matches_manifest"] = r["base_sha256"] == t["base_sha256"]
        r["edited_hash_matches_manifest"] = r["edited_sha256"] == t["edited_sha256"]
        # rebuild from the authors' sparse edit
        if t["form"] != "sparse":
            raise ValueError(f"unexpected form {t['form']}")
        idx, val = z[f"t{i}_idx"], z[f"t{i}_val"]
        rb = W.copy().reshape(-1)
        rb[idx] = val.astype(np.uint16) if val.dtype != np.uint16 else val
        rb = rb.reshape(W.shape)
        r["rebuild_bit_identical"] = bool(np.array_equal(rb, E))
        r["sparse_entries_in_release"] = int(idx.size)
        changed = W != E
        r["changed_entries"] = int(changed.sum())
        r["changed_columns"] = int(changed.any(axis=0).sum())
        r["changed_rows"] = int(changed.any(axis=1).sum())
        Wf = bf16_to_f32(W).astype(np.float64)
        Ef = bf16_to_f32(E).astype(np.float64)
        D = Ef - Wf
        r["relative_frobenius_change"] = float(np.linalg.norm(D) / np.linalg.norm(Wf))
        cols = np.where(changed.any(axis=0))[0]
        s = np.linalg.svd(D[:, cols], compute_uv=False)
        r["sigma1_over_sigma2"] = float(s[0] / s[1])
        r["energy_rank1"] = float(s[0] ** 2 / np.sum(s ** 2))
        # ---- factor form estimated from the diff
        Uu, S, Vt = np.linalg.svd(D[:, cols], full_matrices=False)
        u = Uu[:, 0]
        Wc = Wf[:, cols]
        proj = u @ Wc                                   # u^T W restricted to the edited columns
        # D[:, cols] ~= -alpha * outer(u, proj): least squares for alpha
        alpha = float(-np.sum(D[:, cols] * np.outer(u, proj)) / np.sum(np.outer(u, proj) ** 2))
        r["alpha_estimated"] = alpha
        r["alpha_sign_note"] = "W' = W - alpha * outer(u, u^T W) on the edited columns"
        variants = {}
        for uname, uvec in (("u_f64", u), ("u_f32", u.astype(np.float32).astype(np.float64)),
                            ("u_bf16", bf16_to_f32(f32_to_bf16_rne(u.astype(np.float32))).astype(np.float64))):
            for prec in ("f64", "f32"):
                Wn = Wf.copy()
                if prec == "f64":
                    Wn[:, cols] = Wc - alpha * np.outer(uvec, uvec @ Wc)
                    bits = f32_to_bf16_rne(Wn.astype(np.float32))   # one rounding step via float32
                else:
                    uv32 = uvec.astype(np.float32)
                    Wc32 = Wc.astype(np.float32)
                    Wn32 = Wf.astype(np.float32)
                    Wn32[:, cols] = Wc32 - np.float32(alpha) * np.outer(uv32, uv32 @ Wc32)
                    bits = f32_to_bf16_rne(Wn32)
                mism = bits != E
                abs_err = np.abs(bf16_to_f32(bits).astype(np.float64) - Ef)
                variants[f"{uname}_apply_{prec}"] = {
                    "mismatched_entries": int(mism.sum()),
                    "mismatch_share_of_changed": float(mism.sum() / max(int(changed.sum()), 1)),
                    "bit_exact": bool(not mism.any()),
                    "max_abs_error": float(abs_err.max()),
                    "max_abs_error_over_max_abs_diff": float(abs_err.max() / np.abs(D).max())}
        r["factor_variants"] = variants
        best = min(variants, key=lambda k: variants[k]["mismatched_entries"])
        r["factor_best_variant"] = best
        resid = variants[best]["mismatched_entries"]
        n_rows = W.shape[0]
        r["sizes_bytes"] = {
            "full_tensor_bf16": int(W.size * 2),
            "sparse_raw_idx4_val2": int(changed.sum() * 6),
            "factor_u_f32_cols_i16_alpha_f64": int(n_rows * 4 + len(cols) * 2 + 8),
            "factor_u_bf16_cols_i16_alpha_f64": int(n_rows * 2 + len(cols) * 2 + 8),
            "factor_plus_residual_raw": int(n_rows * 4 + len(cols) * 2 + 8 + resid * 6),
            "factor_f32_wire_hex": int(n_rows * 4 * 2),
        }
        # compressed sparse form (what a release would actually ship)
        sp = io.BytesIO()
        np.savez_compressed(sp, idx=np.where(changed.reshape(-1))[0].astype(np.uint32),
                            val=E.reshape(-1)[changed.reshape(-1)].astype(np.uint16))
        r["sizes_bytes"]["sparse_npz_compressed"] = len(sp.getvalue())
        r["sizes_bytes"]["sparse_zlib_raw"] = len(zlib.compress(
            np.where(changed.reshape(-1))[0].astype(np.uint32).tobytes()
            + E.reshape(-1)[changed.reshape(-1)].astype(np.uint16).tobytes(), 9))
        all_ok &= r["base_hash_matches_manifest"] and r["edited_hash_matches_manifest"] and r["rebuild_bit_identical"]
        res["tensors"].append(r)
        print(name, json.dumps({k: r[k] for k in ("changed_entries", "rebuild_bit_identical",
                                                  "sigma1_over_sigma2", "relative_frobenius_change",
                                                  "factor_best_variant")}), flush=True)
    res["release_edit_npz_bytes"] = npz_bytes
    res["changed_entries_total"] = sum(t["changed_entries"] for t in res["tensors"])
    res["e0r_pass"] = bool(all_ok and res["changed_entries_total"] == man["changed_entries_total"])
    res["host"] = "Claude cloud workspace (Linux, 2 vCPU, NumPy " + np.__version__ + ")"
    res["date"] = time.strftime("%Y-%m-%d")
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "e0r_patch_forms.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, indent=1)
    print("E0-R pass:", res["e0r_pass"])
    return 0 if res["e0r_pass"] else 1


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1], sys.argv[2]))
