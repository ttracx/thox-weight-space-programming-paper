#__WSP_LOOP_INLINE__
"""l1_eval: THOX loop baseline and decoding-control evaluation (technical report v1.1.0, Section 5).

Runs on Hugging Face Jobs (GPU) with vLLM. Measures, on MATH-500, how often Qwen3.5-0.8B-class models loop and
what that costs in accuracy, under the source post's thinking-on protocol, under the model card's thinking-off
protocol, under THOX's greedy serving configuration, and under two decoding-only defences applied to the same
generations (a hard thinking budget with a forced answer, and a streaming loop interrupt that rewinds to the
loop onset and forces an answer). Every generation, its metrics and its full text are written to JSONL and
uploaded to a private dataset repository; nothing is summarised by hand.

Usage inside the job:
    python l1_eval.py job <J1|J2|J3a|J3b>     # run a job's model groups in subprocesses, upload after each
    python l1_eval.py run '<json spec>'        # one model, several configurations (called by `job`)

Grading follows the source exactly (RikiyaT/lm_understand-logs exp8_math/code/mathqa.py, MIT): the user turn is
the problem plus "Please reason step by step, and put your final answer within \\boxed{}."; the answer is the last
\\boxed{} after the last </think> (or of the whole text when thinking never closed); math-verify 0.9.0 decides
equivalence with verify(parse('\\boxed{gold}'), parse('\\boxed{pred}')). A stricter variant that requires a
closed thinking block is recorded next to it.
"""
import functools
import gzip
import json
import os
import subprocess
import sys
import threading
import time
import traceback

DATASET_REPO = os.environ.get("WSP_DATASET_REPO", "Thox-ai/thox-wsp-evals")
MATH500 = ("HuggingFaceH4/MATH-500", "6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be")
INSTRUCTION = "Please reason step by step, and put your final answer within \\boxed{}."
# Qwen3 Technical Report (arXiv:2505.09388), thinking-budget stop instruction, verbatim.
FORCE_TEXT = ("\n\nConsidering the limited time by the user, I have to give the solution based on the thinking "
              "directly now.\n</think>.\n\n")

PROFILES = {
    # source post, Experiment 8 (evaluate.py SAMPLING_THINK35): Qwen3.5 card thinking-mode benchmark setting
    "think35": {"temperature": 0.6, "top_p": 0.95, "top_k": 20, "presence_penalty": 1.5, "max_tokens": 32768},
    # source evaluate.py SAMPLING_NOTHINK35: the card's non-thinking benchmark setting
    "nothink35": {"temperature": 0.7, "top_p": 0.8, "top_k": 20, "presence_penalty": 1.5, "max_tokens": 8192},
    # THOX serving configuration of ThoxEdge-0.8B (Modelfile: temperature 0)
    "greedy": {"temperature": 0.0, "max_tokens": 8192},
}

MODELS = {
    "base": ("Qwen/Qwen3.5-0.8B", "2fc06364715b967f1860aea9cf38778875588b17"),
    "edit": ("RikiyaT/Qwen3.5-0.8B-weight-space-programming", "d1671a178705bcab7644806d23c535517f35723b"),
    "thoxedge": ("Thox-ai/ThoxEdge-0.8B", "235cce41bb3f1ea61719c37033d7eb8e309812e9"),
    "micro125": ("Thox-ai/thox-micro-125m-instruct", "10aecf3cee72036c489cf891f51a93c6a483ee0f"),
}

# One entry per model group: (model key, max_model_len, [config dicts]).
JOBS = {
    "J1": [("base", 40960, [{"name": "think_on", "think": True, "profile": "think35", "n": 1, "defences": True}])],
    "J2": [("edit", 40960, [{"name": "think_on", "think": True, "profile": "think35", "n": 1, "defences": True}])],
    "J3a": [
        ("base", 10240, [{"name": "think_off_nothink35", "think": False, "profile": "nothink35", "n": 4},
                         {"name": "think_off_greedy", "think": False, "profile": "greedy", "n": 1}]),
        ("edit", 10240, [{"name": "think_off_nothink35", "think": False, "profile": "nothink35", "n": 4},
                         {"name": "think_off_greedy", "think": False, "profile": "greedy", "n": 1}]),
    ],
    "J3b": [
        ("thoxedge", 10240, [{"name": "bare_greedy", "think": False, "profile": "greedy", "n": 1},
                             {"name": "gated_greedy", "think": False, "profile": "greedy", "n": 1,
                              "system": "thoxedge_modelfile", "max_tokens": 2048},
                             {"name": "bare_nothink35", "think": False, "profile": "nothink35", "n": 4}]),
        ("micro125", 1024, [{"name": "greedy", "think": False, "profile": "greedy", "n": 1, "max_tokens": 512}]),
    ],
}


# ------------------------------------------------------------------ grading (source protocol, vendored)
def answer_text(text):
    if "</think>" in text:
        text = text.split("</think>")[-1].strip()
    return text


def _box_at(text, idx):
    key = "\\boxed" if text.startswith("\\boxed", idx) else "\\fbox"
    rest = text[idx + len(key):]
    r = rest.lstrip()
    if r.startswith("{"):
        depth = 0
        for k, ch in enumerate(r):
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    out = r[1:k].strip()
                    return out or None
        return None
    if key == "\\boxed" and rest.startswith(" "):
        out = rest.strip().split("$")[0].split("\n")[0].strip()
        return out or None
    return None


def last_boxed(text):
    idx = text.rfind("\\boxed")
    if idx < 0:
        idx = text.rfind("\\fbox")
        if idx < 0:
            return None
    return _box_at(text, idx)


def extract(text):
    return last_boxed(answer_text(text))


_MV = []


def _mv():
    if not _MV:
        import math_verify  # noqa: PLC0415
        _MV.append(math_verify)
    return _MV[0]


@functools.lru_cache(maxsize=1 << 16)
def _parsed(s):
    to = 5 if threading.current_thread() is threading.main_thread() else None
    return _mv().parse("\\boxed{" + s + "}", parsing_timeout=to)


def is_correct(pred, gold):
    if pred is None or gold is None:
        return False
    try:
        g, p = _parsed(gold), _parsed(pred)
    except Exception:  # noqa: BLE001
        return False
    if not g or not p:
        return False
    to = 5 if threading.current_thread() is threading.main_thread() else None
    try:
        return bool(_mv().verify(g, p, timeout_seconds=to))
    except Exception:  # noqa: BLE001
        return False


# ------------------------------------------------------------------ helpers
def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


def load_math500():
    from datasets import load_dataset
    ds = load_dataset(MATH500[0], split="test", revision=MATH500[1])
    rows = [{"id": r["unique_id"], "problem": r["problem"], "answer": r["answer"],
             "subject": r.get("subject"), "level": r.get("level")} for r in ds]
    if len(rows) != 500:
        raise RuntimeError(f"MATH-500 has {len(rows)} rows, expected 500")
    return rows


def fetch_system_prompt(name):
    if name != "thoxedge_modelfile":
        raise ValueError(f"unknown system prompt {name}")
    from huggingface_hub import hf_hub_download
    repo, rev = MODELS["thoxedge"]
    path = hf_hub_download(repo, "Modelfile", revision=rev)
    txt = open(path, encoding="utf-8").read()
    start = txt.index('SYSTEM """') + len('SYSTEM """')
    end = txt.index('"""', start)
    return txt[start:end]


def build_prompt(tok, problem, think, system):
    msgs = ([{"role": "system", "content": system}] if system else []) + \
           [{"role": "user", "content": problem + "\n" + INSTRUCTION}]
    try:
        return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True, enable_thinking=think)
    except TypeError:
        return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)


def token_index_for_char(tok, ids, char_pos):
    """smallest t with len(decode(ids[:t])) >= char_pos (binary search; decode is monotone in t)."""
    lo, hi = 0, len(ids)
    while lo < hi:
        mid = (lo + hi) // 2
        if len(tok.decode(ids[:mid], skip_special_tokens=False)) >= char_pos:
            hi = mid
        else:
            lo = mid + 1
    return lo


def grade_record(text, gold, think):
    pred = extract(text)
    ok = is_correct(pred, gold)
    closed = "</think>" in text
    return {"pred": None if pred is None else pred[:200], "correct": bool(ok),
            "correct_strict": bool(ok and (closed or not think)), "think_closed": closed}


# ------------------------------------------------------------------ one model group
def run_group(spec):
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams
    from vllm.inputs import TokensPrompt

    key, max_len, configs, out_root = spec["model"], spec["max_model_len"], spec["configs"], spec["out"]
    repo, rev = MODELS[key]
    rows = load_math500()
    tok = AutoTokenizer.from_pretrained(repo, revision=rev)
    t0 = time.time()
    llm = LLM(model=repo, revision=rev, tokenizer_revision=rev, dtype="bfloat16", max_model_len=max_len,
              gpu_memory_utilization=0.90, seed=0)
    load_s = round(time.time() - t0, 1)
    log(f"loaded {repo}@{rev[:8]} in {load_s}s")
    close_ids = tok.encode("</think>", add_special_tokens=False)
    close_id = close_ids[0] if len(close_ids) == 1 else None
    force_ids = tok.encode(FORCE_TEXT, add_special_tokens=False)
    status = {}
    for cfg in configs:
        name = cfg["name"]
        out = os.path.join(out_root, f"{key}__{name}")
        os.makedirs(out, exist_ok=True)
        try:
            prof = dict(PROFILES[cfg["profile"]])
            if "max_tokens" in cfg:
                prof["max_tokens"] = cfg["max_tokens"]
            system = fetch_system_prompt(cfg["system"]) if cfg.get("system") else None
            prompts = [build_prompt(tok, r["problem"], cfg["think"], system) for r in rows]
            # per-prompt cap so prompt + generation never exceeds the model's context (binds only for the
            # 1,024-token thox-micro-125m; recorded per generation as max_tokens_eff)
            caps = []
            for p in prompts:
                room = max_len - len(tok.encode(p, add_special_tokens=False)) - 8
                if room < 16:
                    raise RuntimeError(f"prompt leaves {room} tokens of room in a {max_len}-token context")
                caps.append(min(prof["max_tokens"], room))
            sps = [SamplingParams(n=cfg["n"], seed=0, skip_special_tokens=False,
                                  **{**prof, "max_tokens": c}) for c in caps]
            t1 = time.time()
            outs = llm.generate(prompts, sps)
            gen_s = time.time() - t1
            bad = sum(1 for o in outs for x in o.outputs if x.finish_reason not in ("stop", "length"))
            if bad:
                raise RuntimeError(f"{bad} generations neither stopped nor reached max_tokens")
            recs, tot_tokens = [], 0
            for r, o, cap_i in zip(rows, outs, caps):
                for si, x in enumerate(o.outputs):
                    ids = list(x.token_ids)
                    tot_tokens += len(ids)
                    text = x.text
                    reasoning, answer = split_reasoning(text) if cfg["think"] else ("", text)
                    scan_full = loop_scan(text)
                    rec = {"id": r["id"], "sample": si, "gold": r["answer"], "subject": r["subject"],
                           "level": r["level"], "n_tokens": len(ids), "finish": x.finish_reason,
                           "max_tokens_eff": cap_i,
                           "cap": x.finish_reason == "length",
                           "close_tok": (ids.index(close_id) if close_id is not None and close_id in ids else None),
                           "loop": scan_full, "loop_reasoning": loop_scan(reasoning) if cfg["think"] else None,
                           "verbatim_loop_end": verbatim_loop_end(text),
                           **grade_record(text, r["answer"], cfg["think"]), "text": text,
                           "prompt_len": len(o.prompt_token_ids)}
                    recs.append(rec)
            summary = {"model": repo, "revision": rev, "config": cfg, "sampling": prof, "n_problems": len(rows),
                       "n_gens": len(recs), "gen_seconds": round(gen_s, 1), "gen_tokens": tot_tokens,
                       "tok_per_s": round(tot_tokens / max(gen_s, 1e-9), 1), "load_seconds": load_s,
                       "acc": sum(x["correct"] for x in recs) / len(recs),
                       "acc_strict": sum(x["correct_strict"] for x in recs) / len(recs),
                       "cap_share": sum(x["cap"] for x in recs) / len(recs),
                       "loop_share": sum(bool(x["loop"]["looping"]) for x in recs) / len(recs),
                       "system_prompt": bool(system)}
            log(name, json.dumps({k: summary[k] for k in ("acc", "cap_share", "loop_share", "gen_tokens",
                                                          "gen_seconds")}))
            with gzip.open(os.path.join(out, "gens.jsonl.gz"), "wt", encoding="utf-8") as f:
                for rec in recs:
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            if cfg.get("defences"):
                summary["defences"] = run_defences(llm, tok, SamplingParams, TokensPrompt, prof, outs, rows,
                                                   recs, close_id, force_ids, out)
            json.dump(summary, open(os.path.join(out, "summary.json"), "w"), indent=1)
            status[name] = "ok"
        except Exception as e:  # noqa: BLE001
            status[name] = f"error: {e!r}"
            json.dump({"error": repr(e), "trace": traceback.format_exc()}, open(os.path.join(out, "error.json"), "w"),
                      indent=1)
            log(f"{name} FAILED: {e!r}")
    return status


def run_defences(llm, tok, SamplingParams, TokensPrompt, prof, outs, rows, recs, close_id, force_ids, out):
    """Decoding-only defences on the SAME generations (n=1). Causality makes every prefix identical to what the
    defended stream would have produced with the same seed, so only the forced answer is generated anew."""
    ans_sp = SamplingParams(n=1, seed=1, skip_special_tokens=False, max_tokens=4096,
                            **{k: v for k, v in prof.items() if k != "max_tokens"})
    plans = {"budget4096": [], "budget8192": [], "interrupt": []}
    for i, (r, o) in enumerate(zip(rows, outs)):
        x = o.outputs[0]
        ids = list(x.token_ids)
        pids = list(o.prompt_token_ids)
        rec = recs[i]
        ci = rec["close_tok"]
        for b in (4096, 8192):
            key = f"budget{b}"
            if ci is not None and ci < b:
                plans[key].append({"i": i, "mode": "natural", "prefix_tokens": len(ids)})
            else:
                plans[key].append({"i": i, "mode": "forced", "prompt": pids + ids[:b] + force_ids,
                                   "prefix_text": tok.decode(ids[:b], skip_special_tokens=False),
                                   "prefix_tokens": b})
        scan = rec["loop"]
        if not scan["looping"]:
            plans["interrupt"].append({"i": i, "mode": "natural", "prefix_tokens": len(ids)})
        else:
            text = x.text
            reasoning_end = text.find("</think>")
            onset = scan["onset_char"]
            if reasoning_end < 0 or onset < reasoning_end:
                t = token_index_for_char(tok, ids, onset)
                plans["interrupt"].append({"i": i, "mode": "forced", "prompt": pids + ids[:t] + force_ids,
                                           "prefix_text": tok.decode(ids[:t], skip_special_tokens=False),
                                           "prefix_tokens": t})
            else:
                t = token_index_for_char(tok, ids, onset)
                plans["interrupt"].append({"i": i, "mode": "cut_answer", "text": text[:onset],
                                           "prefix_tokens": t})
    res = {}
    for key, plan in plans.items():
        forced = [p for p in plan if p["mode"] == "forced"]
        t1 = time.time()
        gens = llm.generate([TokensPrompt(prompt_token_ids=p["prompt"]) for p in forced], ans_sp) if forced else []
        gs = time.time() - t1
        gi = 0
        drecs = []
        for p in plan:
            r = rows[p["i"]]
            base = recs[p["i"]]
            if p["mode"] == "natural":
                text, ans_tokens, cap = base["text"], 0, base["cap"]
                tokens = base["n_tokens"]
            elif p["mode"] == "cut_answer":
                text, ans_tokens, cap = p["text"], 0, False
                tokens = p["prefix_tokens"]
            else:
                g = gens[gi].outputs[0]
                gi += 1
                text = p["prefix_text"] + FORCE_TEXT + g.text
                ans_tokens = len(g.token_ids)
                tokens = p["prefix_tokens"] + len(force_ids) + ans_tokens
                cap = g.finish_reason == "length"
            gr = grade_record(text, r["answer"], True)
            drecs.append({"id": r["id"], "mode": p["mode"], "tokens": tokens, "answer_tokens": ans_tokens,
                          "answer_cap": cap, "correct": gr["correct"], "pred": gr["pred"],
                          "base_correct": base["correct"], "answer_loop": loop_scan(answer_text(text))["looping"]})
        with gzip.open(os.path.join(out, f"defence_{key}.jsonl.gz"), "wt", encoding="utf-8") as f:
            for d in drecs:
                f.write(json.dumps(d, ensure_ascii=False) + "\n")
        res[key] = {"acc": sum(d["correct"] for d in drecs) / len(drecs),
                    "forced": sum(d["mode"] == "forced" for d in drecs),
                    "cut_answer": sum(d["mode"] == "cut_answer" for d in drecs),
                    "tokens": sum(d["tokens"] for d in drecs), "gen_seconds": round(gs, 1)}
        log(key, json.dumps(res[key]))
    return res


# ------------------------------------------------------------------ job driver
def upload(folder, path_in_repo):
    from huggingface_hub import HfApi
    tok = os.environ.get("HF_TOKEN")
    if not tok:
        log("HF_TOKEN missing: results stay local and will be lost when the job ends")
        return False
    for attempt in range(4):
        try:
            HfApi(token=tok).upload_folder(repo_id=DATASET_REPO, repo_type="dataset", folder_path=folder,
                                           path_in_repo=path_in_repo,
                                           commit_message=f"l1_eval results: {path_in_repo}")
            log(f"uploaded {folder} -> {DATASET_REPO}/{path_in_repo}")
            return True
        except Exception as e:  # noqa: BLE001
            log(f"upload attempt {attempt + 1} failed: {e!r}")
            time.sleep(15 * (attempt + 1))
    return False


def job(name):
    if name not in JOBS:
        raise SystemExit(f"unknown job {name}; choose from {sorted(JOBS)}")
    import platform
    env = {"python": platform.python_version(), "job": name}
    try:
        import vllm, transformers, math_verify  # noqa: E401,F401
        env.update(vllm=vllm.__version__, transformers=transformers.__version__)
        env["math_verify"] = getattr(math_verify, "__version__", "0.9.0 (pinned)")
        env["gpu"] = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version",
                                     "--format=csv,noheader"], capture_output=True, text=True).stdout.strip()
    except Exception as e:  # noqa: BLE001
        env["env_error"] = repr(e)
    root = f"/tmp/l1/{name}"
    os.makedirs(root, exist_ok=True)
    json.dump(env, open(os.path.join(root, f"env_{name}.json"), "w"), indent=1)
    log("env", json.dumps(env))
    failures = 0
    for model, max_len, configs in JOBS[name]:
        spec = {"model": model, "max_model_len": max_len, "configs": configs, "out": root}
        rc = subprocess.run([sys.executable, os.path.abspath(__file__), "run", json.dumps(spec)]).returncode
        if rc != 0:
            failures += 1
            log(f"group {model} exited with {rc}")
        upload(root, f"l1/{name}")
    log(f"job {name} done, failed groups: {failures}")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    if sys.argv[1] == "job":
        job(sys.argv[2])
    elif sys.argv[1] == "run":
        st = run_group(json.loads(sys.argv[2]))
        log("status", json.dumps(st))
        sys.exit(0 if all(v == "ok" for v in st.values()) else 2)
    else:
        raise SystemExit(__doc__)
