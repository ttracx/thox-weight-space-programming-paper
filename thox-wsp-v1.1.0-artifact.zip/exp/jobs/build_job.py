"""Assemble the self-contained HF Jobs script l1_eval.py from lib/wsp_loop.py and jobs/l1_eval_main.py.

The job runs as a single uv script, so the loop metric is inlined rather than imported; building it from the
same source file keeps the GPU job, the local analysis and the tests on one implementation.
"""
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
HEADER = """# /// script
# requires-python = ">=3.11"
# dependencies = ["vllm==0.33.0", "math-verify==0.9.0", "datasets", "huggingface_hub"]
# ///
"""


def main() -> int:
    loop_src = (HERE.parent / "lib" / "wsp_loop.py").read_text(encoding="utf-8")
    main_src = (HERE / "l1_eval_main.py").read_text(encoding="utf-8")
    marker = "#__WSP_LOOP_INLINE__\n"
    if marker not in main_src:
        print("marker missing in l1_eval_main.py", file=sys.stderr)
        return 1
    out = HEADER + loop_src + "\n\n" + main_src.replace(marker, "")
    compile(out, "l1_eval.py", "exec")
    (HERE / "l1_eval.py").write_text(out, encoding="utf-8")
    print(f"wrote {HERE / 'l1_eval.py'} ({len(out):,} bytes)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
