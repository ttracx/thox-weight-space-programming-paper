# L1: decoding-control jobs (technical report v1.1.0, Section 5)

`l1_eval.py` is assembled by `python build_job.py` from `../lib/wsp_loop.py` and `l1_eval_main.py`, and is stored in the
private dataset `Thox-ai/thox-wsp-evals` at `code/l1_eval.py` (sha256
`d33279484d2f57246ecfbfc79a53f9bc1a3257e41256c55c383bcdd519c75de6`). Each job checks that hash before it runs.

## Launch (Hugging Face Jobs)

Common settings for all four jobs:

- image `ghcr.io/astral-sh/uv:python3.12-bookworm`
- env `VLLM_USE_FLASHINFER_SAMPLER=0` (the image has no nvcc; FlashInfer's sampler JIT needs it)
- secret `HF_TOKEN=$HF_TOKEN` (results upload)
- volume `hf://datasets/Thox-ai/thox-wsp-evals/code:/code:ro`
- command: `sha256sum -c` against the hash above, copy to `/tmp/l1_eval.py`, then `uv run --script /tmp/l1_eval.py job <J>`

| Job | Flavor | Timeout | Content |
|---|---|---|---|
| J1 | h200 | 2h | Qwen3.5-0.8B thinking on (500 x 1) + budget and interrupt defences |
| J2 | h200 | 2h | Released edit thinking on (500 x 1) + defences |
| J3a | a100-large | 90m | Base and edit thinking off: card sampling (500 x 4) and greedy (500 x 1) |
| J3b | a100-large | 60m | ThoxEdge-0.8B bare greedy, served configuration, card sampling; thox-micro-125m-instruct greedy |

Results upload to `l1/<J>/` in the dataset after each model group.

## Analyse and rebuild

1. Run `exp/analyze_l1.py` as a CPU job with the dataset mounted at `/data` and `--upload`; it writes `results/l1_summary.json`.
2. Copy that file to `exp/results/l1_summary.json`.
3. `python wp/figures.py && python wp/build.py && node wp/pdf.cjs wp/out <version> <date> && python wp/merge_pdf.py wp/out <pdf> <version> && python wp/demo_build.py`.

The paper switches to the measured Section 5 (results table, Figures 6 and 7, defences, THOX models, verdict under the
pre-registered rule) when `l1_summary.json` is present.

## Run history

| Date (UTC) | Event |
|---|---|
| 2026-11-04 15:11 | First launch failed at engine start: FlashInfer sampler needs nvcc. Fixed with the env setting above |
| 2026-11-04 15:15 | Second launch ran; all four jobs stopped at about 15:20, before any upload |
| 2026-11-04 15:34 | Relaunch refused: HTTP 402 Payment Required for every job (GPU and CPU, user and Thox-ai namespaces) |
