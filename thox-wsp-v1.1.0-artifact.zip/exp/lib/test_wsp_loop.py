"""Unit tests for wsp_loop.py (run: python -m unittest -v test_wsp_loop.py from exp/lib)."""
import random
import unittest

import wsp_loop as L


def _fresh_words(k, seed=0):
    rng = random.Random(seed)
    return [f"w{rng.randrange(10**9)}" for _ in range(k)]


class LoopScanTests(unittest.TestCase):
    def test_short_text_never_loops(self):
        r = L.loop_scan("a b c")
        self.assertFalse(r["looping"])
        self.assertEqual(r["n_words"], 3)
        self.assertEqual(r["repeat_share"], 0.0)

    def test_unique_text_does_not_loop(self):
        text = " ".join(_fresh_words(2000))
        r = L.loop_scan(text)
        self.assertFalse(r["looping"])
        self.assertEqual(r["repeat_share"], 0.0)

    def test_exact_repetition_loops_with_correct_onset(self):
        head = _fresh_words(500, seed=1)
        block = _fresh_words(37, seed=2)
        words = head + block * 40
        text = " ".join(words)
        r = L.loop_scan(text)
        self.assertTrue(r["looping"])
        # n-grams start repeating once the second copy of the block begins (word 500 + 37); the first
        # qualifying window starts shortly before that, never inside the unique head's early part.
        self.assertGreaterEqual(r["onset_word"], 500 - 300)
        self.assertLessEqual(r["onset_word"], 500 + 37 + 1)
        self.assertEqual(text[r["onset_char"]:].split()[0], words[r["onset_word"]])
        self.assertEqual(r["fire_word"], r["onset_word"] + 299)

    def test_threshold_boundary(self):
        # 300-window with exactly 270 repeats fires; 269 does not. Build flags directly through text design:
        # a long unique prefix, then a block repeated, then compare frac thresholds on a controlled text.
        words = _fresh_words(320, seed=3) + _fresh_words(320, seed=3)
        text = " ".join(words)
        hi = L.loop_scan(text, frac=0.9)
        self.assertTrue(hi["looping"])
        lo = L.loop_scan(" ".join(_fresh_words(640, seed=4)), frac=0.9)
        self.assertFalse(lo["looping"])

    def test_causality_prefix_invariance(self):
        head = _fresh_words(400, seed=5)
        block = _fresh_words(25, seed=6)
        words = head + block * 30
        full = L.loop_scan(" ".join(words))
        cut = full["fire_word"] + 8
        pref = L.loop_scan(" ".join(words[:cut]))
        self.assertTrue(pref["looping"])
        self.assertEqual(pref["onset_word"], full["onset_word"])

    def test_bad_arguments(self):
        with self.assertRaises(ValueError):
            L.loop_scan("x", n=0)
        with self.assertRaises(ValueError):
            L.loop_scan("x", frac=0)
        with self.assertRaises(TypeError):
            L.loop_scan(None)


class VerbatimTests(unittest.TestCase):
    def test_repeated_end_block(self):
        text = " ".join(_fresh_words(100, seed=7) + ["a", "b", "c", "d", "e"] * 10 + ["partial"])
        self.assertTrue(L.verbatim_loop_end(text))

    def test_clean_end(self):
        self.assertFalse(L.verbatim_loop_end(" ".join(_fresh_words(300, seed=8))))


class SplitTests(unittest.TestCase):
    def test_split(self):
        self.assertEqual(L.split_reasoning("abc</think>xyz"), ("abc", "xyz"))
        self.assertEqual(L.split_reasoning("abc"), ("abc", None))


if __name__ == "__main__":
    unittest.main()
