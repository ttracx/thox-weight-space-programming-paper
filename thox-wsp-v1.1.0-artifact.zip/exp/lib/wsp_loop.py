"""wsp_loop.py: loop and repetition metrics for THOX Weight-Space Programming evaluations.

THOX.ai Research, technical report v1.1.0 artifact. Pure Python, no dependencies, so the same code runs in the
GPU evaluation job, in the local analysis, and (ported line for line) in the companion demo page.

Two signals:

1. loop_scan(): the n-gram window test used by the v1.0.0 paper and by the independent CPU re-check of the
   source post. An answer counts as looping when, inside some run of `window` consecutive word 8-grams, at least
   `frac` of the 8-grams have already appeared earlier in the same text. The scan is causal: whether it fires by
   word j depends only on words 0..j, so the first qualifying window is exactly what a streaming detector would
   see. The onset is the first word of that window, the point a streaming interrupt rewinds to.

2. verbatim_loop_end(): the source authors' end-of-text period test (exp8_math/code/mathqa.py loop_signals,
   MIT licence, RikiyaT/lm_understand-logs @ 4d09ba6): without its last word, the text ends with one block of
   1..200 words repeated at least 3 times in a row and over at least 40 words. Re-implemented here verbatim in
   logic so the two signals can be compared on the same generations.
"""
from __future__ import annotations

import math
import re
from typing import Dict, List, Optional, Tuple

WORD_RE = re.compile(r"\S+")

DEFAULT_N = 8
DEFAULT_WINDOW = 300
DEFAULT_FRAC = 0.9

LOOP_MAX_PERIOD = 200
LOOP_MIN_REPEATS = 3
LOOP_MIN_SPAN = 40


def _words_with_offsets(text: str) -> Tuple[List[str], List[int]]:
    """Split on whitespace and keep each word's starting character offset."""
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")
    words: List[str] = []
    offsets: List[int] = []
    for m in WORD_RE.finditer(text):
        words.append(m.group())
        offsets.append(m.start())
    return words, offsets


def loop_scan(text: str, n: int = DEFAULT_N, window: int = DEFAULT_WINDOW,
              frac: float = DEFAULT_FRAC) -> Dict[str, Optional[float]]:
    """Causal n-gram loop test.

    Returns a dict with:
      looping      bool, True when some window of `window` consecutive n-grams has >= ceil(frac*window) repeats
      onset_word   index of the first word of the first qualifying window, or None
      onset_char   character offset of that word in `text`, or None
      fire_word    index of the last n-gram start in the first qualifying window (when a streaming detector
                   would fire), or None
      n_words      number of whitespace words
      repeat_share share of all n-grams that repeat an earlier n-gram (0.0 for texts shorter than n words)
    """
    if n < 1 or window < 1:
        raise ValueError("n and window must be positive")
    if not (0.0 < frac <= 1.0):
        raise ValueError("frac must be in (0, 1]")
    words, offsets = _words_with_offsets(text)
    m = len(words) - n + 1
    out: Dict[str, Optional[float]] = {"looping": False, "onset_word": None, "onset_char": None,
                                       "fire_word": None, "n_words": len(words), "repeat_share": 0.0}
    if m <= 0:
        return out
    seen = set()
    flags = bytearray(m)
    for i in range(m):
        g = tuple(words[i:i + n])
        if g in seen:
            flags[i] = 1
        else:
            seen.add(g)
    out["repeat_share"] = sum(flags) / m
    if m < window:
        return out
    need = math.ceil(frac * window - 1e-9)
    s = sum(flags[:window])
    start = None
    if s >= need:
        start = 0
    else:
        for i in range(window, m):
            s += flags[i] - flags[i - window]
            if s >= need:
                start = i - window + 1
                break
    if start is not None:
        out["looping"] = True
        out["onset_word"] = start
        out["onset_char"] = offsets[start]
        out["fire_word"] = start + window - 1
    return out


def verbatim_loop_end(text: str) -> bool:
    """The source authors' period test on the END of a text (see module docstring)."""
    w = text.split()[:-1]
    n = len(w)
    for p in range(1, LOOP_MAX_PERIOD + 1):
        reps = max(LOOP_MIN_REPEATS, -(-LOOP_MIN_SPAN // p))
        if reps * p > n:
            break
        blk = w[n - p:]
        if all(w[n - (j + 1) * p:n - j * p] == blk for j in range(1, reps)):
            return True
    return False


THINK_CLOSE = "</think>"


def split_reasoning(text: str) -> Tuple[str, Optional[str]]:
    """(reasoning, answer). The answer is the text after the FIRST </think>; None when thinking never closed."""
    i = text.find(THINK_CLOSE)
    if i < 0:
        return text, None
    return text[:i], text[i + len(THINK_CLOSE):]
