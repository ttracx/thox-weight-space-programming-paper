"""A0: THOX paired analysis of the source authors' released per-problem MATH-500 results (Experiment 8).

    python -I exp/a0_source_paired.py <lm_understand-logs checkout>/exp8_math/eval exp/results

Reads eval/unedited/parts/math500_s{0..9}of10/math500_per_problem.json and the same for eval/p50c (4 samples per
problem, thinking on, 32,768-token cap; RikiyaT/lm_understand-logs @ 4d09ba6, CC BY 4.0) and writes
exp/results/a0_source_paired.json: per-model accuracy recomputed from the per-problem records, the paired
problem-level difference with a 95% bootstrap interval (10,000 resamples over problems, seed 0), and how the gain is
distributed over problems. No GPU, no model: this is arithmetic on released files, class CALCULATED.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np


def load(eval_dir: str, ckpt: str) -> dict[str, list[int]]:
    out: dict[str, list[int]] = {}
    for i in range(10):
        p = os.path.join(eval_dir, ckpt, "parts", f"math500_s{i}of10", "math500_per_problem.json")
        for r in json.load(open(p, encoding="utf-8")):
            if r["id"] in out:
                raise ValueError(f"duplicate problem {r['id']} in {ckpt}")
            out[r["id"]] = [int(c) for c in r["correct"]]
    if len(out) != 500:
        raise ValueError(f"{ckpt}: {len(out)} problems, expected 500")
    return out


def main(eval_dir: str, out_dir: str) -> int:
    base, edit = load(eval_dir, "unedited"), load(eval_dir, "p50c")
    ids = sorted(base)
    if set(ids) != set(edit):
        raise ValueError("problem sets differ")
    b = np.array([np.mean(base[i]) for i in ids])
    e = np.array([np.mean(edit[i]) for i in ids])
    x = e - b
    rng = np.random.default_rng(0)
    boots = rng.choice(x, size=(10_000, len(x)), replace=True).mean(axis=1)
    lo, hi = np.percentile(boots, [2.5, 97.5])
    res = {
        "source": "RikiyaT/lm_understand-logs@4d09ba6 exp8_math/eval/{unedited,p50c} math500 per-problem files",
        "samples_per_problem": len(base[ids[0]]),
        "base_acc": float(b.mean()), "edit_acc": float(e.mean()),
        "base_se": float(b.std(ddof=1) / np.sqrt(len(b))), "edit_se": float(e.std(ddof=1) / np.sqrt(len(e))),
        "diff": float(x.mean()), "diff_ci95": [float(lo), float(hi)],
        "problems_better": int((x > 0).sum()), "problems_worse": int((x < 0).sum()), "problems_equal": int((x == 0).sum()),
        "base_never_solved": int((b == 0).sum()),
        "base_never_edit_some": int(((b == 0) & (e > 0)).sum()),
        "edit_all_samples_correct": int((e == 1).sum()), "base_all_samples_correct": int((b == 1).sum()),
        "edit_majority": int((e >= 0.5).sum()), "base_majority": int((b >= 0.5).sum()),
    }
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "a0_source_paired.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, indent=1)
    print(json.dumps(res, indent=1))
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(*sys.argv[1:]))
