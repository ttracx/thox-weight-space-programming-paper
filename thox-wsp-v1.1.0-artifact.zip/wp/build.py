"""build.py: THOX technical report v1.1.0, Weight-Space Programming for THOX Edge Models.

    python wp/build.py        (from the repository root)

Reads only the evidence files in exp/results/ and the verified reference list in refs/verified_refs.json, renders the
equations with KaTeX (wp/katex_render.cjs), inlines the figures from wp/fig/ and the Inter and JetBrains Mono fonts,
and writes three standalone HTML files to wp/out/: paper.html (screen edition with light and dark themes),
cover.html and body.html (print sources for wp/pdf.cjs). Every number in the text comes from the evidence files;
citations are written as [@key] and numbered by first use. A key that is cited but not in the reference table, or
listed but never cited, fails the build.
"""
from __future__ import annotations

import base64
import html
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "exp", "results")
WP = os.path.join(ROOT, "wp")
OUT = os.path.join(WP, "out")
FONTS = os.path.join(WP, "node", "node_modules", "@fontsource")

VERSION = "1.1.0"
DATE = "2026-11-04"
PREV = ("1.0.0", "2026-11-03")
TITLE = "Weight-Space Programming for THOX Edge Models: Evidence Review, Small-Scale Recreation, and a Signed Patch Channel"
SHORT = "Weight-Space Programming for THOX Edge Models"
DECK = ("What a frontier LLM reading and writing weights actually establishes, what THOX reproduced and verified "
        "itself, and the signed patch channel that makes any of it shippable.")


# ---------------------------------------------------------------------------------------------------- evidence
def load(name, required=True):
    p = os.path.join(RES, name)
    if not os.path.exists(p):
        if required:
            raise SystemExit(f"missing evidence file {p}")
        return None
    return json.load(open(p, encoding="utf-8"))


CARRIED = load("carried_v1_0_0.json")
E0R = load("e0r_patch_forms.json")
SRC_BASE = load("source/exp8_unedited_merged.json")
SRC_EDIT = load("source/exp8_p50c_merged.json")
L1 = load("l1_summary.json", required=False)
A0 = load("a0_source_paired.json")
L1_STATUS = ("The four L1 jobs were launched on Hugging Face Jobs on 2026-11-04 and were stopped at about 15:20 UTC, "
             "minutes into generation, before any result was saved. A relaunch was then refused with HTTP 402 (Payment "
             "Required) for every job, GPU or CPU, under both the user and the organisation namespaces, which is "
             "consistent with exhausted compute credit rather than a fault in the jobs.")
REFS_VERIFIED = {r["key"]: r for r in json.load(open(os.path.join(ROOT, "refs", "verified_refs.json"), encoding="utf-8"))}


def pct(x, d=1):
    return f"{x * 100:.{d}f}%"


def num(x):
    return f"{x:,}"


def pts(x, d=1):
    s = f"{abs(x) * 100:.{d}f}"
    return ("+" if x >= 0 else "&minus;") + s + " points"


def kb(b):
    return f"{b / 1e6:.2f} MB" if b >= 1e6 else f"{b / 1e3:.1f} KB"


def cv(group, key):
    return CARRIED[group][key]["value"]


# ---------------------------------------------------------------------------------------------------- references
def _auth(lst, n=6):
    lst = [a for a in lst if a]
    if len(lst) > n:
        return ", ".join(lst[:n]) + ", et al"
    return ", ".join(lst)


def vref(key):
    r = REFS_VERIFIED[key]
    a = _auth(r.get("authors") or [])
    venue = r.get("venue") or ""
    venue = re.split(r"\s*\((?:per )?abs-page", venue)[0].strip()
    yr = r.get("year") or ""
    if re.search(r"\b(19|20)\d\d\b", venue):
        yr = ""
    url = r.get("url") or ""
    arx = re.search(r"arxiv\.org/abs/([0-9.]+)", url)
    where = f"arXiv:{arx.group(1)}" if arx else ""
    parts = [f"{a}." if a else "", f"{r['title']}.", f"{venue}{', ' if venue and yr else ''}{yr}." if (venue or yr) else "",
             f"{where}." if where else ""]
    return " ".join(p for p in parts if p), url


REF_TABLE = {
    "src": ("1", "Blog post, rikiyat.github.io; authors affiliated with MIT CSAIL, published 2026-11-02"),
    "qwen": ("2", None), "logs": ("5", "commit 4d09ba6; CC BY 4.0 (logs, data, networks), MIT (scripts), GPL-3.0 "
                                       "(MinAtar source quoted in the Experiment 5 prompts)"),
    "honnibal": ("6", None), "willison": ("7", None), "wspacetest": ("8", "user repository, no description; "
                                                                         "cited at the state of 2026-11-03"),
    "editckpt": ("9", None),
    "goedecke": ("10", None), "arditi": ("11", None), "eilertsen": ("12", None), "unterthiner": ("13", None),
    "survey": ("14", None), "kaushik": ("15", "v3 revised 2026-10-05; interpretation contested in secondary coverage"),
    "ha": ("16", None), "peebles": ("17", None), "t2l": ("18", None), "zhyper": ("19", None), "rome": ("20", None),
    "memit": ("21", None), "repe": ("22", None), "lora": ("23", None), "soups": ("24", None),
    "taskarith": ("25", None), "ties": ("26", None), "dare": ("27", None), "elhage": ("28", None),
    "olsson": ("29", None), "tracr": ("30", None), "opro": ("31", None),
    "openwsp": ("B1", "README, report.md and STATUS.md at the pinned commit; 1 sample per problem"),
    "krentsel": ("B2a", "figures appear only in a chart image"),
    "officechai": ("B2b", "the article's reading of the chart in the X post"),
    "kingy": ("B3", None), "alphaxiv": ("B4", "comment reports a 'math eval' without naming the benchmark"),
    "astra": ("B5", "title and date as published in OpenAI's RSS feed"),
    "dwsnet": ("B6", None), "nfn": ("B7", None), "hase": ("B8", None), "s1": ("B9", None),
    "holtzman": ("B10", None), "lightman": ("B11", "source of the MATH-500 subset"), "hendrycks": ("B12", None),
    "vllm": ("B13", None), "mathverify": ("B14", "version 0.9.0 used for grading"), "rfc8032": ("B15", None),
    "thoxedge": ("B16", None), "micro": ("B17", None),
}
EXTRA_REFS = {
    "qwen3": ("An Yang, Anfeng Li, Baosong Yang, Beichen Zhang, Binyuan Hui, Bo Zheng, et al. Qwen3 Technical Report. "
              "arXiv preprint, 2025. arXiv:2505.09388.", "https://arxiv.org/abs/2505.09388"),
    "catalog": ("THOX.ai. THOX device model catalog, live revision 2026-11-02.1 (94 models), and TXF-MP model cards. "
                "THOX.ai internal records, as cited in technical report v1.0.0.", ""),
    "meshstack": ("Craig Ross, Tommy Xaypanya. THOX MeshStack: Capacity-Priced Pipeline Sharding, Grant-Gated KV Transfer "
                  "and Lease-Fenced Device Roles for a Private Household Mesh. THOX.ai Research technical report "
                  "v1.0.1, Zenodo, 2026. DOI 10.5281/zenodo.23919580.", "https://doi.org/10.5281/zenodo.23919580"),
    "v100": ("THOX.ai Research. Weight-Space Programming for THOX Edge Models: Evidence Review, Small-Scale "
             "Recreation, and a Signed Patch Channel. Technical report v1.0.0, internal edition, 2026-11-03.", ""),
    "evals": ("THOX.ai Research. thox-wsp-evals: L1 generations, defence outputs and analysis for technical report "
              "v1.1.0. Private Hugging Face dataset Thox-ai/thox-wsp-evals, 2026-11-04.",
              "https://huggingface.co/datasets/Thox-ai/thox-wsp-evals"),
}


def ref_entry(key):
    if key in EXTRA_REFS:
        return EXTRA_REFS[key]
    vkey, note = REF_TABLE[key]
    text, url = vref(vkey)
    if key == "src":
        r = REFS_VERIFIED["1"]
        text = f"{_auth(r['authors'])}. {r['title']}. Blog post, rikiyat.github.io (authors affiliated with MIT CSAIL), 2026-11-02."
    if key == "qwen":
        text = ("Qwen Team. Qwen/Qwen3.5-0.8B model repository, revision 2fc06364715b967f1860aea9cf38778875588b17. "
                "Hugging Face, Apache-2.0, 2026.")
    if key == "editckpt":
        text = ("RikiyaT; checkpoint rebuilt and re-evaluated by akhaliq (AK) with ML Intern. "
                "RikiyaT/Qwen3.5-0.8B-weight-space-programming, revision d1671a178705bcab7644806d23c535517f35723b. "
                "Hugging Face, Apache-2.0, 2026.")
    if key == "logs":
        text = ("RikiyaT. lm_understand-logs: prompts, replies, networks, edit scripts and evaluations for the Sparks "
                "experiments. GitHub repository, commit 4d09ba6d6a7e891dd8063974dfe81b3d78e3494f, 2026.")
    if key == "wspacetest":
        text = "adiant211. wspacetest: an independent CPU re-check of the Sparks experiments. GitHub repository, 2026."
    if key == "openwsp":
        text = "OpenWSP contributors. OpenWSP. GitHub repository, commit 2265473e250b6f6f40a0e2c7853129902d0a11ea, 2026-11-04."
    if key == "krentsel":
        text = ("Alex Krentsel. Post on X reporting a cross-model reproduction of the Sparks Experiment 5, "
                "2026-11-03.")
    if key == "alphaxiv":
        text = ("Joseph Noble. Comment on the alphaXiv discussion page for 'Sparks of Weight-Space Programming', "
                "2026-11-03.")
    if key in ("thoxedge", "micro"):
        r = REFS_VERIFIED[vkey]
        text = f"THOX.ai. {r['title']}. {r['venue']}, 2026."
    if key == "mathverify":
        text = "Hugging Face. Math-Verify. GitHub repository huggingface/Math-Verify and PyPI package math-verify."
    if note:
        text = text.rstrip(".") + f". Note: {note}."
    return text, url


# ---------------------------------------------------------------------------------------------------- document model
class Doc:
    def __init__(self):
        self.parts = []
        self.cite_order = []
        self.eqs = {}
        self.fig_n = 0
        self.tab_n = 0
        self.figs = {}
        self.tabs = {}

    # inline markup: [@a,b] citations, **bold**, `code`, {fig:x} {tab:x}
    def md(self, s):
        def cite(m):
            keys = [k.strip() for k in m.group(1).split(",")]
            out = []
            for k in keys:
                if k not in REF_TABLE and k not in EXTRA_REFS:
                    raise SystemExit(f"unknown citation key {k}")
                if k not in self.cite_order:
                    self.cite_order.append(k)
                out.append(f'<a class="cite" href="#ref-{k}">[{self.cite_order.index(k) + 1}]</a>')
            return "".join(out)
        s = re.sub(r"\[@([^\]]+)\]", cite, s)
        s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
        s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
        s = re.sub(r"\{fig:([a-z0-9_]+)\}", lambda m: f"Figure {self.reserve_fig(m.group(1))}", s)
        s = re.sub(r"\{tab:([a-z0-9_]+)\}", lambda m: f"Table {self.reserve_tab(m.group(1))}", s)
        s = re.sub(r"\$\$(.+?)\$\$", lambda m: self.inline_eq(m.group(1)), s)
        return s

    def inline_eq(self, tex):
        eid = f"ieq{len(self.eqs)}"
        self.eqs[eid] = {"tex": tex, "display": False}
        return f"@@{eid}@@"

    def add(self, h):
        self.parts.append(h)

    def h2(self, n, text, anchor):
        self.add(f'<h2 id="{anchor}"><span class="secno">{n}</span>{text}</h2>')

    def h3(self, text):
        self.add(f"<h3>{text}</h3>")

    def p(self, text, cls=""):
        self.add(f'<p{f" class={chr(34)}{cls}{chr(34)}" if cls else ""}>{self.md(text)}</p>')

    def bullets(self, items):
        self.add("<ul>" + "".join(f"<li>{self.md(i)}</li>" for i in items) + "</ul>")

    def numbered(self, items):
        self.add("<ol>" + "".join(f"<li>{self.md(i)}</li>" for i in items) + "</ol>")

    def callout(self, title, text, kind=""):
        self.add(f'<aside class="callout {kind}"><div class="callout-t">{title}</div><p>{self.md(text)}</p></aside>')

    def eq(self, tex, label=None):
        eid = f"eq{len(self.eqs)}"
        self.eqs[eid] = {"tex": tex, "display": True}
        lab = f'<span class="eqno">({label})</span>' if label else ""
        self.add(f'<div class="eq">@@{eid}@@{lab}</div>')

    def reserve_fig(self, key):
        if key not in self.figs:
            self.fig_n += 1
            self.figs[key] = self.fig_n
        return self.figs[key]

    def reserve_tab(self, key):
        if key not in self.tabs:
            self.tab_n += 1
            self.tabs[key] = self.tab_n
        return self.tabs[key]

    def figure(self, key, svg_file, caption, cls_label):
        n = self.reserve_fig(key)
        path = os.path.join(WP, "fig", svg_file)
        if not os.path.exists(path):
            raise SystemExit(f"missing figure {path}")
        svg = open(path, encoding="utf-8").read()
        svg = re.sub(r"<\?xml[^>]*\?>", "", svg)
        svg = re.sub(r"<!DOCTYPE[^>]*>", "", svg)
        wm = re.search(r'<svg[^>]*?\swidth="([0-9.]+)pt"', svg)
        maxw = f' style="max-width:{float(wm.group(1)) * 1.05:.0f}pt"' if wm else ""
        svg = re.sub(r'(<svg[^>]*?)\swidth="[^"]*"', r"\1", svg, count=1)
        svg = re.sub(r'(<svg[^>]*?)\sheight="[^"]*"', r"\1", svg, count=1)
        self.add(f'<figure id="fig-{key}"><div class="fig"{maxw}>{svg}</div><figcaption><b>Figure {n}.</b> '
                 f'{self.md(caption)} <span class="ev">{cls_label}</span></figcaption></figure>')

    def table(self, key, columns, rows, caption, widths=None, cls=""):
        n = self.reserve_tab(key)
        cg = ""
        if widths:
            tot = sum(widths)
            cg = "<colgroup>" + "".join(f'<col style="width:{w / tot * 100:.1f}%">' for w in widths) + "</colgroup>"
        head = "".join(f"<th>{self.md(c)}</th>" for c in columns)
        body = "".join("<tr>" + "".join(f"<td>{self.md(str(c))}</td>" for c in r) + "</tr>" for r in rows)
        self.add(f'<figure class="tbl {cls}" id="tab-{key}"><table>{cg}<thead><tr>{head}</tr></thead>'
                 f'<tbody>{body}</tbody></table><figcaption><b>Table {n}.</b> {self.md(caption)}</figcaption></figure>')

    def code(self, title, text):
        self.add(f'<div class="codebox"><div class="codebox-t">{title}</div><pre>{html.escape(text)}</pre></div>')


# ---------------------------------------------------------------------------------------------------- content
def l1c(key):
    if not L1:
        return None
    return L1["configs"].get(key) or L1["defences"].get(key)


def l1pair(a, b):
    if not L1:
        return None
    for p in L1["pairs"]:
        if p["a"] == a and p["b"] == b:
            return p
    return None


def ci_txt(p):
    lo, hi = p["ci95"]
    return f"95% interval {lo * 100:+.1f} to {hi * 100:+.1f}".replace("-", "&minus;")


def build_body(d: Doc):
    sb, se = SRC_BASE, SRC_EDIT
    t15, t19 = E0R["tensors"]
    changed_total = E0R["changed_entries_total"]
    fac15 = t15["factor_variants"][t15["factor_best_variant"]]
    fac19 = t19["factor_variants"][t19["factor_best_variant"]]
    resid = fac15["mismatched_entries"] + fac19["mismatched_entries"]
    sz = lambda k: t15["sizes_bytes"][k] + t19["sizes_bytes"][k]  # noqa: E731
    exact_patch = sz("factor_plus_residual_raw")
    npz = E0R["release_edit_npz_bytes"]
    full = sz("full_tensor_bf16")
    sparse_raw = sz("sparse_raw_idx4_val2")
    factor32 = sz("factor_u_f32_cols_i16_alpha_f64")

    base_on, edit_on, base_off, edit_off = (l1c(k) for k in ("base_on", "edit_on", "base_off", "edit_off"))
    have_l1 = bool(L1 and base_on and edit_on and base_off)

    # ---------------- 1 Introduction
    d.h2("1", "Introduction", "s1")
    d.p("On 2 November 2026, Takehi, Teoh, Zhang and Khattab published a blog post [@src], not a peer-reviewed "
        "paper, reporting that a frontier language model (OpenAI's GPT-6 Astra [@astra]) can read and write neural "
        "network weights directly, in natural language, without gradient descent. They name the practice "
        "**Weight-Space Programming** (WSP). The post's claims span three verbs. Read: given only the 17,253 weights "
        "of a small policy network as text, Astra named the game it was trained on, four times out of four. Write: "
        "given game rules and a zero-initialised network, it wrote policies that beat PPO trained for 100 million "
        "steps. Fix: given a Python kernel over the weights of Qwen3.5-0.8B and a budget of batched forward passes, it "
        f"diagnosed why the model loops in thinking mode and edited {num(131072)} of roughly 752 million weights, "
        f"raising MATH-500 from {sb['math500']['acc'] * 100:.1f}% to {se['math500']['acc'] * 100:.1f}% under the "
        "authors' sampling profile.")
    d.p("THOX builds small language models for its own devices, and one of them, ThoxEdge-0.8B, is a merged fine-tune "
        "of the exact base model in the fix experiment, Qwen/Qwen3.5-0.8B [@qwen,thoxedge]. A method that repairs a "
        "deployed model's dominant failure by changing 0.016% of its weights, and that could ship as kilobytes instead "
        "of a new 529 MB GGUF, is directly relevant to a device fleet that updates over a household mesh [@meshstack]. "
        "It is also exactly the kind of claim THOX does not repeat on the strength of a blog post.")
    d.p(f"Version {PREV[0]} of this report [@v100] reviewed the evidence, recreated the three verbs at checkable scale, "
        "verified the released edit and built a signed patch channel. It left the decisive control unmeasured: how "
        "much of the gain a decoding change recovers with no weight change at all. "
        + ("This edition measures it, on the full MATH-500, for the base model, the released edit and THOX's own "
           "deployed model in its served configuration. " if have_l1 else
           "This edition specifies that measurement at full MATH-500 scale, for the base model, the released edit and "
           "THOX's own deployed model in its served configuration, with a pre-registered decision rule; the run "
           "did not complete because compute billing stopped it. ") +
        "The contributions, in order of evidentiary weight:")
    contrib = [
        "**An evidence review with every citation re-verified** against its live primary page, extended with the "
        "source authors' own released evaluation files, which report results the post does not discuss "
        "(Section 2).",
        "**Four small-scale recreation experiments** (E1 to E4) carried unchanged from v1.0.0: task identity is legible "
        f"only in composed per-class circuits ({cv('E1', 'reader_acc')['R4']:.0f}% against chance), a hand-written "
        "network matches an oracle-trained one, 16 of 747 weights repair a stuck policy, and a weights-only audit "
        "returned a confident ranking for a behaviour that never formed (Section 4).",
        f"**An independent re-verification of the released edit (E0-R) and a measurement of its patch forms (P1)**: "
        f"{num(changed_total)} entries, both hashes, a bit-identical rebuild, and the finding that a factor form "
        f"estimated from the released diff reproduces only {pct(1 - resid / changed_total)} of the changed entries "
        f"bit-exactly; an exact patch needs a {num(resid)}-entry residual and totals {kb(exact_patch)} (Section 4.5).",
    ]
    if have_l1:
        pr = l1pair("edit_on", "base_off")
        contrib.append(
            f"**The decoding control, measured (L1)**: on all 500 MATH-500 problems, turning thinking off with no weight "
            f"change scores {pct(base_off['acc'])} against {pct(edit_on['acc'])} for the released edit with thinking "
            f"on (paired difference {pts(pr['diff'])}, {ci_txt(pr)}); two decoding-only defences and THOX's own "
            "deployed model are measured on the same footing (Section 5).")
    else:
        contrib.append("**The decoding control (L1), specified and built but not yet measured**: a fixed protocol "
                       "on the full MATH-500, a tested job script, decoding-only defences applied to the same "
                       "generations, and an analysis pipeline; the run was stopped for compute billing before completion, so "
                       "this edition states no Section 5 number (Section 5).")
    contrib.append("**A corrected patch-channel specification**: the patch-size table now agrees with the wire "
                   "format, and exactness is enforced by result hashes plus an optional sparse residual (Section 6).")
    d.numbered(contrib)
    implications = ("Ship decoding-side loop defences and measured serving configurations first; they are free, "
                    + ("reversible and, on this evidence, recover most of the benchmark gain. " if have_l1 else
                       "reversible, and the only available measurement of the decisive comparison (third-party, one "
                       "sample per problem) says they recover most of the benchmark gain. ") +
                    "Keep the signed patch "
                    "channel, which serves LoRA and distillation deltas today. Treat LLM weight editing as a gated "
                    "research program whose first bar is beating those controls. Do not describe any THOX model as "
                    "created or improved by Weight-Space Programming until that bar is cleared.")
    d.callout("Product implications", implications)

    # ---------------- 2 Source result
    d.h2("2", "The source result and its evidence state", "s2")
    d.h3("2.1 What was shown, experiment by experiment")
    tab_exp = d.reserve_tab("exp")
    d.p(f"Table {tab_exp} summarises the eight experiments as reported [@src,logs]. Two structural facts matter for "
        "everything that follows. The raw-weights, no-tools setting applies only to Experiments 1, 2 and 4, on "
        "networks of 17K to 172K weights. Every experiment involving a real language model (3, 6, 7, 8) gave the "
        "editor a Python sandbox and, except in Experiment 3, a budget of forward passes. The popular summary of the "
        "post, an LLM reading raw weights and fixing a real model by inspection, describes no single experiment in it "
        "[@honnibal].")
    d.table("exp", ["Exp.", "Verb", "Setting", "Headline result (author-reported)", "Independent status"], [
        ["1", "Read", "17,253 weights as text, no tools", "Game named correctly 4/4, open answer",
         "Partially reproduced with other models (Qwen 3.8 27B: 3 games; Kimi K3.1 Pro: 1) [@willison]"],
        ["2", "Read", "23,824 weights, no tools, no forward pass", "Diffusion model's shape named 3/3 (drawn as outline)",
         "Answers re-scored consistent; a Sobel template tool also scores 3/3 [@wspacetest]"],
        ["3", "Read", "Middle blocks only of 7.16M char LMs, Python, no execution",
         "Language 6/6 attempts; every copying head named, no false positives",
         "Signed K-composition tool recovers 2/3 exactly; unsigned textbook score fails [@wspacetest]"],
        ["4", "Fix", "171,664 weights, no tools, one reply", "Stuck car policy: 0% to 100% over 1,024 episodes; 3.54% of weights changed",
         "Rebuilt network bit-identical; success rate not independently re-run"],
        ["5", "Write", "Zero-initialised 20,486-weight policies, no tools, no rollouts",
         "Beat PPO-100M on 3 MinAtar games; Breakout 517.4 vs PPO-500M 25.3",
         "Re-scored within 1.4 SE [@wspacetest]; cross-model chart: Claude Opus 5.5 about 20x PPO-500M on Breakout, "
         "as read by press coverage; raw data not public [@krentsel,officechai]"],
        ["6", "Write", "1.48M-weight Go network, Python sandbox, 0 to 50 forward passes",
         "50 passes: beats equal-size PPO trained on 20M games", "Replayed within 1.7 SE [@wspacetest]"],
        ["7", "Read", "Gemma 3 270M pair differing only in a sycophancy fine-tune",
         "Weights alone failed 4/4; with attention patterns 3/3 pairs", "Re-scored: weights-only answers at chance [@wspacetest]"],
        ["8", "Fix", "Qwen3.5-0.8B, Python kernel, 10/25/50 forward passes, 158 turns, 20.3 h",
         f"MATH-500 {sb['math500']['acc'] * 100:.1f}% to {se['math500']['acc'] * 100:.1f}%; cap hits "
         f"{sb['math500']['cut_share'] * 100:.1f}% to {se['math500']['cut_share'] * 100:.1f}%",
         "Edit identity reproduced (THOX E0 and E0-R); MATH-500 re-run once in full; mechanism consistent"],
    ], "The eight Sparks experiments. Results are author-reported unless the last column says otherwise.",
        widths=[0.5, 0.6, 2.2, 2.4, 2.8], cls="small")

    d.h3("2.2 What independent work has established")
    d.p("The Experiment 8 edit is the best-verified claim in the post. The released `apply_edit.py` rebuilds the edited "
        "checkpoint from the pinned base, and several parties, THOX included (Section 4.5), confirm that the two "
        "edited tensors hash to the published values [@logs,editckpt]. The MATH-500 gain was re-run once in full on "
        "Hugging Face Jobs: 51.0% for the edited model against the authors' 48.1%, with the base model checked only on "
        "a 25-problem smoke test (5.0%) [@editckpt]. A commenter reports 10.9% and 61.7% on a 'math eval' without "
        "naming the benchmark or settings [@alphaxiv]; this paper does not count it as a MATH-500 result. Under a "
        "repeated 8-gram test, 183 of 200 base answers loop against 72 of 200 edited, and median loop onset moves from "
        "2,725 to 7,856 words; Experiment 5 and 6 scores reproduce within about one standard error [@wspacetest].")
    d.p(f"The edit's anatomy is also established. It touches 64 columns of the `down_proj` matrix in each of layers 15 "
        f"and 19: {num(131072)} entries addressed, {num(changed_total)} of them different after bfloat16 rounding. "
        f"Per tensor the diff is rank-1 (singular-value ratios {t15['sigma1_over_sigma2']:,.0f} and "
        f"{t19['sigma1_over_sigma2']:,.0f}), and the component along the diagnosed repetition direction is multiplied "
        f"by about &minus;5: flipped and amplified, not merely removed [@wspacetest]. The relative change to the two "
        f"matrices is {pct(t15['relative_frobenius_change'])} and {pct(t19['relative_frobenius_change'])} in "
        "Frobenius terms: a small count of edited entries is not a small edit.")

    d.h3("2.3 What the authors' own released files add")
    fig_src = d.reserve_fig("src")
    d.p(f"The released logs include the authors' live results table and per-benchmark scores, which carry more than "
        f"the post discusses [@logs]. {{fig:src}} plots them. The 50-pass edit lifts every benchmark the authors ran, "
        f"not only the two in the headline: AMC23 from {sb['amc23']['acc'] * 100:.1f}% to "
        f"{se['amc23']['acc'] * 100:.1f}%, Minerva from {sb['minerva']['acc'] * 100:.1f}% to "
        f"{se['minerva']['acc'] * 100:.1f}%, OlympiadBench from {sb['olympiad']['acc'] * 100:.1f}% to "
        f"{se['olympiad']['acc'] * 100:.1f}%, GPQA Diamond from {sb['gpqa']['acc'] * 100:.1f}% to "
        f"{se['gpqa']['acc'] * 100:.1f}% and the MMLU-Pro subset from {sb['mmlupro1k']['acc'] * 100:.1f}% to "
        f"{se['mmlupro1k']['acc'] * 100:.1f}%. The pattern is the loop story's signature: the unedited model hits the "
        f"32,768-token cap on {sb['amc23']['cut_share'] * 100:.1f}% of AMC23 answers and "
        f"{sb['olympiad']['cut_share'] * 100:.1f}% of OlympiadBench answers, and the benchmarks with the most cap hits "
        "gain the most. The same table records two facts that bound the prompt-hint critique. A run with a shorter "
        "prompt that omitted the failure example (prompt v4) submitted no edit at 10 passes and reached the same "
        "14.1% at 25 passes as the hinted prompt; and the four prompt-v5 runs are listed without results. Run-to-run "
        "variance is therefore real and only partly characterised.")
    d.figure("src", "fig1_source_exp8.svg",
             "Experiment 8 as reported in the authors' released evaluation files (thinking on, 32,768-token cap; "
             "4 samples per problem for MATH-500, Minerva, OlympiadBench and GPQA, 2 for GSM8K and IFEval, 16 for "
             "AMC23, 1 for MMLU-Pro) [@logs]. THOX did not run these benchmarks.", "Author-reported")
    lo, hi = A0["diff_ci95"]
    d.p(f"THOX re-analysed the released MATH-500 per-problem files (A0, arithmetic on released data). They reproduce "
        f"the headline exactly ({pct(A0['base_acc'])} and {pct(A0['edit_acc'])} over "
        f"{A0['samples_per_problem']} samples per problem), and the paired problem-level gain is "
        f"{pts(A0['diff'])} with a 95% bootstrap interval of {lo * 100:.1f} to {hi * 100:.1f} points. The edit scores "
        f"higher than the base on {A0['problems_better']} problems and lower on {A0['problems_worse']}; the base "
        f"never solves {A0['base_never_solved']} of the 500 in four samples, and the edit solves "
        f"{A0['base_never_edit_some']} of those at least once. A change that helps on hundreds of problems and hurts "
        "on none is what removing a uniform obstacle looks like, and it is also exactly the signature a decoding "
        "change that avoids the same obstacle would produce, which is why Section 2.5 matters.")

    d.h3("2.4 What is contested")
    d.p("Three critiques bound the claim. **Framing.** The no-tools, raw-floats setting covers only the small-network "
        "experiments; the Qwen result shows a frontier model can be prompted to devise and carry out a task a human "
        "ML engineer could do [@honnibal]. **Novelty.** The Experiment 8 procedure is the established steering and "
        "abliteration playbook: contrast failing and healthy activations, estimate a direction, rank the weights that "
        "write along it, subtract, test [@goedecke,arditi]. Goedecke also shows that a three-line norm heatmap makes "
        "most of Experiment 1 visually obvious because the input channels are labelled [@goedecke]. **Cost.** The "
        "editor spent 158 turns and 20.3 hours on Experiment 8; a scripted pipeline with no LLM re-derived a similar "
        "edit in about five CPU minutes and sixteen forward passes, reaching roughly 75% of the loop suppression "
        "[@wspacetest]. None of this makes the result false. It makes the frontier LLM one component, a hypothesis "
        "proposer, inside a harness whose measuring and editing are ordinary engineering.")

    d.h3("2.5 The two controls that decide the THOX question")
    d.p("Two comparisons matter more for THOX than any other number in this debate. The **Gemma control**: the same "
        "procedure applied to Gemma 3 270M, a model that rarely loops (8.5% cap hits), moved MATH-500 from 6.8% to at "
        "most 7.7%, which the authors themselves report as not established [@logs]. Editing removed an obstacle that "
        "hid an ability; it could not add an ability the model lacked. The **decoding control**: the OpenWSP "
        "repository reports the unedited model at 46.8% on MATH-500 with thinking disabled (0.6% cap hits) against "
        "50.6% for the released edit, with one sample per problem [@openwsp]. When v1.0.0 was written the table was not "
        "visible; at the pinned commit it is in the README and the status files, but it remains a third-party number "
        "under its own settings. " + ("Section 5 replaces it with a THOX measurement." if L1 else
        "Section 5 specifies the THOX measurement that replaces it."))

    d.h3("2.6 Claim tiers used in this paper")
    d.table("tiers", ["Tier", "Meaning", "Examples here"], [
        ["Author-reported", "Stated by Takehi et al. or in their released files; not independently re-run",
         "Exp 4 success rate; Exp 8 GSM8K, IFEval and the other benchmarks in {fig:src}"],
        ["Independently reproduced", "Re-run or rebuilt by a party other than the authors, THOX included",
         "Exp 8 edit identity (E0, E0-R); Exp 5 and 6 scores; Exp 8 MATH-500 for the edit (L1)"],
        ["Contested or third-party", "Disputed framing, or a number THOX did not produce",
         "OpenWSP decoding table; cross-model Breakout chart (read from an image by press coverage)"],
        ["THOX-measured", "Produced by Sections 4 and 5 on named THOX-controlled hosts", "E1 to E4, E0-R, P1, L1, patch-channel tests"],
    ], "Evidence tiers. The tier travels with the number wherever this paper repeats it.", widths=[1.4, 2.6, 3.4])

    # ---------------- 3 Definitions
    d.h2("3", "Definitions and method", "s3")
    d.p("**Weight-Space Programming (WSP)** is the source post's term for a general-purpose LLM reading and writing a "
        "network's weights directly, not through an optimizer and in particular not with gradient descent, around a "
        "natural-language specification [@src]. **Read, fix, write** are its three task classes: infer behaviour from "
        "weights (Experiments 1 to 3, 7), edit a failing network (4, 8), create weights from zero (5, 6). A "
        "**forward pass**, in the source harness, is a budgeted batch of executions (up to 512 generations in "
        "Experiment 8), not a single example. A **rank-1 patch** is a weight edit of the Experiment 8 shape: for a "
        "tensor $$W \\in \\mathbb{R}^{d \\times n}$$, a unit direction $$u \\in \\mathbb{R}^{d}$$, a column set $$C$$ and "
        "a scalar $$\\alpha$$,")
    d.eq("W'_{:,j} \\;=\\; \\begin{cases} W_{:,j} - \\alpha\\, u\\,\\big(u^{\\top} W_{:,j}\\big) & j \\in C \\\\[2pt] "
         "W_{:,j} & j \\notin C \\end{cases}", "1")
    d.p(f"For Experiment 8, $$d = 1{{,}}024$$, $$|C| = 64$$ per tensor and $$\\alpha = 6$$ as stated in the editor's "
        f"report; E0-R estimates $$\\alpha$$ from the released diff as {t15['alpha_estimated']:.4f} and "
        f"{t19['alpha_estimated']:.4f}. A **loop**, throughout this paper, is detected causally on whitespace words "
        "$$w_0, w_1, \\ldots$$ with 8-grams $$g_i = (w_i, \\ldots, w_{i+7})$$:")
    d.eq("\\mathrm{loop} \\iff \\exists\\, t:\\; \\sum_{i=t}^{t+299} \\mathbb{1}\\big[g_i \\in \\{g_0, \\ldots, "
         "g_{i-1}\\}\\big] \\;\\ge\\; 270", "2")
    d.p("which is the test of the independent CPU re-check [@wspacetest]. The first qualifying window's start $$t$$ is "
        "the **loop onset**; because the test is causal, it is the point a streaming detector would rewind to. The "
        "source authors' own end-of-text period test is recorded alongside it.")
    d.p("**Evidence classes** follow the THOX research paper standard: MEASURED (run on a named host), CALCULATED "
        "(arithmetic from stated inputs), SIMULATED (run inside a simulated environment). Nothing measured on a "
        "general host is stated as a device result. Method discipline: every headline number is produced by a script "
        "in the artifact bundle and read from an evidence file (Section 11); failed iterations are preserved and "
        "reported; each experiment carries at least one control.")
    d.h3("Lineage: where WSP sits")
    d.p("WSP is best understood as an untrained entrant into four established lines of work. **Trained readers** have "
        "read properties and accuracy from weights using networks trained for the job on thousands of checkpoints "
        "[@eilertsen,unterthiner]; permutation-equivariant architectures make such readers respect the symmetries of "
        "weight space [@dwsnet,nfn], and the weight-space learning survey now taxonomises the field [@survey]. Spectral "
        "work finds shared low-dimensional subspaces across large model populations, a candidate explanation for why "
        "directional edits work at all, though its interpretation is contested [@kaushik]. **Trained writers** "
        "generate weights from networks trained for the job, from HyperNetworks [@ha] through checkpoint-generating "
        "diffusion [@peebles] to hypernetworks that write a LoRA adapter from a task description in one forward pass "
        "[@t2l,zhyper]. **Algorithmic editors** write weights by formula: ROME and MEMIT locate factual recall in "
        "mid-layer MLPs and rewrite it with rank-one updates [@rome,memit], though where an effect localises does not "
        "reliably predict where editing works [@hase]; representation engineering and the refusal-direction result "
        "established that behaviours can live in single residual-stream directions that weight edits remove "
        "[@repe,arditi]. Experiment 8's edit is a member of this family whose target and formula were chosen by a "
        "reasoning model. **Weight arithmetic** supplies the delta object everything operates on: low-rank deltas "
        "[@lora], model soups [@soups], task vectors [@taskarith], and merging methods that exist because naive "
        "arithmetic interferes [@ties,dare]. Underneath the reading claims sits mechanistic interpretability, the QK "
        "and OV circuit account that Experiment 3's editor independently reinvented [@elhage,olsson], and Tracr's proof "
        "that programs compile into transformer weights, the precedent for Experiments 5 and 6 [@tracr]. The paradigm "
        "claim extends LLM-as-optimizer work from prompts and programs to weights [@opro]. On the decoding side, the "
        "controls of Section 5 descend from the degeneration literature [@holtzman] and from thinking-budget "
        "interventions [@qwen3,s1].")

    # ---------------- 4 Recreation
    d.h2("4", "THOX recreation experiments", "s4")
    d.p(f"Sections 4.1 to 4.4 are carried unchanged from v{PREV[0]}, where they were run on the THOX build VM (CPU) on "
        f"{PREV[1]} with NumPy and PyTorch [@v100]. Their numbers enter this edition through "
        "`carried_v1_0_0.json`, which records each value with the sentence it appears in and fails the build if the "
        "sentence is absent from the v1.0.0 text. The reader, writer and editor in these experiments were deterministic "
        "tools, not a frontier API model: what is tested is whether the weight-space structure the source exploits "
        "exists and is usable by THOX tooling.")
    d.h3("4.1 E1, Read: the task signature lives in the composed per-class circuit")
    acc = cv("E1", "reader_acc")
    d.p(f"Thirty multilayer perceptrons (64-48-4) were trained on three tasks over 8&times;8 one-dot grids: name the "
        "dot's column, its row, or its diagonal class; 10 seeds per task, every network at 100% task accuracy. Four "
        "weights-only readers then attempted identification with no forward passes. R1 aggregates $$|W_1|$$ into one "
        "input map; R2 lets each hidden unit vote; R3 composes the layers once into $$E = W_2^{\\top} W_1^{\\top}$$ "
        "summed over classes; R4 composes per output class and lets each class map vote. R1, R2 and R3 score exactly "
        f"chance ({acc['R1']:.1f}%) because they misread every column and row network as diagonal; R4 scores "
        f"{acc['R4']:.0f}%, with its permutation control at chance ({{fig:e1}}). What a small network computes is "
        "legible in its composed per-class circuits and largely illegible in its layer-1 marginals.")
    d.figure("e1", "fig2_e1_readers.svg", "E1: four weights-only readers on 30 trained networks; only the per-class "
             "composed reader identifies the task. Carried from v1.0.0.", "Measured, THOX build VM")
    d.h3("4.2 E2, Write: a hand-written network matches an oracle-trained one")
    e2 = CARRIED["E2"]
    d.p("Experiment 5's claim reduces to a compilation claim: if the solution is a short program, weights can encode it "
        "directly. On a control task with a known program, predicting where a ball bouncing in a unit box lands, the "
        "written network implements the reflection construction by hand, with zero gradient steps; its landing "
        f"predictions are exact to float64 precision (maximum error {e2['max_target_error']['value']:.1e}). As a "
        f"paddle controller it catches {e2['written_catch_standard']['value']:.0f}% of balls in the standard regime and "
        f"{e2['written_catch_hard']['value']:.1f}% in a hard regime. Twenty random-weight networks average "
        f"{e2['random_mean']['value']:.1f}% (best {e2['random_best']['value']:.1f}%); a gradient-trained oracle given "
        f"{num(e2['oracle_steps']['value'])} steps on {num(e2['oracle_examples']['value'])} labelled examples reaches "
        "the identical catch profile with a small landing error ({fig:e2}). Both controllers fail on the same balls: "
        "they are paddle-limited, not prediction-limited.")
    d.figure("e2", "fig3_e2_written.svg", "E2: written, oracle-trained and random networks on the ball-landing control "
             "task. Carried from v1.0.0.", "Measured, task simulation")
    d.h3("4.3 E3, Fix: sixteen weights repair a policy stuck at zero")
    e3 = CARRIED["E3"]
    d.p(f"A {e3['params']['value']}-parameter MountainCar policy (2-24-24-3) imitation-trained on an always-push-right "
        "expert succeeds 0% of the time: it never builds energy by rocking. The designed fix repurposes two little-used "
        "first-layer units as velocity detectors, adds an energy-pumping override pathway and gives the output enough "
        f"gain to win when the car is slow. It touches {e3['edited_weights']['value']} of {e3['params']['value']} "
        f"weights ({e3['edited_share_pct']['value']}%) and raises success to {e3['success_512']['value']}% over 512 "
        "episodes; a random edit of the same size scores 0% at every gain, and sweeping the override gain gives a "
        f"clean dose-response ({{fig:e3}}). A first attempt that changed {e3['failed_first_edit_weights']['value']} "
        "weights left success at 0% and is preserved in the findings log. The transferable claim is the shape "
        "(diagnose a single locus, add a pathway, verify against a same-size random control), not the fraction.")
    d.figure("e3", "fig4_e3_dose.svg", "E3: MountainCar success against override gain for the 16-weight edit, 256 "
             "episodes per point. Carried from v1.0.0.", "Simulated environment, THOX build VM")
    d.h3("4.4 E4, Audit: a negative result, reported in full")
    e4 = CARRIED["E4"]
    d.p(f"The Experiment 3 audit shape was attempted on a small transformer (2 layers, 4 heads, d=64, "
        f"{num(e4['params']['value'])} parameters) trained on sequences with a planted repeated bigram. The "
        f"weights-only scores ranked a candidate induction head (composition score {e4['top_composition_score']['value']} "
        f"against a 0.05 to 0.39 spread). The ground truth failed: after {num(e4['steps']['value'])} steps the loss on "
        f"repeat positions was {e4['repeat_loss']['value']} against {e4['other_loss']['value']} elsewhere, the "
        "ln(24) floor of an unpredictable token; attention at repeat positions was uniform across heads; ablating any "
        f"single head moved repeat loss by at most {e4['max_ablation_delta']['value']}. No induction behaviour formed, "
        f"so there was no head to find, and the weights-only ranking (Spearman {e4['spearman']['value']:.2f} against a "
        "noise floor) is evidence of nothing. A weight-only audit tool always produces a ranking; whether the ranking "
        "means anything depends on the behaviour existing, which can only be established behaviourally.")

    d.h3("4.5 E0-R and P1: the released edit, re-verified, and what it takes to ship it")
    tab_pf = d.reserve_tab("pf")
    d.p(f"v{PREV[0]} verified the released Experiment 8 edit on the THOX build VM (E0). This edition repeats the check "
        "independently on a second host with a different method (E0-R): HTTP range reads of only the four tensors "
        "involved, SHA-256 against the authors' edit manifest, and a rebuild from the authors' sparse diff. All checks "
        f"pass. The base tensors hash to the manifest's base values; the released tensors hash to "
        f"`{t15['edited_sha256'][:12]}...` and `{t19['edited_sha256'][:12]}...`; rebuilding from `edit.npz` is "
        f"bit-identical; {num(t15['changed_entries'])} and {num(t19['changed_entries'])} entries differ, "
        f"{num(changed_total)} in total; singular-value ratios are {t15['sigma1_over_sigma2']:,.0f} and "
        f"{t19['sigma1_over_sigma2']:,.0f}, with {t15['energy_rank1'] * 100:.4f}% and "
        f"{t19['energy_rank1'] * 100:.4f}% of the diff energy in the first direction.")
    d.p(f"P1 then asks how this edit would travel through the THOX patch channel ({{tab:pf}}, {{fig:pf}}). The "
        f"authors released it in sparse form: {num(changed_total)} (index, value) pairs, {kb(npz)} as compressed "
        f"`edit.npz`. The factor form of Equation (1) is smaller by two orders of magnitude, but a factor estimated from "
        f"the released diff is not exact: in every precision tried, applying it reproduces "
        f"{pct(1 - fac15['mismatch_share_of_changed'])} and {pct(1 - fac19['mismatch_share_of_changed'])} of the "
        f"changed entries bit-for-bit, and the remaining {num(resid)} each differ by one bfloat16 rounding step "
        f"(maximum absolute error {fac15['max_abs_error']:.2e}, {pct(fac15['max_abs_error_over_max_abs_diff'], 2)} "
        "of the largest diff entry). Rounding the direction to bfloat16 roughly doubles the mismatches. An exact patch "
        f"therefore ships the factor plus a sparse residual: {kb(exact_patch)} for both tensors, "
        f"{sparse_raw / exact_patch:.0f}x below the raw sparse diff, {npz / exact_patch:.1f}x below the released "
        f"compressed file and {full / exact_patch:,.0f}x below the two full tensors. When THOX produces an edit itself, "
        "the editor's own direction is available at edit time and the residual is empty by construction; the result "
        "hashes make the distinction checkable either way.")
    d.table("pf", ["Representation", "Contents", "Bytes (both tensors)", "Exact", "Class"], [
        ["Full edited tensors", "Two 1,024 &times; 3,584 bfloat16 tensors", kb(full), "yes", "Calculated"],
        ["Sparse diff, raw", f"{num(changed_total)} &times; (4-byte index, 2-byte value)", kb(sparse_raw), "yes", "Calculated"],
        ["Released edit.npz", "Authors' compressed sparse form", kb(npz), "yes", "Measured (file)"],
        ["Factor + residual", f"u float32, 64 int16 columns, alpha; {num(resid)} residual entries", kb(exact_patch),
         "yes", "Measured (E0-R)"],
        ["Factor only, float32 u", "u float32, 64 int16 columns, alpha", kb(factor32),
         f"no: {pct(resid / changed_total)} of changed entries off by one step", "Measured (E0-R)"],
        ["Full model re-issue", "ThoxEdge-0.8B Q4_K_M GGUF", "529.3 MB", "yes", "Model card [@thoxedge]"],
    ], "Patch representations for the Experiment 8 edit. Exactness is checked against the released tensors' SHA-256.",
        widths=[1.7, 3.0, 1.3, 1.6, 1.2], cls="small")
    d.figure("pf", "fig5_patch_forms.svg", "P1: bytes needed to move the Experiment 8 edit, log scale. The light green "
             "bar is not bit-exact and would fail the loader's result-hash check.", "Measured, cloud workspace")

    # ---------------- 5 Decoding control
    build_section5(d)

    # ---------------- 6 Patch channel
    d.h2("6", "The THOX patch channel", "s6")
    d.h3("6.1 Patch anatomy, corrected")
    d.p("v1.0.0 sized the Experiment 8 patch with a bfloat16 direction (about 4.4 KB) while specifying a float32 wire "
        "form, and called factor form three orders of magnitude below the sparse diff. Both are corrected here from "
        f"the P1 measurement. The factor costs $$4d + 2|C| + 8$$ bytes per tensor ({kb(factor32 // 2)} for $$d = 1{{,}}024$$, "
        f"$$|C| = 64$$), or twice the direction's share as hex on the wire; it sits about {sparse_raw / factor32:.0f}x "
        "below the raw sparse diff, two orders of magnitude, not three. For an edit received as a sparse diff, exactness "
        "needs the residual of Section 4.5, giving")
    d.eq("|P| \\;=\\; \\sum_{\\text{tensors}} \\big(4d + 2|C| + 8 + 6r\\big)", "3")
    d.p(f"bytes, with $$r$$ residual entries at a 4-byte index and a 2-byte value. For Experiment 8 that is "
        f"{kb(exact_patch)}. The manifest records the SHA-256 of every resulting tensor, and the loader verifies the "
        "hashes after applying and before switching; a patch that does not reproduce bit-exactly does not activate.")
    d.h3("6.2 Manifest, signing, loader")
    d.p("The patch manifest (schema `thox-wsp/patch-manifest/v1`) is the signed contract between the editing "
        "environment and the device. It pins the base (repository, revision, per-tensor SHA-256), lists operations "
        "(rank-1 factor form, optional sparse residual), records the expected result hashes, the evaluation report "
        "hash, editor provenance (model identifier, effort, transcript hash) and the licence notices for base and "
        "patch. The release key signs it with Ed25519 [@rfc8032] and lives outside the editing environment, so a "
        "compromised or over-eager editor cannot issue a patch a device will accept. One implementation lesson from "
        "v1.0.0 stands: Python and Rust disagree in the last digit of some float formatting, so the signed wire form "
        "carries numbers as hex of their little-endian bytes, never as JSON decimals. Sign bit patterns, never text "
        "representations of numbers.")
    d.code("Patch lifecycle (loader-enforced)",
           "1 READ        fingerprint base: repo, revision, per-tensor sha256\n"
           "2 DIAGNOSE    failure hypothesis + contrast sets; baseline rates recorded\n"
           "3 EDIT        rank-1 ops (tensor, u, cols, alpha) + optional sparse residual + result hashes\n"
           "4 VERIFY      deterministic rebuild; failure gate; decoding-control gate (Section 8);\n"
           "              retention gate; safety gate; quantised-artifact gate; human diff review\n"
           "5 SIGN        Ed25519 over the canonical manifest; key held outside the editor\n"
           "6 DISTRIBUTE  staged rollout; device verifies signature + base hashes,\n"
           "              applies to the inactive slot, checks result hashes, smoke-tests,\n"
           "              switches atomically or rolls back")
    pc = CARRIED["patch_channel"]
    d.h3("6.3 Verification status")
    d.table("pcv", ["Check", "Result"], [
        ["Rust unit tests (bf16 round-trip, rank-1 apply against the Python test vector, SHA-256 known vector)",
         pc["rust_unit_tests"]["value"]],
        ["End-to-end: Python toolkit fingerprints, builds and signs a manifest; Rust loader verifies, applies to slot B",
         "Pass; applied tensor bit-identical to the Python reference"],
        ["Rollback", "Pass; active slot returns to A"],
        ["Tampered manifest (alpha altered after signing)", "Correctly rejected: signature verification failed"],
        ["Wrong base tensor in slot A", "Correctly aborted: base hash mismatch, no switch"],
        ["Sparse-residual operation (new in v1.1.0 schema)", "Specified; not yet implemented in the loader"],
        ["Production patch issued through the channel", "None"],
    ], f"Patch channel verification ({pc['toolkit_version']['value']}), carried from v1.0.0 and run on the THOX build "
       "VM on 2026-11-03, plus the v1.1.0 schema addition.", widths=[5, 2.4])
    d.p("The channel is delta-agnostic: a LoRA merge or a distillation delta is a base pin plus operations plus result "
        "hashes, so the signing, distribution and rollback machinery serves THOX's existing model pipeline even if no "
        "WSP patch is ever issued.")

    # ---------------- 7 Application
    build_section7(d)

    # ---------------- 8 Gated program
    build_section8(d)

    # ---------------- 9 Limitations
    build_section9(d)

    # ---------------- 10 Conclusion
    d.h2("10", "Conclusion", "s10")
    concl = ("Weight-Space Programming, read carefully, is three results of different strengths wearing one name. "
             "Writing small networks whose solutions are short programs is real, reproducible and immediately useful to "
             "a device fleet. Reading weights is real where the read composes circuits and imaginary where it inspects "
             "marginals. Fixing a real model is real exactly once, on a failure with a single locus, verified "
             "bit-exactly by THOX twice. ")
    if have_l1:
        pr = l1pair("edit_on", "base_off")
        concl += (f"This edition measured the cheaper explanation the whole question turned on: turning thinking off "
                  f"scores {pct(base_off['acc'])} on MATH-500 against {pct(edit_on['acc'])} for the released edit "
                  f"with thinking on, a paired difference of {pts(pr['diff'])} ({ci_txt(pr)}). ")
    if not have_l1:
        concl += ("The cheaper explanation the whole question turns on, turning thinking off, is specified here with a "
                  "pre-registered decision rule but was not measured in this edition. ")
    concl += ("THOX's response is sized to that evidence: ship the decoding defences and measured serving "
              "configurations, keep the baselines, build the signed channel that every future delta will use, and let "
              "weight patching earn its place against the controls, in the open, at the bars in Section 8.")
    d.p(concl)

    # ---------------- 11 Provenance
    build_section11(d)

    # ---------------- References
    d.add('<h2 id="refs"><span class="secno">R</span>References</h2><ol class="refs">')
    listed = set(d.cite_order)
    for i, k in enumerate(d.cite_order, 1):
        text, url = ref_entry(k)
        link = f' <a href="{html.escape(url)}">{html.escape(url)}</a>' if url else ""
        d.add(f'<li id="ref-{k}"><span class="refno">[{i}]</span> {html.escape(text)}{link}</li>')
    d.add("</ol>")
    unused = [k for k in list(REF_TABLE) + list(EXTRA_REFS) if k not in listed]
    return unused


def S5_TITLE():
    return "The decoding control, measured" if L1 else "The decoding control: protocol and decision rule"


def build_section5(d: Doc):
    d.h2("5", S5_TITLE(), "s5")
    if not L1:
        d.callout("Measurement status", L1_STATUS + " This edition therefore states no Section 5 measurement. The "
                  "protocol below is fixed, the job script is versioned in the artifact bundle and in the private "
                  "results dataset [@evals], and the decision rule in Section 5.2 is pre-registered, so the next run "
                  "can only confirm or refute it.", "warn")
    d.p("Section 2.5 reduced the THOX question to one comparison: against a serving configuration that already "
        "avoids the loop, what is left for a weight patch to fix? L1 " + ("measures" if L1 else "is built to measure") +
        " it on infrastructure THOX controls, at "
        "full benchmark scale, with the source's own grading.")
    d.h3("5.1 Protocol")
    cfgs = L1["configs"] if L1 else {}
    rows = []
    for key, label in [("base_on", "Qwen3.5-0.8B, thinking on"), ("edit_on", "Released edit, thinking on"),
                       ("base_off", "Qwen3.5-0.8B, thinking off"), ("edit_off", "Released edit, thinking off"),
                       ("base_off_greedy", "Qwen3.5-0.8B, thinking off, greedy"),
                       ("edit_off_greedy", "Released edit, thinking off, greedy"),
                       ("thoxedge_greedy", "ThoxEdge-0.8B, greedy, no system prompt"),
                       ("thoxedge_gated", "ThoxEdge-0.8B, served configuration"),
                       ("thoxedge_off", "ThoxEdge-0.8B, thinking off, card sampling"),
                       ("micro125_greedy", "thox-micro-125m-instruct, greedy")]:
        c = cfgs.get(key)
        sp = {"base_on": "T 0.6, top-p 0.95, top-k 20, presence 1.5; 32,768", "edit_on": "same as above",
              "base_off": "T 0.7, top-p 0.8, top-k 20, presence 1.5; 8,192", "edit_off": "same as above",
              "base_off_greedy": "greedy; 8,192", "edit_off_greedy": "greedy; 8,192",
              "thoxedge_greedy": "greedy; 8,192", "thoxedge_gated": "greedy, grounding prompt; 2,048 (4,096 context)",
              "thoxedge_off": "T 0.7, top-p 0.8, top-k 20, presence 1.5; 8,192",
              "micro125_greedy": "greedy; 512 (1,024 context)"}[key]
        planned = {"base_off": 4, "edit_off": 4, "thoxedge_off": 4}.get(key, 1)
        rows.append([label, sp, str(c["samples_per_problem"]) if c else str(planned),
                     num(c["n_gens"]) if c else f"{num(500 * planned)} planned"])
    d.table("l1cfg", ["Configuration", "Sampling; max new tokens", "Samples per problem", "Generations"], rows,
            "L1 configurations on MATH-500 (500 problems, HuggingFaceH4/MATH-500 at revision 6e4ed1a). Thinking-on "
            "rows use the source's Experiment 8 profile; thinking-off rows use the Qwen3.5 card's non-thinking "
            "setting as encoded in the source's evaluation script; greedy rows match ThoxEdge's served Modelfile.",
            widths=[2.6, 3.2, 1.0, 1.0], cls="small")
    d.p("Prompts, answer extraction and checking follow the source exactly [@logs]: the problem plus 'Please reason "
        "step by step, and put your final answer within \\boxed{}.', the last boxed answer after the last closing "
        "think tag, and math-verify 0.9.0 equivalence [@mathverify]. MATH-500 is the Lightman et al. subset of MATH "
        "[@lightman,hendrycks]. Generation runs with vLLM 0.33.0 [@vllm] on Hugging Face Jobs (NVIDIA H200 for "
        "the thinking-on runs, A100 80 GB for the rest), bfloat16, seed 0. Accuracy is the mean over samples, with the "
        "standard error over problems; paired differences use 10,000 bootstrap resamples over problems. Two "
        "decoding-only defences are applied to the thinking-on generations themselves, which is valid because "
        "generation is causal: every prefix is exactly what the defended stream would have produced. The **budget** "
        "defence truncates thinking at 4,096 or 8,192 tokens and appends the Qwen3 stop-thinking instruction "
        "[@qwen3]; the **interrupt** defence rewinds to the loop onset of Equation (2) and appends the same "
        "instruction. Only the forced answer (at most 4,096 tokens) is generated anew.")
    if not L1:
        d.p("Before launch, the non-GPU parts of the pipeline were checked on the build host: the loop metric against "
            "nine unit tests (onset correctness, causality under truncation, threshold boundary, argument validation), "
            "the vendored grading against known answers, prompt construction against all four tokenizers, the "
            "token-index mapping used by the interrupt defence, and the analysis script against synthetic data in the "
            "output format. The GPU stage itself has not completed.")
        d.h3("5.2 Pre-registered decision rule")
        d.p("Let $$\\Delta$$ be the paired problem-level MATH-500 difference between the released edit with thinking on "
            "and the unedited base with thinking off, with its 95% bootstrap interval $$[\\Delta_{lo}, \\Delta_{hi}]$$. "
            "The outcome is read as follows, before any data exist:")
        d.bullets([
            "**Edit adds value**: $$\\Delta_{lo} > +2$$ points. A loop patch has a real gap to aim at; the Section 8 "
            "bar stands as written.",
            "**Equivalent**: the whole interval lies within &plusmn;2 points. The headline gain is available with "
            "no weight change; no loop patch is justified by this benchmark.",
            "**Inconclusive**: any other interval. More samples per problem are run before anything is decided.",
            "**Decoding dominates**: $$\\Delta_{hi} < -2$$ points. Turning thinking off beats the edit; a loop patch "
            "has nothing to add for a model served thinking-off.",
            "**ThoxEdge-0.8B**: if its served configuration (grounding prompt, greedy, thinking off) loops on fewer "
            "than 2% of MATH-500 problems, no ThoxEdge loop patch enters the program; above that, the loop rate is "
            "the baseline a patch must cut, with no retention loss.",
        ])
        d.p("Until the run completes, the only measurement of this comparison is third-party: 46.8% thinking-off "
            "against 50.6% for the released edit with one sample per problem [@openwsp]. At that sample size its "
            "interval would be several points wide, so under the rule above it does not settle the question, and "
            "this paper does not adopt a number it did not produce.")
        return
    base_on, edit_on, base_off, edit_off = (l1c(k) for k in ("base_on", "edit_on", "base_off", "edit_off"))
    d.h3("5.2 Result: thinking off recovers what the edit recovers")
    rows = []
    for key in ("base_on", "base_on+budget4096", "base_on+budget8192", "base_on+interrupt", "base_off",
                "base_off_greedy", "edit_on", "edit_on+interrupt", "edit_off", "edit_off_greedy"):
        c = l1c(key)
        if not c:
            continue
        label = c.get("label", key)
        if key in L1["defences"]:
            label = {"base_on+budget4096": "Base, thinking on + budget 4,096",
                     "base_on+budget8192": "Base, thinking on + budget 8,192",
                     "base_on+interrupt": "Base, thinking on + loop interrupt",
                     "edit_on+interrupt": "Edit, thinking on + loop interrupt"}.get(key, key)
            rows.append([label, f"{pct(c['acc'])} &plusmn; {c['acc_se'] * 100:.1f}", "&ndash;", "&ndash;",
                         f"{c['tokens_mean'] / 1e3:.1f}k", f"{c['tokens_per_correct'] / 1e3:.1f}k"])
        else:
            rows.append([label, f"{pct(c['acc'])} &plusmn; {c['acc_se'] * 100:.1f}", pct(c["cap_share"]),
                         pct(c["loop_share"]), f"{c['tokens_mean'] / 1e3:.1f}k", f"{c['tokens_per_correct'] / 1e3:.1f}k"])
    d.table("l1res", ["Configuration", "MATH-500 (&plusmn; SE)", "Cap hit", "Loops", "Mean tokens", "Tokens / correct"],
            rows, "L1 results. Cap hit: generation reached its token limit. Loops: Equation (2) fired anywhere in "
            "the output. Defence rows reuse the same generations; tokens include the kept prefix and the forced answer.",
            widths=[3.0, 1.4, 0.9, 0.9, 1.0, 1.1], cls="small")
    p_off_on = l1pair("base_off", "base_on")
    p_edit_off = l1pair("edit_on", "base_off")
    p_edit_on = l1pair("edit_on", "base_on")
    d.p(f"With thinking on, the base model reaches the cap on {pct(base_on['cap_share'])} of problems, loops on "
        f"{pct(base_on['loop_share'])} by Equation (2), and scores {pct(base_on['acc'])}, in line with the authors' "
        f"{SRC_BASE['math500']['acc'] * 100:.1f}% over four samples. The released edit scores {pct(edit_on['acc'])} "
        f"with {pct(edit_on['cap_share'])} cap hits, reproducing the authors' {SRC_EDIT['math500']['acc'] * 100:.1f}% "
        f"and the Hugging Face re-run's 51.0% ({pts(p_edit_on['diff'])} over the base, {ci_txt(p_edit_on)}). Turning "
        f"thinking off with no weight change scores {pct(base_off['acc'])} with {pct(base_off['cap_share'])} cap hits "
        f"({pts(p_off_on['diff'])} over thinking on, {ci_txt(p_off_on)}). The edit with thinking on against the base "
        f"with thinking off differs by {pts(p_edit_off['diff'])} ({ci_txt(p_edit_off)}); the edit is better on "
        f"{p_edit_off['problems_better']} problems and worse on {p_edit_off['problems_worse']}.")
    verdict = _edit_verdict(p_edit_off)
    d.callout("What this settles", verdict)
    if edit_off:
        p_eo = l1pair("edit_off", "base_off")
        d.p(f"With thinking off, the edit scores {pct(edit_off['acc'])} against the base's {pct(base_off['acc'])} "
            f"({pts(p_eo['diff'])}, {ci_txt(p_eo)}). This is the comparison that matters for a model served "
            "thinking-off, like ThoxEdge-0.8B.")
    d.figure("l1", "fig6_l1_accuracy.svg", "L1: MATH-500 accuracy by configuration with 95% intervals (1.96 SE over "
             "problems); amber labels give the share of generations that reached the token cap. Green: no weight "
             "change or THOX's own model; ink: the released edit; grey: the base with thinking on.",
             "Measured, Hugging Face Jobs")
    d.h3("5.3 Decoding-only defences")
    b4, b8, it = l1c("base_on+budget4096"), l1c("base_on+budget8192"), l1c("base_on+interrupt")
    if b4 and it:
        p_it = l1pair("base_on+interrupt", "base_on")
        p_b4 = l1pair("base_on+budget4096", "base_on")
        p_e_it = l1pair("edit_on", "base_on+interrupt")
        d.p(f"Applied to the same base generations, the loop interrupt forces an answer on {num(it['forced'])} of 500 "
            f"problems and scores {pct(it['acc'])} ({pts(p_it['diff'])} over unprotected thinking, {ci_txt(p_it)}); "
            f"a 4,096-token thinking budget forces {num(b4['forced'])} answers and scores {pct(b4['acc'])} "
            f"({pts(p_b4['diff'])}, {ci_txt(p_b4)})"
            + (f"; an 8,192-token budget scores {pct(b8['acc'])}" if b8 else "") +
            f". The released edit with thinking on still differs from the interrupt-defended base by "
            f"{pts(p_e_it['diff'])} ({ci_txt(p_e_it)}). Forced answers are short: the defences need "
            f"{it['tokens_per_correct'] / 1e3:.1f}k and {b4['tokens_per_correct'] / 1e3:.1f}k generated tokens per "
            f"correct answer against {base_on['tokens_per_correct'] / 1e3:.1f}k for unprotected thinking "
            "({fig:cost}).")
    d.figure("cost", "fig7_l1_cost.svg", "L1: accuracy against generated tokens per correct answer. Configurations "
             "to the upper left are both more accurate and cheaper to serve.", "Measured, Hugging Face Jobs")
    d.h3("5.4 THOX models")
    te, tg, mi = l1c("thoxedge_greedy"), l1c("thoxedge_gated"), l1c("micro125_greedy")
    if te:
        bog = l1c("base_off_greedy")
        p_te = l1pair("thoxedge_greedy", "base_off_greedy")
        txt = (f"ThoxEdge-0.8B is served thinking-off and greedy [@thoxedge]. Bare (no system prompt), it loops on "
               f"{pct(te['loop_share'])} of MATH-500 problems, hits the cap on {pct(te['cap_share'])} and scores "
               f"{pct(te['acc'])}, against {pct(bog['acc'])} for its base under the same greedy decoding "
               f"({pts(p_te['diff'])}, {ci_txt(p_te)}).")
        if tg:
            txt += (f" In its served configuration (grounding system prompt, greedy, 4,096-token context) it loops on "
                    f"{pct(tg['loop_share'])} and scores {pct(tg['acc'])}.")
        txt += (" MATH-500 is a stress workload for this model, not its job: ThoxEdge is a facts-and-behaviour skin "
                "evaluated by GATE49. What transfers is the loop rate under the deployed decoding, which is the "
                "baseline any ThoxEdge weight patch would have to improve.")
        d.p(txt)
    if mi:
        d.p(f"thox-micro-125m-instruct, THOX's from-scratch 123M-parameter model [@micro], is outside its competence on "
            f"MATH-500 ({pct(mi['acc'])}) and is measured for loop behaviour only: under greedy decoding with a "
            f"512-token cap it loops on {pct(mi['loop_share'])} of problems and reaches the cap on "
            f"{pct(mi['cap_share'])}. That is the first loop baseline for an in-house THOX model.")
    d.h3("5.5 What this does not settle")
    d.p("L1 is one benchmark, one sampling seed per configuration, and decoding settings taken from the source and "
        "the model card rather than tuned. It does not test the vendor's recommended thinking-mode text profile "
        "(temperature 1.0), retention on non-math tasks, or quantised artifacts. It also does not test whether a "
        "THOX-derived patch could beat the controls; it sets the bar such a patch must clear.")


def _edit_verdict(p):
    diff, (lo, hi) = p["diff"], p["ci95"]
    if lo > 0.02:
        return (f"The released weight edit beats the best no-weight-change configuration measured here by "
                f"{pts(diff)} ({ci_txt(p)}), more than the two-point practical margin. A THOX patch would have a real "
                "gap to aim at, and the Section 8 bar stands as written.")
    if hi < -0.02:
        return (f"Turning thinking off beats the released weight edit by {pts(-diff)} ({ci_txt(p)}). On MATH-500, "
                "the decoding control dominates the edit; a loop patch has nothing to add for a model served "
                "thinking-off.")
    if not (lo >= -0.02 and hi <= 0.02):
        return (f"The comparison is inconclusive at this sample size (difference {pts(diff)}, {ci_txt(p)}): neither "
                "the edit nor the decoding control is established as better by the two-point margin.")
    return (f"The released weight edit and simply turning thinking off are equivalent within two points on "
            f"MATH-500 (difference {pts(diff)}, {ci_txt(p)}). Nearly all of the headline gain is available with no "
            "weight change, which is how THOX already serves ThoxEdge-0.8B. A weight patch for this failure is not "
            "justified by this benchmark.")


def build_section7(d: Doc):
    d.h2("7", "Application to THOX device models", "s7")
    d.p("Facts in this section come from the THOX model catalog and model cards [@catalog,thoxedge]. ThoxEdge-0.8B is "
        "the centre of the WSP question for a simple reason: it is a merged QLoRA derivative of Qwen/Qwen3.5-0.8B, the "
        "Experiment 8 base, published after passing GATE49 at 46 of 49 on its development set, and it is served "
        "thinking-off at temperature 0 with a grounding system prompt. Its card records thinking-mode behaviour as out "
        "of contract and names its known residual defect: two prefill no-decline hard failures, which are not loop "
        "defects. Under the Gemma-control logic a loop patch for ThoxEdge-0.8B is "
        "expected to do approximately nothing, and proposing one anyway is the kind of claim this paper exists to "
        "prevent.")
    d.table("map", ["Surface", "Role in the WSP program"], [
        ["ThoxWork&trade;", "Patch workbench: read, diagnose and edit sessions with a frontier editor; diff review, "
                             "approval and signing. Editor transcripts stored with the patch."],
        ["MeshStack&trade;", "Patch registry and distribution: metadata, signatures, eligibility, staged rollout and "
                              "per-device verification receipts. Kilobyte-scale patches fit mesh transfer; full models "
                              "do not [@meshstack]."],
        ["ThoxOS&trade; and ThoxMind", "The Rust loader of Section 6: signature and base-hash verification, staged "
                                       "apply, result-hash check, on-device smoke suite, atomic A/B switch, rollback."],
        ["ThoxEdge-0.8B", "First replication target because the base, the failure mode and a released reference edit "
                          "all exist. Served thinking-off and greedy; its loop rate under that decoding (Section 5) is the bar a patch must beat."],
        ["thox-micro-125m", "In-house target: THOX-trained, so a patch here would be the first fully THOX-owned WSP "
                            "artifact if the gates pass. Its loop baseline is part of the Section 5 protocol."],
        ["ESP32-C6-class nodes", "Whole written networks (the E2 shape), not patches: at this scale the network is the "
                                 "patch. Memory budgets must be checked per firmware build; no THOX measurement exists."],
    ], "Platform mapping. Every THOX-specific benefit in the right-hand column is a design proposal until the Section 8 "
       "gates pass.", widths=[1.6, 5.4])
    d.p("Two existing THOX practices absorb WSP without new machinery. GATE49, the evaluation every promoted model "
        "passes, already runs Qwen3.5 models thinking-off as part of the measured configuration, so a patched model "
        "re-enters an existing gate. The catalog sync rule (every model change updates the Model Factory, catalogs, "
        "repositories, Ollama, Hugging Face and the website in one pass) extends to patches by treating the manifest "
        "as a catalog object with its own hash and status.")


def build_section8(d: Doc):
    d.h2("8", "The gated replication program", "s8")
    d.p("THOX adopts WSP as a research program with pre-registered bars, not as a technique. The bars are THOX-defined "
        "targets. Compute planning follows the measured runs: full benchmarks belong on GPU jobs, and local machines "
        "carry editing and small-sample gates.")
    l1_status = "Protocol and jobs built; run stopped by compute billing (HTTP 402)"
    if L1:
        p = l1pair("edit_on", "base_off")
        l1_status = (f"Controls measured (Section 5): edit vs thinking off {pts(p['diff'])}; "
                     "no THOX-derived patch yet") if p else "Partly measured (Section 5)"
    d.table("gates", ["Step", "Content", "Success bar", "Status"], [
        ["E0", "Rebuild the released edit; verify hashes and rank", "Bit-exact match", "PASS (v1.0.0 E0; v1.1.0 E0-R)"],
        ["E1'", "Read: frontier editors (Claude Opus 5.5, GPT-6 Astra) and a local open model on the released policies "
                "and on new THOX-trained policies they cannot have seen",
         "At or above 3/4 on new policies in 2 of 3 attempts, and better than the scripted reader of Section 4.1", "Not run"],
        ["E2'", "Write: a frontier editor writes one THOX routing or control network from zero, scored against an "
                "equal-size trained network", "Beat the trained baseline on the task's held-out regime",
         "Not run (tool version: Section 4.2)"],
        ["E4", "Repair: decoding-only controls and the released edit at full scale; then a THOX-derived patch",
         "A THOX patch beats the best decoding control by more than 2 standard errors with no retention regression "
         "beyond 1 standard error; otherwise the decoding control is the shipping answer", l1_status],
        ["E5", "Port: the winning procedure, if any, to thox-micro-125m and a 2B-class model; quantise to Q8_0 and "
               "Q4_0 and re-gate", "Patch keeps at least 80% of its bf16 effect at Q4_0", "Not run"],
    ], "The gated program. Claims about THOX models stay internal until E4 and E5 pass.", widths=[0.6, 3.4, 2.6, 1.6],
        cls="small")
    d.p("The cheapest items ship first and pay off unconditionally: streaming loop detection with rewind and a hard "
        "thinking budget with a forced answer in the serving harness, the measured loop baselines extended to every "
        "device-target model, and the Section 6 channel. Weight patching is deliberately last, behind the controls it "
        "has to beat.")


def build_section9(d: Doc):
    d.h2("9", "Limitations", "s9")
    items = [
        "**Source maturity.** The source is a blog post, not peer-reviewed, with no arXiv version. Experiment 7's "
        "fine-tuned models are not released, some harness and grader modules are placeholders, earlier prompt trials "
        "were not published and the prompt-v5 runs are listed without results, so selection effects cannot be excluded.",
        "**Carried results.** E1 to E4 and the patch-channel tests are carried from v1.0.0 with phrase checks; their "
        "scripts and raw files live in the v1.0.0 artifact bundle on the THOX build VM and were not re-run for this "
        "edition. Merging that bundle into the repository is an open action.",
        "**Recreation scale.** Section 4 runs at 747 to 70,656 parameters, plus E0-R at 0.8B. It shows the exploited "
        "structure exists and is tool-usable; it does not show a frontier LLM can perform the source's feats, and no "
        "THOX frontier-editor run (E1', E2') has happened.",
        "**E4 is a negative result about one training run**, not about induction-head auditing in general.",
        ("**L1 scope.** One benchmark (MATH-500), one seed per configuration (four samples per problem for the "
         "card-sampling thinking-off rows), decoding settings from the source and the card rather than tuned, bfloat16 "
         "weights through vLLM rather than the GGUF builds THOX devices run, and no retention or safety suite. The "
         "defences are applied to recorded generations; they are exact for the prefix by causality but the forced "
         "answer uses a fresh seed." if L1 else
         "**No decoding-control measurement in this edition.** The L1 run was stopped by compute billing before "
         "completion, so the "
         "decisive comparison rests on a third-party number with one sample per problem [@openwsp] and on the "
         "pre-registered rule of Section 5.2. When L1 runs, its own scope limits apply: one benchmark, settings taken "
         "from the source and the card rather than tuned, bfloat16 weights through vLLM rather than the GGUF builds "
         "THOX devices run, and no retention or safety suite."),
        "**Small edit counts are not small edits.** The Experiment 8 diff changes its two matrices by 8% to 11% in "
        "Frobenius terms, and independent re-checking found the reasoning preceding a loop also loses probability "
        "under the edit [@wspacetest]. Retention measurement is half of any patch claim.",
        "**Sampling-profile dependence.** The source compared base and edit at temperature 0.6, while the Qwen3.5 card "
        "recommends temperature 1.0 for thinking-mode text tasks [@qwen]; L1 follows the source and does not test the "
        "card profile.",
        "**Safety surface.** The direction-ablation machinery that removes a loop direction removes refusal behaviour "
        "in the published literature [@arditi]. A signed patch channel is also an attack surface: signatures, base "
        "pinning, result hashes and on-device smoke tests are load-bearing. Weight-only audits of hidden traits failed "
        "in the source's Experiment 7 and are not relied on for any THOX safety decision.",
        "**Quantisation is untested for patches.** Whether a rank-1 edit survives Q4 quantisation of the full model is "
        "unknown here; E5 exists because the answer decides whether patches ship to devices at all.",
        "**Pricing and availability.** Frontier-editor cost for an Experiment 8-scale run is unknown, and editor outputs "
        "are not reproducible bit-for-bit across model versions; provenance records belong in the manifest.",
    ]
    d.bullets(items)


def build_section11(d: Doc):
    d.h2("11", "Provenance and document control", "s11")
    d.p("This edition was produced under the THOX Research Paper Process v1.0. Sources: the source post and its "
        "released logs, checkpoints and evaluation files; the v1.0.0 edition and its demo, whose measured numbers are "
        "carried with phrase checks; a reference list in which every external entry was re-opened on its primary page "
        "on 2026-11-04; and new THOX experiments (E0-R, P1, L1). Every figure and every number in the text is "
        "generated from the files listed below by `wp/figures.py` and `wp/build.py`.")
    jobs = "Hugging Face Jobs, account tommytracx, labels project=thox-wsp, edition=v1-1-0"
    rows = [
        ["Version", "v1.1.0 (public edition), supersedes v1.0.1 (2026-11-04); v1.0.1 superseded v1.0.0 (2026-11-03)"],
        ["Date", DATE],
        ["Author", "Craig Ross (Chief Executive Officer) and Tommy Xaypanya (Chief Technology Officer & Co-Founder, corresponding author), THOX.ai"],
        ["Status", "Public edition. Published on Zenodo, DOI 10.5281/zenodo.23955394 (concept DOI "
                   "10.5281/zenodo.23954378), license CC BY 4.0, under the THOX Research Paper Process v1.0."],
        ["Evidence files", "exp/results/carried_v1_0_0.json, e0r_patch_forms.json, l1_summary.json, "
                           "source/exp8_*_merged.json"],
        ["Raw L1 data", ("Private dataset Thox-ai/thox-wsp-evals (generations, defence outputs, job script) [@evals]"
                         if L1 else "Job script in the private dataset Thox-ai/thox-wsp-evals [@evals]; no generations "
                         "(run stopped by compute billing)")],
        ["Compute", (f"L1: {jobs}; " if L1 else f"L1 (stopped, HTTP 402): {jobs}; ") +
         "E0-R, P1 and A0: cloud workspace (Linux, 2 vCPU); E1 to E4: THOX build VM (v1.0.0)"],
        ["Companion demo", "weight-space-programming-demo.html (same bundle)"],
    ]
    d.table("ctl", ["Field", "Value"], rows, "Document control.", widths=[1.5, 5.5])
    d.table("chg", ["Area", f"Change from v{PREV[0]}"], [
        ["Byline", "Founder authors restored for the public edition: Craig Ross and Tommy Xaypanya. An intermediate "
                        "internal draft of v1.1.0 carried the THOX.ai Research organisational byline only."],
        ["Section 5", ("Was a pending instrument check (n=4 per configuration); now the full L1 measurement." if L1 else
                       "Was a pending instrument check (n=4 per configuration; the scoped check was later completed on "
                       "THOX hardware and is published as data supplement S1 alongside the v1.0.1 edition); now a full-scale "
                       "protocol, a tested job script, an analysis pipeline and a pre-registered decision rule. The "
                       "full run was stopped by compute billing before completion; no number is stated.")],
        ["Section 2.3", "New: the authors' released benchmark files and THOX's paired analysis of their per-problem "
                        "MATH-500 records (A0)."],
        ["Section 4.5", "E0 re-verified independently (E0-R); patch forms measured (P1)."],
        ["Section 6.1", "Patch sizes corrected to match the wire form; 'three orders of magnitude' corrected to two; "
                        "sparse residual added for exactness."],
        ["Section 2", "Authors' released benchmark files and prompt-variant runs added; OpenWSP pinned and cited; "
                      "Krentsel, Hugging Face re-run and alphaXiv sources cited; the alphaXiv figures no longer called "
                      "MATH-500."],
        ["References", "All entries re-verified. Corrected: source host (personal site, not a CSAIL blog), Honnibal "
                       "title, Text-to-LoRA title, HyperNetworks and MEMIT venues, logs licences, rebuild credit. "
                       "Added: NFN, DWSNets, Hase et al., Qwen3, s1, Holtzman et al., MATH, MATH-500, vLLM, "
                       "Math-Verify, RFC 8032."],
        ["Figures", "Regenerated from evidence files; titles moved to captions (no clipping); legends outside plot "
                    "areas; numbered by first appearance."],
    ], "Change log.", widths=[1.5, 5.5])


# ---------------------------------------------------------------------------------------------------- cover + summary
def build_cover(d: Doc):
    base_on, edit_on, base_off = l1c("base_on"), l1c("edit_on"), l1c("base_off")
    E0 = E0R
    abstract = (f"Takehi et al. report that a frontier LLM can read and write neural network weights directly, without "
                f"gradient descent, and that editing 0.016% of Qwen3.5-0.8B's weights raised its MATH-500 score from "
                f"{SRC_BASE['math500']['acc'] * 100:.1f}% to {SRC_EDIT['math500']['acc'] * 100:.1f}% by removing a "
                "thinking-loop failure. THOX ships a derivative of that exact base model, so this report reviews the "
                "claim, recreates its three verbs at checkable scale, re-verifies the released edit and "
                + ("measures" if L1 else "specifies") + " the control the question turns on. The headline edit is genuine and narrower than its framing: it removes "
                "an obstacle rather than adding ability. ")
    if base_on and edit_on and base_off:
        p = l1pair("edit_on", "base_off")
        abstract += (f"On the full MATH-500, THOX measures the base at {pct(base_on['acc'])} with thinking on, the "
                     f"released edit at {pct(edit_on['acc'])}, and the unedited base at {pct(base_off['acc'])} with "
                     f"thinking simply turned off (edit minus thinking-off {pts(p['diff'])}, {ci_txt(p)}). ")
    else:
        abstract += ("The decisive control, the same base model with thinking turned off, is specified at full "
                     "MATH-500 scale with a pre-registered decision rule; its run was stopped by compute billing "
                     "before completion, so this edition states no number for it. ")
    abstract += (f"The released edit rebuilds bit-exactly ({num(E0['changed_entries_total'])} entries, both hashes), but "
                 "a factor form estimated from it is not exact without a sparse residual, which sets the size of an "
                 "exact patch at tens of kilobytes. Small recreations show task identity is legible only in composed "
                 "per-class circuits, that a hand-written network matches an oracle-trained one, and that 16 of 747 "
                 "weights repair a stuck policy. THOX adopts the decoding defences and the signed patch channel now, "
                 "and holds weight patching behind a pre-registered bar: beat the best decoding-only control by more "
                 "than two standard errors.")
    contents = [("1", "Introduction"), ("2", "The source result and its evidence state"), ("3", "Definitions and method"),
                ("4", "THOX recreation experiments"), ("5", S5_TITLE()),
                ("6", "The THOX patch channel"), ("7", "Application to THOX device models"),
                ("8", "The gated replication program"), ("9", "Limitations"), ("10", "Conclusion"),
                ("11", "Provenance and document control"), ("R", "References")]
    toc = "".join(f'<li><a href="#s{n}" class="toc-a"><span class="toc-n">{n}</span>{t}</a></li>' if n != "R" else
                  f'<li><a href="#refs" class="toc-a"><span class="toc-n">R</span>{t}</a></li>' for n, t in contents)
    return f"""
<section class="cover">
  <div class="cover-top"><span class="eyebrow">THOX.ai Research &middot; Technical report v{VERSION} &middot; {DATE}</span>
  <span class="pill">Public edition</span></div>
  <div class="wordmark"><span class="wm-g">THOX</span><span class="wm-w">.ai</span></div>
  <h1>{TITLE}</h1>
  <p class="deck">{DECK}</p>
  <p class="byline">Craig Ross and Tommy Xaypanya</p>
  <p class="byline">Chief Executive Officer &middot; CTO &amp; Co-Founder (corresponding author)</p>
  <div class="abstract"><div class="abs-t">Abstract</div><p>{abstract}</p></div>
  <div class="toc"><div class="abs-t">Contents</div><ol>{toc}</ol></div>
  <p class="cover-foot">Craig Ross and Tommy Xaypanya, THOX.ai. Public edition v{VERSION}, {DATE}; supersedes v1.0.1
  (2026-11-04). Published on Zenodo: DOI 10.5281/zenodo.23955394 (concept DOI 10.5281/zenodo.23954378). License
  CC BY 4.0. <span class="slogan">Your AI. Your Data. Your Rules.&trade;</span></p>
</section>"""


def build_kpis():
    base_off, edit_on, tg, te = l1c("base_off"), l1c("edit_on"), l1c("thoxedge_gated"), l1c("thoxedge_greedy")
    t15, t19 = E0R["tensors"]
    exact = t15["sizes_bytes"]["factor_plus_residual_raw"] + t19["sizes_bytes"]["factor_plus_residual_raw"]
    cards = [(num(E0R["changed_entries_total"]), "entries changed in the released Qwen3.5-0.8B edit, rebuilt bit-exactly "
              "and re-verified on a second host (E0-R)", "Measured")]
    if base_off and edit_on:
        cards.append((f"{base_off['acc'] * 100:.1f}% vs {edit_on['acc'] * 100:.1f}%",
                      "MATH-500: base with thinking off and no weight change, against the released edit with thinking "
                      "on (L1, 500 problems)", "Measured"))
    else:
        cards.append((f"{A0['problems_better']} / {A0['problems_worse']}", "MATH-500 problems where the released edit "
                      "scores higher / lower than the base, in the authors' own per-problem files (A0)", "Calculated"))
    sv = tg or te
    if not sv:
        r4 = CARRIED["E1"]["reader_acc"]["value"]
        cards.insert(1, (f"{r4['R4']:.0f}% vs {r4['R1']:.1f}%", "task identified from weights alone by the per-class "
                         "composed reader, against three marginal readers at chance (E1, 30 networks)", "Measured"))
    if sv:
        cards.append((pct(sv["loop_share"]), "of ThoxEdge-0.8B answers loop " + ("in its served configuration "
                      "(grounding prompt, greedy)" if tg else "under greedy thinking-off decoding") +
                      " on MATH-500 (L1)", "Measured"))
    cards.append((kb(exact), f"exact patch for the Experiment 8 edit (factor plus residual), against "
                  f"{kb(E0R['release_edit_npz_bytes'])} for the released compressed diff (P1)", "Measured"))
    return "".join(f'<div class="kpi"><div class="kv">{v}</div><div class="kl">{l}</div><div class="kt">{t}</div></div>'
                   for v, l, t in cards)


# ---------------------------------------------------------------------------------------------------- assembly
def font_face():
    faces = []
    for fam, files in (("Inter", [(400, "inter-latin-400-normal"), (500, "inter-latin-500-normal"),
                                   (600, "inter-latin-600-normal"), (700, "inter-latin-700-normal")]),
                       ("JetBrains Mono", [(400, "jetbrains-mono-latin-400-normal"),
                                           (500, "jetbrains-mono-latin-500-normal"),
                                           (700, "jetbrains-mono-latin-700-normal")])):
        pkg = "inter" if fam == "Inter" else "jetbrains-mono"
        for w, f in files:
            data = base64.b64encode(open(os.path.join(FONTS, pkg, "files", f + ".woff2"), "rb").read()).decode()
            faces.append(f"@font-face{{font-family:'{fam}';font-style:normal;font-weight:{w};font-display:swap;"
                         f"src:url(data:font/woff2;base64,{data}) format('woff2')}}")
    return "\n".join(faces)


CSS = r"""
:root{--paper:#FFFFFF;--ink:#09090B;--ink2:#3F3F46;--muted:#52525B;--rule:#D4D4D8;--soft:#F4F4F5;--green:#047C3D;
--green-bg:#E8F5EE;--amber:#B45309;--cover:#09090B;--cover-text:#FAFAFA;--cover-muted:#A1A1AA;--brand:#05A451;
--sans:'Inter',system-ui,sans-serif;--mono:'JetBrains Mono',ui-monospace,monospace}
@media screen and (prefers-color-scheme:dark){:root:not([data-theme="light"]){--paper:#0F0F12;--ink:#FAFAFA;--ink2:#D4D4D8;
--muted:#A1A1AA;--rule:#3F3F46;--soft:#18181B;--green:#05A451;--green-bg:#0F2A1B;--amber:#F59E0B}
:root:not([data-theme="light"]) figure .fig{background:#FFFFFF;border-radius:6px;padding:6px}}
:root[data-theme="dark"]{--paper:#0F0F12;--ink:#FAFAFA;--ink2:#D4D4D8;--muted:#A1A1AA;--rule:#3F3F46;--soft:#18181B;
--green:#05A451;--green-bg:#0F2A1B;--amber:#F59E0B}
:root[data-theme="dark"] figure .fig{background:#FFFFFF;border-radius:6px;padding:6px}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--sans);font-size:10.4pt;line-height:1.55;
}
.wrap{max-width:7.0in;margin:0 auto;padding:0 16px}
a{color:var(--green)}
.cover{background:var(--cover);color:var(--cover-text);padding:0.75in 0.8in 0.6in;min-height:11in;display:flex;
flex-direction:column}
.cover-top{display:flex;justify-content:space-between;align-items:center;gap:12px;border-bottom:1px solid #27272A;
padding-bottom:10px}
.eyebrow{font-family:var(--mono);font-size:8.6pt;color:var(--cover-muted);letter-spacing:.02em}
.pill{font-family:var(--mono);font-size:8pt;color:var(--brand);border:1px solid var(--brand);border-radius:999px;
padding:2px 10px;white-space:nowrap}
.wordmark{font-family:var(--mono);font-weight:700;font-size:13pt;margin:22px 0 6px}
.wm-g{color:var(--brand)}.wm-w{color:var(--cover-text)}
.cover h1{font-size:23pt;line-height:1.15;margin:10px 0 10px;letter-spacing:-.01em;font-weight:700}
.deck{font-size:12pt;color:#D4D4D8;margin:0 0 10px;line-height:1.45}
.byline{font-size:10pt;color:var(--cover-muted);margin:0 0 16px}
.abstract{border-left:3px solid var(--brand);padding:2px 0 2px 14px;margin:6px 0 16px}
.abs-t{font-family:var(--mono);font-size:8pt;letter-spacing:.12em;text-transform:uppercase;color:var(--brand);
margin-bottom:5px}
.abstract p{margin:0;font-size:9.6pt;line-height:1.5;color:#E4E4E7}
.toc ol{list-style:none;padding:0;margin:0;columns:2;column-gap:28px}
.toc li{font-size:9.3pt;margin:2px 0;break-inside:avoid}
.toc-a{color:#E4E4E7;text-decoration:none}.toc-n{font-family:var(--mono);color:var(--brand);display:inline-block;
width:2em}
.cover-foot{margin-top:auto;padding-top:14px;border-top:1px solid #27272A;font-size:7.8pt;color:var(--cover-muted);
line-height:1.45}
.slogan{color:var(--cover-text);white-space:nowrap}
.summary{padding-top:.1in}
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:8px 0 14px}
.kpi{border:1px solid var(--rule);border-top:3px solid var(--green);border-radius:6px;padding:9px 9px 8px;
background:var(--soft)}
.kv{font-family:var(--mono);font-weight:700;font-size:13.5pt;color:var(--green);line-height:1.15;word-break:break-word}
.kl{font-size:7.9pt;color:var(--ink2);margin-top:5px;line-height:1.35}
.kt{font-family:var(--mono);font-size:6.8pt;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);
margin-top:6px}
h2{font-size:15pt;margin:26px 0 10px;padding-bottom:5px;border-bottom:2px solid var(--green);break-after:avoid;
letter-spacing:-.005em}
h2 .secno{font-family:var(--mono);color:var(--green);font-size:11pt;margin-right:10px;font-weight:700}
h3{font-size:11pt;margin:18px 0 6px;break-after:avoid}
p{margin:0 0 9px;text-align:left;hyphens:auto}
ul,ol{margin:0 0 10px;padding-left:20px}
li{margin:3px 0}
code{font-family:var(--mono);font-size:.86em;background:var(--soft);border:1px solid var(--rule);border-radius:3px;
padding:0 3px;word-break:break-all}
.cite{text-decoration:none;font-family:var(--mono);font-size:.82em;white-space:nowrap}
.callout{background:var(--green-bg);border-left:3px solid var(--green);border-radius:0 6px 6px 0;padding:9px 12px;
margin:10px 0 14px;break-inside:avoid}
.callout.warn{background:#FEF3C7;border-left-color:var(--amber);color:#09090B}
.callout-t{font-family:var(--mono);font-size:7.8pt;letter-spacing:.1em;text-transform:uppercase;color:var(--green);
margin-bottom:4px}
.callout p{margin:0;font-size:9.6pt}
figure{margin:12px 0 16px;break-inside:avoid}
figure .fig{max-width:6.1in;margin:0 auto}
figure .fig svg{width:100%;height:auto;display:block}
figcaption{font-size:8.3pt;color:var(--muted);margin-top:6px;line-height:1.45}
figcaption b{color:var(--ink)}
.ev{font-family:var(--mono);font-size:7pt;letter-spacing:.06em;text-transform:uppercase;color:var(--green);
margin-left:4px;white-space:nowrap}
.tbl{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:8.5pt;line-height:1.4;font-variant-numeric:tabular-nums}
.tbl.small table{font-size:7.9pt}
th{background:#18181B;color:#FAFAFA;text-align:left;font-weight:600;padding:5px 6px;vertical-align:bottom}
td{padding:5px 6px;border-bottom:1px solid var(--rule);vertical-align:top}
tbody tr:nth-child(even) td{background:color-mix(in srgb,var(--soft) 60%,transparent)}
.eq{display:flex;align-items:center;justify-content:center;gap:16px;margin:8px 0 12px;overflow-x:auto}
.eqno{font-family:var(--mono);font-size:8.5pt;color:var(--muted)}
.codebox{border:1px solid var(--rule);border-radius:6px;margin:10px 0 14px;break-inside:avoid;overflow:hidden}
.codebox-t{background:#18181B;color:#FAFAFA;font-size:8.3pt;font-weight:600;padding:5px 9px}
.codebox pre{margin:0;padding:9px;font-family:var(--mono);font-size:7.7pt;line-height:1.5;background:var(--soft);
overflow-x:auto;white-space:pre}
.refs{list-style:none;padding:0;font-size:8.2pt;line-height:1.45}
.refs li{margin:0 0 5px;padding-left:2.6em;text-indent:-2.6em;word-break:break-word}
.refno{font-family:var(--mono);color:var(--green)}
.theme-btn{position:fixed;bottom:12px;right:12px;z-index:5;font-family:var(--mono);font-size:8pt;background:var(--soft);
color:var(--ink);border:1px solid var(--rule);border-radius:999px;padding:4px 10px;cursor:pointer}
@media screen{.cover{min-height:auto;padding:40px 24px 28px;border-radius:0}.cover-foot{margin-top:24px}
.body-wrap{padding-bottom:48px}}
@media screen and (max-width:640px){.kpis{grid-template-columns:repeat(2,1fr)}.toc ol{columns:1}.cover h1{font-size:19pt}
body{font-size:10.2pt}.cover{padding:32px 16px 22px}}
@media print{.theme-btn{display:none}.wrap{max-width:none;padding:0}a{color:var(--green);text-decoration:none}
.cover{min-height:11in;height:11in}}
@page{size:Letter;margin:0}
"""


def assemble():
    d = Doc()
    unused = build_body(d)
    if unused:
        print("note: reference keys defined but not cited:", unused)
    body_html = "\n".join(d.parts)
    # equations
    os.makedirs(OUT, exist_ok=True)
    eq_in, eq_out = os.path.join(OUT, "eqs_in.json"), os.path.join(OUT, "eqs_out.json")
    cover_doc = Doc()
    cover_doc.cite_order = d.cite_order
    cover_html = build_cover(d)
    json.dump(d.eqs, open(eq_in, "w"))
    subprocess.run(["node", os.path.join(WP, "katex_render.cjs"), eq_in, eq_out], check=True)
    rendered = json.load(open(eq_out))
    katex_css = rendered.pop("__css__")
    body_html = re.sub(r"@@((?:i)?eq\d+)@@", lambda m: rendered[m.group(1)], body_html)
    if "@@" in body_html:
        raise SystemExit("unrendered equation marker left in body")
    kpis = build_kpis()
    summary = (f'<section class="summary"><h2 id="summary"><span class="secno">&#9632;</span>Executive summary</h2>'
               f'<div class="kpis">{kpis}</div></section>')
    fonts = font_face()
    head = (f'<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>{html.escape(SHORT)} v{VERSION}</title>'
            f'<meta name="description" content="{html.escape(DECK)}">'
            f'<meta name="author" content="Craig Ross and Tommy Xaypanya">'
            f'<style>{fonts}\n{katex_css}\n{CSS}</style>')
    theme_js = ("<script>(function(){var b=document.getElementById('tb');if(!b)return;var r=document.documentElement;"
                "function cur(){return r.getAttribute('data-theme')||(matchMedia('(prefers-color-scheme: dark)').matches?"
                "'dark':'light')}function lab(){b.textContent=cur()==='dark'?'Light':'Dark'}"
                "try{var s=localStorage.getItem('thox-paper-theme');if(s)r.setAttribute('data-theme',s)}catch(e){}"
                "lab();b.addEventListener('click',function(){var n=cur()==='dark'?'light':'dark';"
                "r.setAttribute('data-theme',n);try{localStorage.setItem('thox-paper-theme',n)}catch(e){}lab()})})();"
                "</script>")
    paper = (f"<!doctype html><html lang='en'><head>{head}</head><body>"
             f"<button class='theme-btn' id='tb' type='button'>Dark</button>{cover_html}"
             f"<div class='wrap body-wrap'>{summary}{body_html}</div>{theme_js}</body></html>")
    cover_only = f"<!doctype html><html lang='en' data-theme='light'><head>{head}</head><body>{cover_html}</body></html>"
    body_only = (f"<!doctype html><html lang='en' data-theme='light'><head>{head}</head><body>"
                 f"<div class='wrap'>{summary}{body_html}</div></body></html>")
    for name, content in (("paper.html", paper), ("cover.html", cover_only), ("body.html", body_only)):
        with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
            f.write(content)
    # writing-rule checks
    text = re.sub(r"<[^>]+>", " ", paper)
    bad = [c for c in ("\u2014", "lorem", "TODO", "[Title") if c in text]
    if bad:
        raise SystemExit(f"writing-rule violation in output: {bad}")
    print(f"built paper.html ({len(paper) / 1e6:.2f} MB), {len(d.cite_order)} references, {d.fig_n} figures, "
          f"{d.tab_n} tables, {len(d.eqs)} equations; L1 present: {bool(L1)}")


if __name__ == "__main__":
    os.chdir(ROOT)
    assemble()
    sys.exit(0)
