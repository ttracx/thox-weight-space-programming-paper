/**
 * pdf.cjs: print THOX technical report v1.1.0 to PDF with Playwright (Chromium).
 *
 * Usage: node wp/pdf.cjs <outDir> <version> <date>
 *   reads  <outDir>/cover.html and <outDir>/body.html (written by wp/build.py)
 *   writes <outDir>/cover.pdf and <outDir>/body.pdf; wp/merge_pdf.py joins them and sets metadata.
 *
 * The cover prints full-bleed with no header or footer. The body prints on US Letter with a running header
 * (short title and version) and a "page x / y" footer in JetBrains Mono, matching the THOX research paper standard.
 */
"use strict";
const path = require("path");
const { chromium } = require("playwright");

async function main() {
  const [outDir, version, date] = process.argv.slice(2);
  if (!outDir || !version || !date) {
    console.error("usage: node wp/pdf.cjs <outDir> <version> <date>");
    process.exit(2);
  }
  const browser = await chromium.launch();
  try {
    const page = await browser.newPage();
    const errors = [];
    page.on("pageerror", (e) => errors.push(String(e)));
    page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });

    await page.goto("file://" + path.resolve(outDir, "cover.html"), { waitUntil: "load" });
    await page.evaluate(() => document.fonts.ready);
    await page.addStyleTag({ content: "@page{size:Letter;margin:0} body{margin:0}" });
    await page.pdf({ path: path.resolve(outDir, "cover.pdf"), format: "Letter", printBackground: true,
                     margin: { top: "0", bottom: "0", left: "0", right: "0" }, pageRanges: "1" });

    await page.goto("file://" + path.resolve(outDir, "body.html"), { waitUntil: "load" });
    await page.evaluate(() => document.fonts.ready);
    await page.addStyleTag({ content: "@page{size:Letter;margin:0.8in 0.82in 0.78in 0.82in}" });
    const mono = "font-family:'JetBrains Mono',monospace;font-size:7px;color:#71717A;width:100%;" +
                 "padding:0 0.82in;display:flex;justify-content:space-between;";
    await page.pdf({
      path: path.resolve(outDir, "body.pdf"), format: "Letter", printBackground: true,
      displayHeaderFooter: true, preferCSSPageSize: true,
      headerTemplate: `<div style="${mono}"><span>THOX.ai Research &middot; Weight-Space Programming for THOX Edge ` +
                      `Models</span><span>v${version} &middot; ${date} &middot; Public edition</span></div>`,
      footerTemplate: `<div style="${mono}"><span>Your AI. Your Data. Your Rules.&trade;</span>` +
                      `<span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>`,
    });
    if (errors.length) {
      console.error("page errors:", errors);
      process.exit(1);
    }
    console.log("printed cover.pdf and body.pdf");
  } finally {
    await browser.close();
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
