"""demo_build.py: the companion demo page for THOX technical report v1.1.0.

    python wp/demo_build.py          (from the repository root; writes wp/out/weight-space-programming-demo.html)

One standalone HTML file, no network calls. It runs real logic in the browser: a JavaScript port of the loop metric
(exp/lib/wsp_loop.py loop_scan), checked at load against known-answer vectors computed by the Python implementation;
the pre-registered Section 5.2 decision rule; and the patch-size calculator of Equation (3). Its data come from the
evidence files (carried_v1_0_0.json, e0r_patch_forms.json, a0_source_paired.json) and are embedded at build time.
"""
from __future__ import annotations

import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "exp", "lib"))
import wsp_loop as L  # noqa: E402

RES = os.path.join(ROOT, "exp", "results")


def minstd(seed: int, n: int) -> list[str]:
    """Deterministic word stream shared by Python and the page (MINSTD LCG, safe in JS doubles)."""
    x = seed
    out = []
    for _ in range(n):
        x = (x * 48271) % 2147483647
        out.append("w" + _b36(x))
    return out


def _b36(v: int) -> str:
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    s = ""
    while v:
        v, r = divmod(v, 36)
        s = digits[r] + s
    return s or "0"


VECTOR_SPECS = [
    {"head_seed": 11, "head_n": 2000, "block_seed": 0, "block_n": 0, "reps": 0},
    {"head_seed": 12, "head_n": 500, "block_seed": 13, "block_n": 37, "reps": 40},
    {"head_seed": 14, "head_n": 400, "block_seed": 15, "block_n": 25, "reps": 30},
    {"head_seed": 16, "head_n": 3, "block_seed": 0, "block_n": 0, "reps": 0},
    {"head_seed": 17, "head_n": 900, "block_seed": 18, "block_n": 120, "reps": 4},
    {"head_seed": 19, "head_n": 50, "block_seed": 20, "block_n": 9, "reps": 60},
]


def vectors():
    out = []
    for spec in VECTOR_SPECS:
        words = minstd(spec["head_seed"], spec["head_n"]) + minstd(spec["block_seed"], spec["block_n"]) * spec["reps"]
        r = L.loop_scan(" ".join(words))
        out.append({**spec, "looping": r["looping"], "onset_word": r["onset_word"], "n_words": r["n_words"],
                    "repeat_share": round(r["repeat_share"], 6)})
    return out


def main() -> int:
    carried = json.load(open(os.path.join(RES, "carried_v1_0_0.json"), encoding="utf-8"))
    e0r = json.load(open(os.path.join(RES, "e0r_patch_forms.json"), encoding="utf-8"))
    a0 = json.load(open(os.path.join(RES, "a0_source_paired.json"), encoding="utf-8"))
    l1 = None
    p = os.path.join(RES, "l1_summary.json")
    if os.path.exists(p):
        l1 = json.load(open(p, encoding="utf-8"))
    t15, t19 = e0r["tensors"]
    data = {
        "maps": carried["E1_example_maps"], "sweep": carried["E3_gain_sweep_256"],
        "e3_success_512": carried["E3"]["success_512"]["value"],
        "e0r": {"changed": e0r["changed_entries_total"], "per": [t15["changed_entries"], t19["changed_entries"]],
                "sigma": [round(t15["sigma1_over_sigma2"]), round(t19["sigma1_over_sigma2"])],
                "hash": [t15["edited_sha256"][:12], t19["edited_sha256"][:12]],
                "resid": [t15["factor_variants"][t15["factor_best_variant"]]["mismatched_entries"],
                          t19["factor_variants"][t19["factor_best_variant"]]["mismatched_entries"]],
                "npz": e0r["release_edit_npz_bytes"], "pass": e0r["e0r_pass"]},
        "a0": a0, "vectors": vectors(), "l1": None if not l1 else {
            k: {"acc": v["acc"], "cap": v.get("cap_share"), "loop": v.get("loop_share")} for k, v in l1["configs"].items()},
    }
    html = (TEMPLATE.replace("__DATA__", json.dumps(data, separators=(",", ":")))
            .replace("__CHG__", str(data["e0r"]["changed"])).replace("__RES__", str(sum(data["e0r"]["resid"]))))
    os.makedirs(os.path.join(ROOT, "wp", "out"), exist_ok=True)
    out = os.path.join(ROOT, "wp", "out", "weight-space-programming-demo.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"wrote {out} ({len(html) / 1e3:.0f} KB), {len(data['vectors'])} loop vectors")
    return 0


TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Weight-Space Programming Demo</title>
<meta name="description" content="Companion to THOX technical report v1.1.0: read a task from composed weight maps, explore a 16-weight policy fix, check the released Qwen3.5-0.8B edit, size an exact signed patch, and run the loop detector and the pre-registered decision rule in the browser.">
<style>
:root{--bg:#FFFFFF;--fg:#09090B;--muted:#52525B;--rule:#D4D4D8;--card:#F4F4F5;--green:#047C3D;--pale:#E8F5EE;
--bad:#B91C1C;--amber:#B45309;--mark:#FDE68A;--mono:'JetBrains Mono',ui-monospace,SFMono-Regular,Menlo,monospace;
--sans:Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#09090B;--fg:#FAFAFA;--muted:#A1A1AA;
--rule:#3F3F46;--card:#18181B;--green:#05A451;--pale:#0F2A1B;--bad:#F87171;--amber:#F59E0B;--mark:#5B4A12}}
:root[data-theme="dark"]{--bg:#09090B;--fg:#FAFAFA;--muted:#A1A1AA;--rule:#3F3F46;--card:#18181B;--green:#05A451;
--pale:#0F2A1B;--bad:#F87171;--amber:#F59E0B;--mark:#5B4A12}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--fg);font-family:var(--sans);line-height:1.5;font-size:15px}
.wrap{max-width:960px;margin:0 auto;padding:22px 16px 48px}
header{border-bottom:2px solid var(--green);padding-bottom:10px;margin-bottom:16px;position:relative}
.eyebrow{font-family:var(--mono);font-size:11px;color:var(--green);text-transform:uppercase;letter-spacing:.08em;
padding-right:80px}
h1{font-size:24px;margin:6px 0 4px;line-height:1.2}
h2{font-size:18px;margin:28px 0 8px;border-bottom:1px solid var(--rule);padding-bottom:4px}
p{margin:0 0 10px}
.card{background:var(--card);border:1px solid var(--rule);border-radius:8px;padding:14px;margin:10px 0}
label{display:block;font-size:13px;color:var(--muted);margin:8px 0 2px}
input,select,textarea{width:100%;max-width:100%;font-family:var(--mono);font-size:13px;padding:7px 8px;
border:1px solid var(--rule);border-radius:6px;background:var(--bg);color:var(--fg)}
textarea{min-height:110px;resize:vertical}
input[type=range]{padding:0}
button{font-family:var(--sans);font-size:14px;font-weight:600;background:var(--green);color:#fff;border:0;
border-radius:6px;padding:8px 14px;margin:10px 6px 0 0;cursor:pointer;transition:opacity 120ms}
button:hover{opacity:.9}
button.secondary{background:transparent;color:var(--green);border:1px solid var(--green)}
@media (prefers-reduced-motion:reduce){button{transition:none}}
.out{font-family:var(--mono);font-size:12.5px;white-space:pre-wrap;word-break:break-word;background:var(--bg);
border:1px solid var(--rule);border-radius:6px;padding:10px;margin:8px 0 0;max-height:320px;overflow:auto}
.ok{color:var(--green);font-weight:600}.bad{color:var(--bad);font-weight:600}.warn{color:var(--amber);font-weight:600}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin:10px 0}
.kpi{border:1px solid var(--rule);border-top:3px solid var(--green);border-radius:6px;padding:10px;background:var(--card)}
.kv{font-family:var(--mono);font-size:20px;font-weight:700;color:var(--green);word-break:break-word}
.kl{font-size:12px;color:var(--muted);margin-top:3px}
.kt{font-family:var(--mono);font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin-top:6px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
table{width:100%;border-collapse:collapse;font-size:13px;margin:8px 0}
th,td{text-align:left;padding:5px 6px;border-bottom:1px solid var(--rule)}
th{color:var(--muted);font-weight:600}
td.num{font-family:var(--mono);text-align:right}
.note{font-size:13px;color:var(--muted)}
.maps{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-top:8px}
canvas.map{border:1px solid var(--rule);border-radius:6px;image-rendering:pixelated;width:100%;max-width:150px;
aspect-ratio:1/1}
mark{background:var(--mark);color:inherit}
.theme{position:absolute;top:0;right:0;font-size:12px;background:transparent;color:var(--muted);
border:1px solid var(--rule);padding:4px 10px;margin:0}
.badge{display:inline-block;font-family:var(--mono);font-size:11px;border:1px solid var(--green);color:var(--green);
border-radius:999px;padding:1px 8px;margin-left:6px}
.badge.bad{border-color:var(--bad);color:var(--bad)}
footer{margin-top:32px;font-size:12px;color:var(--muted);border-top:1px solid var(--rule);padding-top:10px}
</style>
</head>
<body>
<div class="wrap">
<header>
  <button class="theme" id="themeBtn" type="button">Dark</button>
  <div class="eyebrow">THOX.ai Research &middot; companion demo to technical report v1.1.0</div>
  <h1>Weight-Space Programming, hands on</h1>
  <p>Six instruments from the report, running in this page. Each number carries its evidence class. The loop detector
  is a line-for-line port of the report's Python metric and checks itself against Python-computed vectors when the
  page loads: <span id="selftest" class="badge">checking</span></p>
</header>

<h2>1. Read: find the task in the composed maps</h2>
<p>Per-class effective input-to-logit maps (E = W2<sup>T</sup>W1<sup>T</sup>) of trained 64-48-4 networks from E1.
Each network names the dot's column, its row, or its diagonal class on an 8x8 grid. Three marginal readers scored at
chance on networks like these; the per-class composed reader scored 100% over 30 networks. Guess before you reveal.</p>
<div class="card">
  <label for="netSel">Network</label>
  <select id="netSel"><option value="col">Network A</option><option value="row">Network B</option><option value="diag">Network C</option></select>
  <div class="maps" id="maps"></div>
  <label for="guess">Your guess</label>
  <select id="guess"><option value="col">column</option><option value="row">row</option><option value="diag">diagonal</option></select>
  <button id="reveal" type="button">Reveal</button>
  <div class="out" id="readOut">Each tile is one class's |E| map (darker green = stronger).</div>
</div>

<h2>2. Fix: sixteen weights, one dose-response</h2>
<p>E3 repaired a MountainCar policy stuck at 0% by editing 16 of 747 weights. A random edit of the same size scored 0%
at every gain. Drag the override gain; 1.0 is the shipped edit.</p>
<div class="card">
  <label for="gain">Override gain: <span id="gainVal">1.0</span>x</label>
  <input type="range" id="gain" min="0" max="4" step="1" value="3">
  <div class="kpis"><div class="kpi"><div class="kv" id="succ">-</div><div class="kl">success at this gain (256 episodes)</div><div class="kt">Simulated</div></div>
  <div class="kpi"><div class="kv">0%</div><div class="kl">before the edit, and for the random-edit control at every gain</div><div class="kt">Simulated</div></div></div>
</div>

<h2>3. Verify: the released Qwen3.5-0.8B edit</h2>
<div class="kpis" id="e0kpis"></div>
<p class="note" id="e0note"></p>

<h2>4. What the authors' own files show</h2>
<p>THOX re-analysed the authors' released per-problem MATH-500 records (A0, 4 samples per problem, thinking on).</p>
<div class="kpis" id="a0kpis"></div>
<p class="note">A gain on hundreds of problems and a loss on none is what removing one uniform obstacle looks like. A
decoding change that avoids the same obstacle would leave the same signature, which is why section 6 matters.</p>

<h2>5. Ship: size an exact signed patch</h2>
<p>An exact rank-1 patch ships, per tensor, the direction u (float32), the edited column indices and alpha, plus a
sparse residual for entries the factor alone misses by one rounding step: |P| = &Sigma; (4d + 2|C| + 8) + 6r.
Defaults are the measured Experiment 8 values (two tensors; totals for changed and residual entries).</p>
<div class="card">
  <div class="grid">
    <div><label for="pRows">Rows d (u length)</label><input id="pRows" type="number" min="1" value="1024"></div>
    <div><label for="pCols">Tensor columns</label><input id="pCols" type="number" min="1" value="3584"></div>
    <div><label for="pEdit">Edited columns |C|</label><input id="pEdit" type="number" min="1" value="64"></div>
    <div><label for="pTen">Tensors</label><input id="pTen" type="number" min="1" value="2"></div>
    <div><label for="pChg">Changed entries (total)</label><input id="pChg" type="number" min="0" value="__CHG__"></div>
    <div><label for="pRes">Residual entries r (total)</label><input id="pRes" type="number" min="0" value="__RES__"></div>
  </div>
  <table id="patchTable"><thead><tr><th>Representation</th><th>Bytes</th><th>Exact</th></tr></thead><tbody></tbody></table>
  <p class="note">The loader verifies an Ed25519 signature, the base tensors' SHA-256, applies to the inactive A/B slot,
  checks every result hash and only then switches. A factor without its residual fails that check by design.</p>
</div>

<h2>6. The control: loop detector and decision rule</h2>
<p id="l1status"></p>
<div class="card">
  <label for="loopText">Paste a model answer (or generate an example)</label>
  <textarea id="loopText" spellcheck="false"></textarea>
  <button id="loopRun" type="button">Scan for a loop</button>
  <button id="loopEx" class="secondary" type="button">Example: answer that falls into a loop</button>
  <div class="out" id="loopOut">The test: some run of 300 consecutive word 8-grams in which at least 270 already
appeared earlier. It is causal, so the onset is where a streaming interrupt would rewind to.</div>
</div>
<div class="card">
  <p style="margin:0 0 6px"><b>Pre-registered decision rule</b> (Section 5.2): paired MATH-500 difference, released
  edit with thinking on minus the unedited base with thinking off, and its 95% interval, in points.</p>
  <div class="grid">
    <div><label for="dLo">Interval low</label><input id="dLo" type="number" step="0.1" value="-1.5"></div>
    <div><label for="dHi">Interval high</label><input id="dHi" type="number" step="0.1" value="1.2"></div>
  </div>
  <button id="ruleRun" type="button">Apply the rule</button>
  <div class="out" id="ruleOut">Enter an interval and apply the rule.</div>
</div>

<footer>THOX.ai Research, companion to technical report v1.1.0 (public edition, 2026-11-04). Data embedded from
exp/results/ at build time; this page makes no network calls. Your AI. Your Data. Your Rules.&trade;</footer>
</div>
<script>
"use strict";
const D = __DATA__;

/* ---------- theme ---------- */
(function () {
  const btn = document.getElementById("themeBtn"), root = document.documentElement;
  const cur = () => root.getAttribute("data-theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  const label = () => { btn.textContent = cur() === "dark" ? "Light" : "Dark"; };
  try { const s = localStorage.getItem("thox-wsp-demo-theme"); if (s) root.setAttribute("data-theme", s); } catch (e) {}
  label();
  btn.addEventListener("click", () => {
    const n = cur() === "dark" ? "light" : "dark";
    root.setAttribute("data-theme", n);
    try { localStorage.setItem("thox-wsp-demo-theme", n); } catch (e) {}
    label(); drawMaps();
  });
})();

/* ---------- loop metric: port of exp/lib/wsp_loop.py loop_scan ---------- */
function loopScan(text, n = 8, windowLen = 300, frac = 0.9) {
  if (typeof text !== "string") throw new TypeError("text must be a string");
  const words = [], offsets = [];
  const re = /\S+/g; let m;
  while ((m = re.exec(text)) !== null) { words.push(m[0]); offsets.push(m.index); }
  const M = words.length - n + 1;
  const out = { looping: false, onset_word: null, onset_char: null, fire_word: null, n_words: words.length, repeat_share: 0 };
  if (M <= 0) return out;
  const seen = new Set(); const flags = new Uint8Array(M); let total = 0;
  for (let i = 0; i < M; i++) {
    const g = words.slice(i, i + n).join("\u0001");
    if (seen.has(g)) { flags[i] = 1; total++; } else { seen.add(g); }
  }
  out.repeat_share = total / M;
  if (M < windowLen) return out;
  const need = Math.ceil(frac * windowLen - 1e-9);
  let s = 0; for (let i = 0; i < windowLen; i++) s += flags[i];
  let start = null;
  if (s >= need) start = 0;
  else for (let i = windowLen; i < M; i++) { s += flags[i] - flags[i - windowLen]; if (s >= need) { start = i - windowLen + 1; break; } }
  if (start !== null) { out.looping = true; out.onset_word = start; out.onset_char = offsets[start]; out.fire_word = start + windowLen - 1; }
  return out;
}
function minstd(seed, n) {
  let x = seed; const out = [];
  for (let i = 0; i < n; i++) { x = (x * 48271) % 2147483647; out.push("w" + x.toString(36)); }
  return out;
}
function vectorText(v) {
  let w = minstd(v.head_seed, v.head_n);
  const block = minstd(v.block_seed, v.block_n);
  for (let r = 0; r < v.reps; r++) w = w.concat(block);
  return w.join(" ");
}
function selfTest() {
  let pass = 0; const fails = [];
  for (const v of D.vectors) {
    const r = loopScan(vectorText(v));
    const ok = r.looping === v.looping && r.onset_word === v.onset_word && r.n_words === v.n_words &&
               Math.abs(r.repeat_share - v.repeat_share) < 1e-6;
    if (ok) pass++; else fails.push(v);
  }
  const el = document.getElementById("selftest");
  el.textContent = `self-test ${pass}/${D.vectors.length} match Python`;
  if (pass !== D.vectors.length) { el.classList.add("bad"); console.error("loop self-test failed", fails); }
  window.__thoxSelfTest = { pass, total: D.vectors.length };
}

/* ---------- 1. maps ---------- */
function drawMaps() {
  const task = document.getElementById("netSel").value;
  const wrap = document.getElementById("maps"); wrap.innerHTML = "";
  const dark = getComputedStyle(document.documentElement).getPropertyValue("--bg").trim().toUpperCase() !== "#FFFFFF";
  D.maps[task].maps.forEach((grid, c) => {
    const holder = document.createElement("div");
    const cv = document.createElement("canvas"); cv.width = 8; cv.height = 8; cv.className = "map";
    cv.setAttribute("aria-label", "class " + c + " effective map");
    const ctx = cv.getContext("2d");
    let mx = 0; grid.flat().forEach(v => { mx = Math.max(mx, Math.abs(v)); });
    for (let r = 0; r < 8; r++) for (let col = 0; col < 8; col++) {
      const t = Math.abs(grid[r][col]) / (mx || 1);
      ctx.fillStyle = dark ? `rgba(5,164,81,${0.08 + 0.92 * t})` : `rgba(4,124,61,${0.06 + 0.94 * t})`;
      ctx.fillRect(col, r, 1, 1);
    }
    const lab = document.createElement("div"); lab.className = "note"; lab.textContent = "class " + c;
    holder.appendChild(cv); holder.appendChild(lab); wrap.appendChild(holder);
  });
}
document.getElementById("netSel").addEventListener("change", () => {
  drawMaps(); document.getElementById("readOut").textContent = "Maps drawn. Make your guess, then reveal.";
});
document.getElementById("reveal").addEventListener("click", () => {
  const task = document.getElementById("netSel").value, g = document.getElementById("guess").value;
  const names = { col: "column", row: "row", diag: "diagonal" };
  const o = document.getElementById("readOut");
  o.innerHTML = "";
  const s = document.createElement("span"); s.className = g === task ? "ok" : "bad";
  s.textContent = g === task ? "Correct. " : "Not this time. ";
  o.appendChild(s);
  o.appendChild(document.createTextNode(`This network's task was ${names[task]}. The per-class composed reader (R4) also ` +
    `reads it as ${names[task]}; the three marginal readers answer "diagonal" on every column and row network. ` +
    `Over 30 networks: R4 100%, R1-R3 at chance (33.3%). Measured, E1 (v1.0.0).`));
});

/* ---------- 2. sweep ---------- */
const gains = Object.keys(D.sweep).map(Number).sort((a, b) => a - b);
function showGain() {
  const g = gains[Number(document.getElementById("gain").value)];
  document.getElementById("gainVal").textContent = g.toFixed(2);
  document.getElementById("succ").textContent = (D.sweep[String(g)] !== undefined ? D.sweep[String(g)] : D.sweep[g.toFixed(1)]) * 100 + "%";
}
document.getElementById("gain").max = gains.length - 1;
document.getElementById("gain").value = gains.indexOf(1);
document.getElementById("gain").addEventListener("input", showGain);

/* ---------- 3. E0-R ---------- */
(function () {
  const e = D.e0r, f = (n) => n.toLocaleString("en-US");
  const k = [[f(e.changed), "entries changed across the two edited down_proj tensors (" + f(e.per[0]) + " + " + f(e.per[1]) + "); rebuild from the authors' sparse diff is bit-identical", "Measured, E0-R"],
             [f(e.sigma[0]) + " / " + f(e.sigma[1]), "sigma1/sigma2 of each tensor's diff: both edits are rank-1", "Measured, E0-R"],
             [e.hash[0] + "... / " + e.hash[1] + "...", "edited tensor SHA-256 prefixes, matching the authors' manifest", "Measured, E0-R"],
             [f(e.resid[0] + e.resid[1]), "entries a factor estimated from the released diff misses by one rounding step; an exact patch carries them as a residual", "Measured, P1"]];
  document.getElementById("e0kpis").innerHTML = k.map(([v, l, t]) =>
    `<div class="kpi"><div class="kv">${v}</div><div class="kl">${l}</div><div class="kt">${t}</div></div>`).join("");
  document.getElementById("e0note").textContent = (e.pass ? "All E0-R checks pass. " : "E0-R did not pass. ") +
    "Base pinned at Qwen/Qwen3.5-0.8B revision 2fc06364715b; edited checkpoint at revision d1671a178705. Full hashes: exp/results/e0r_patch_forms.json.";
})();

/* ---------- 4. A0 ---------- */
(function () {
  const a = D.a0, p = (x) => (x * 100).toFixed(1) + "%";
  const k = [[p(a.base_acc) + " to " + p(a.edit_acc), "MATH-500 recomputed from the released per-problem files", "Calculated, A0"],
             [a.problems_better + " / " + a.problems_worse, "problems where the edit scores higher / lower than the base", "Calculated, A0"],
             [String(a.base_never_edit_some), "of the " + a.base_never_solved + " problems the base never solves in 4 samples, solved by the edit at least once", "Calculated, A0"],
             ["+" + (a.diff * 100).toFixed(1) + " pts", "paired gain, 95% bootstrap " + (a.diff_ci95[0] * 100).toFixed(1) + " to " + (a.diff_ci95[1] * 100).toFixed(1), "Calculated, A0"]];
  document.getElementById("a0kpis").innerHTML = k.map(([v, l, t]) =>
    `<div class="kpi"><div class="kv">${v}</div><div class="kl">${l}</div><div class="kt">${t}</div></div>`).join("");
})();

/* ---------- 5. patch calculator ---------- */
function fmtBytes(n) { return n >= 1e6 ? (n / 1e6).toFixed(2) + " MB" : n >= 1e3 ? (n / 1e3).toFixed(1) + " KB" : n + " B"; }
function patchCalc() {
  const val = (id, min) => { const v = Math.floor(Number(document.getElementById(id).value)); return Number.isFinite(v) && v >= min ? v : null; };
  const d = val("pRows", 1), n = val("pCols", 1), c = val("pEdit", 1), r = val("pRes", 0), t = val("pTen", 1),
        chg = val("pChg", 0);
  const body = document.querySelector("#patchTable tbody");
  if ([d, n, c, r, t, chg].some(x => x === null) || c > n || chg > t * d * c || r > chg) {
    body.innerHTML = `<tr><td colspan="3" class="bad">Enter whole numbers: rows, columns, edited columns and tensors at least 1; changed entries no more than tensors x rows x edited columns; residual no more than changed entries.</td></tr>`;
    return;
  }
  const rows = [["Full edited tensors (bf16)", t * d * n * 2, "yes"],
                ["Sparse diff, raw (index + value per changed entry)", chg * 6, "yes"],
                ["Factor + residual (Equation 3)", t * (4 * d + 2 * c + 8) + 6 * r, "yes"],
                ["Factor only, float32 u", t * (4 * d + 2 * c + 8), r > 0 ? "no" : "yes"],
                ["Factor only, as hex on the wire", t * (8 * d + 4 * c + 16), r > 0 ? "no" : "yes"]];
  body.innerHTML = rows.map(([name, b, ex]) =>
    `<tr><td>${name}</td><td class="num">${fmtBytes(b)}</td><td class="${ex === "yes" ? "ok" : "bad"}">${ex}</td></tr>`).join("");
}
["pRows", "pCols", "pEdit", "pRes", "pTen", "pChg"].forEach(id => document.getElementById(id).addEventListener("input", patchCalc));

/* ---------- 6. loop detector + rule ---------- */
function escapeHtml(s) { return s.replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch])); }
function runLoop() {
  const text = document.getElementById("loopText").value;
  const out = document.getElementById("loopOut");
  if (!text.trim()) { out.textContent = "Paste some text first."; return; }
  const r = loopScan(text);
  if (!r.looping) {
    out.innerHTML = `<span class="ok">No loop.</span> ${r.n_words.toLocaleString("en-US")} words; ` +
      `${(r.repeat_share * 100).toFixed(1)}% of 8-grams repeat an earlier one.`;
    return;
  }
  const before = text.slice(Math.max(0, r.onset_char - 240), r.onset_char);
  const after = text.slice(r.onset_char, r.onset_char + 360);
  out.innerHTML = `<span class="warn">Loop detected.</span> Onset at word ${r.onset_word.toLocaleString("en-US")} of ` +
    `${r.n_words.toLocaleString("en-US")}; a streaming detector fires at word ${(r.fire_word + 7).toLocaleString("en-US")} and rewinds to the onset. ` +
    `${(r.repeat_share * 100).toFixed(1)}% of 8-grams repeat.\n\n...${escapeHtml(before)}<mark>${escapeHtml(after)}</mark>...`;
}
document.getElementById("loopRun").addEventListener("click", runLoop);
document.getElementById("loopEx").addEventListener("click", () => {
  const steps = [];
  for (let i = 1; i <= 60; i++) steps.push(`Step ${i}: try n = ${i + 2}; then n^2 - 1 = ${(i + 2) * (i + 2) - 1}, which factors as (${i + 1})(${i + 3}).`);
  const loop = "Wait, let me double-check the factorisation of n^2 - 1 again. We have n^2 - 1 = (n - 1)(n + 1), so for n = 5 this gives 4 times 6 = 24. ";
  document.getElementById("loopText").value = "We need the smallest n with n^2 - 1 divisible by 24. " + steps.join(" ") + " " + loop.repeat(40);
  runLoop();
});
function applyRule() {
  const lo = Number(document.getElementById("dLo").value), hi = Number(document.getElementById("dHi").value);
  const out = document.getElementById("ruleOut");
  if (!Number.isFinite(lo) || !Number.isFinite(hi) || lo > hi) { out.innerHTML = '<span class="bad">Enter a low bound no greater than the high bound.</span>'; return; }
  let v;
  if (lo > 2) v = '<span class="ok">Edit adds value.</span> A loop patch has a real gap to aim at; the Section 8 bar stands.';
  else if (hi < -2) v = '<span class="ok">Decoding dominates.</span> Turning thinking off beats the edit; a loop patch has nothing to add for a model served thinking-off.';
  else if (lo >= -2 && hi <= 2) v = '<span class="ok">Equivalent.</span> The gain is available with no weight change; no loop patch is justified by this benchmark.';
  else v = '<span class="warn">Inconclusive.</span> Run more samples per problem before deciding.';
  out.innerHTML = `Interval [${lo.toFixed(1)}, ${hi.toFixed(1)}] points: ` + v;
}
document.getElementById("ruleRun").addEventListener("click", applyRule);
document.getElementById("l1status").textContent = D.l1
  ? "Section 5 is measured; the rule below reproduces the report's verdict from its interval."
  : "Section 5's full measurement did not complete in this edition (compute billing stopped the run), so the report states no " +
    "number for it. The detector and the rule below are the instruments that measurement will use.";

drawMaps(); showGain(); patchCalc(); selfTest();
</script>
</body>
</html>
"""

if __name__ == "__main__":
    sys.exit(main())
