"""merge_pdf.py: join cover.pdf and body.pdf into the release PDF and set its metadata.

    python wp/merge_pdf.py <outDir> <output.pdf> <version>
"""
from __future__ import annotations

import os
import sys

from pypdf import PdfReader, PdfWriter


def main(out_dir: str, target: str, version: str) -> int:
    w = PdfWriter()
    for name in ("cover.pdf", "body.pdf"):
        p = os.path.join(out_dir, name)
        if not os.path.exists(p):
            print(f"missing {p}", file=sys.stderr)
            return 1
        for page in PdfReader(p).pages:
            w.add_page(page)
    w.add_metadata({
        "/Title": "Weight-Space Programming for THOX Edge Models: Evidence Review, Small-Scale Recreation, and a "
                  "Signed Patch Channel",
        "/Author": "Craig Ross and Tommy Xaypanya",
        "/Subject": f"THOX.ai Research technical report v{version}, internal edition",
        "/Keywords": "weight-space programming; model editing; decoding control; signed patch channel; THOX",
        "/Creator": "THOX.ai Research build (wp/build.py, wp/pdf.cjs)",
    })
    with open(target, "wb") as f:
        w.write(f)
    print(f"wrote {target} ({len(w.pages)} pages)")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(*sys.argv[1:]))
