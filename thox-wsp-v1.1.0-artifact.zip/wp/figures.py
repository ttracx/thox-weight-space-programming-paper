"""figures.py: every figure in THOX technical report v1.1.0, generated from the evidence files only.

    python wp/figures.py            (from the repository root; writes wp/fig/*.svg)

Inputs (all under exp/results/): source/exp8_*_merged.json (the source authors' released evaluation), carried_v1_0_0.json
(v1.0.0 THOX measurements, phrase-checked), e0r_patch_forms.json (E0-R and P1), l1_summary.json (Section 5; figures 6
and 7 are skipped with a notice when it is absent). SVG with live text (svg.fonttype none), Inter for text and
JetBrains Mono for numbers, THOX greens on white (#047C3D), no titles inside the plot (captions carry them).
"""
from __future__ import annotations

import json
import os
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "exp", "results")
OUT = os.path.join(ROOT, "wp", "fig")

GREEN = "#047C3D"
GREEN_LIGHT = "#7CC49B"
INK = "#09090B"
GREY = "#A1A1AA"
GREY_DARK = "#52525B"
RULE = "#D4D4D8"
AMBER = "#B45309"

plt.rcParams.update({
    "svg.fonttype": "none", "font.family": "Inter", "font.size": 9.5, "axes.edgecolor": RULE,
    "axes.labelcolor": INK, "xtick.color": GREY_DARK, "ytick.color": GREY_DARK, "axes.spines.top": False,
    "axes.spines.right": False, "axes.grid": True, "grid.color": "#F0F0F2", "grid.linewidth": 0.8,
    "axes.axisbelow": True, "legend.frameon": False, "legend.fontsize": 8.5, "figure.dpi": 100,
})
MONO = {"family": "JetBrains Mono"}


def load(name):
    p = os.path.join(RES, name)
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    fig.savefig(os.path.join(OUT, name), format="svg", bbox_inches="tight", pad_inches=0.06)
    plt.close(fig)
    print("wrote", name)


def label_bars(ax, bars, fmt, dy=1.0, color=INK, size=8):
    for b in bars:
        h = b.get_height()
        ax.text(b.get_x() + b.get_width() / 2, h + dy, fmt(h), ha="center", va="bottom", fontsize=size, color=color,
                fontdict=MONO)


def fig_source():
    base, edit = load("source/exp8_unedited_merged.json"), load("source/exp8_p50c_merged.json")
    order = [("math500", "MATH-500"), ("gsm8k", "GSM8K"), ("ifeval", "IFEval"), ("amc23", "AMC23"),
             ("minerva", "Minerva"), ("olympiad", "Olympiad"), ("gpqa", "GPQA-D"), ("mmlupro1k", "MMLU-Pro")]
    x = range(len(order))
    fig, ax = plt.subplots(figsize=(7.2, 2.7))
    w = 0.38
    b1 = ax.bar([i - w / 2 for i in x], [base[k]["acc"] * 100 for k, _ in order], w, color=GREY, label="Unedited")
    b2 = ax.bar([i + w / 2 for i in x], [edit[k]["acc"] * 100 for k, _ in order], w, color=GREEN,
                label="Edited, 50 passes")
    label_bars(ax, b1, lambda v: f"{v:.1f}", dy=0.8, color=GREY_DARK, size=7)
    label_bars(ax, b2, lambda v: f"{v:.1f}", dy=0.8, color=GREEN, size=7)
    ax.set_xticks(list(x), [n for _, n in order], fontsize=8.2)
    ax.set_ylabel("accuracy (%)")
    ax.set_ylim(0, 78)
    ax.legend(loc="upper left", ncol=2, bbox_to_anchor=(0, 1.14))
    save(fig, "fig1_source_exp8.svg")


def fig_e1():
    c = load("carried_v1_0_0.json")
    acc = c["E1"]["reader_acc"]["value"]
    names = [("R1", "R1 global\nmarginal"), ("R2", "R2 per-unit\nvoting"), ("R3", "R3 composed\nmap"),
             ("R4", "R4 composed\nper class")]
    fig, ax = plt.subplots(figsize=(5.6, 2.5))
    bars = ax.bar(range(4), [acc[k] for k, _ in names], 0.6, color=[GREY, GREY, GREY, GREEN])
    label_bars(ax, bars, lambda v: f"{v:.1f}%", dy=1.5)
    ax.axhline(c["E1"]["chance"]["value"], color=INK, lw=0.9, ls=(0, (4, 3)))
    ax.text(2.5, c["E1"]["chance"]["value"] + 3, "chance", ha="center", fontsize=8, color=INK)
    ax.set_xticks(range(4), [n for _, n in names])
    ax.set_ylabel("task identified (%, 30 nets)")
    ax.set_ylim(0, 112)
    save(fig, "fig2_e1_readers.svg")


def fig_e2():
    e = load("carried_v1_0_0.json")["E2"]
    fig, ax = plt.subplots(figsize=(5.6, 2.5))
    groups = ["Written\n(0 steps)", "Trained on oracle\n(1,200 steps)", "Random\n(mean of 20)"]
    std = [e["written_catch_standard"]["value"], e["written_catch_standard"]["value"], e["random_mean"]["value"]]
    hard = [e["written_catch_hard"]["value"], e["written_catch_hard"]["value"], None]
    w = 0.34
    b1 = ax.bar([i - w / 2 for i in range(3)], std, w, color=GREEN, label="standard regime")
    b2 = ax.bar([i + w / 2 for i in range(2)], [h for h in hard if h is not None], w, color=INK,
                label="hard regime (slower paddle, tighter window)")
    label_bars(ax, b1, lambda v: f"{v:.1f}%", dy=1.5)
    label_bars(ax, b2, lambda v: f"{v:.1f}%", dy=1.5)
    ax.set_xticks(range(3), groups)
    ax.set_ylabel("catch rate (%)")
    ax.set_ylim(0, 118)
    ax.legend(loc="upper left", ncol=2, bbox_to_anchor=(0, 1.16))
    save(fig, "fig3_e2_written.svg")


def fig_e3():
    c = load("carried_v1_0_0.json")
    sweep = {float(k): v for k, v in c["E3_gain_sweep_256"].items()}
    xs = sorted(sweep)
    fig, ax = plt.subplots(figsize=(5.6, 2.4))
    ax.plot(xs, [sweep[x] * 100 for x in xs], color=GREEN, lw=2, marker="o", ms=5, label="16-weight edit")
    ax.plot(xs, [0 for _ in xs], color=INK, lw=1.2, ls=(0, (4, 3)), marker="s", ms=3.5,
            label="random edit of equal size")
    for x in xs:
        ax.text(x - 0.03, sweep[x] * 100 + 6, f"{sweep[x] * 100:.1f}%", ha="right" if 0 < x < 2 else "center",
                fontsize=7.5, fontdict=MONO, color=GREEN)
    ax.set_xlabel("override gain (1.0 = shipped edit, 16 of 747 weights)")
    ax.set_ylabel("success (%, 256 ep.)")
    ax.set_ylim(-6, 118)
    ax.legend(loc="upper left", ncol=2, bbox_to_anchor=(0, 1.16))
    save(fig, "fig4_e3_dose.svg")


def fig_patch_forms():
    p = load("e0r_patch_forms.json")
    tot = lambda k: sum(t["sizes_bytes"][k] for t in p["tensors"])  # noqa: E731
    rows = [("Full edited tensors (bf16)", tot("full_tensor_bf16"), GREY),
            ("Sparse diff, raw (index + value)", tot("sparse_raw_idx4_val2"), GREY),
            ("Released edit.npz (compressed sparse)", p["release_edit_npz_bytes"], GREY),
            ("Factor + exactness residual (raw)", tot("factor_plus_residual_raw"), GREEN),
            ("Factor only, float32 u (not bit-exact)", tot("factor_u_f32_cols_i16_alpha_f64"), GREEN_LIGHT)]
    fig, ax = plt.subplots(figsize=(6.4, 2.4))
    y = range(len(rows))[::-1]
    ax.barh(list(y), [r[1] for r in rows], color=[r[2] for r in rows], height=0.6)
    ax.set_xscale("log")
    ax.set_yticks(list(y), [r[0] for r in rows])
    for yy, r in zip(y, rows):
        v = r[1]
        s = f"{v / 1e6:.2f} MB" if v >= 1e6 else f"{v / 1e3:.1f} KB"
        ax.text(v * 1.15, yy, s, va="center", fontsize=8, fontdict=MONO, color=INK)
    ax.set_xlim(1e3, 1e8)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v / 1e6:g} MB" if v >= 1e6 else f"{v / 1e3:g} KB"))
    ax.set_xlabel("bytes for both edited tensors (log scale)")
    ax.grid(axis="y", visible=False)
    save(fig, "fig5_patch_forms.svg")


L1_ORDER = [("base_on", "Base\nthinking on"), ("base_on+budget4096", "Base on\n+budget 4k"),
            ("base_on+interrupt", "Base on\n+interrupt"), ("base_off", "Base\nthinking off"),
            ("edit_on", "Edit\nthinking on"), ("edit_off", "Edit\nthinking off"),
            ("thoxedge_greedy", "ThoxEdge\ngreedy"), ("thoxedge_gated", "ThoxEdge\nserved")]


def _l1_get(s, key):
    if key in s["configs"]:
        return s["configs"][key]
    return s["defences"].get(key)


def fig_l1():
    s = load("l1_summary.json")
    if not s:
        print("l1_summary.json absent: figures 6 and 7 skipped")
        return
    items = [(k, n, _l1_get(s, k)) for k, n in L1_ORDER if _l1_get(s, k)]
    fig, ax = plt.subplots(figsize=(6.8, 2.8))
    x = range(len(items))
    accs = [it[2]["acc"] * 100 for it in items]
    ses = [it[2].get("acc_se", 0) * 100 for it in items]
    colors = [GREEN if k.startswith(("base_off", "base_on+", "thoxedge")) else (INK if k.startswith("edit") else GREY)
              for k, _, _ in items]
    bars = ax.bar(list(x), accs, 0.62, color=colors, yerr=[1.96 * e for e in ses], ecolor=GREY_DARK, capsize=2.5)
    for b, a, (k, _, d) in zip(bars, accs, items):
        cap = d.get("cap_share")
        ax.text(b.get_x() + b.get_width() / 2, a + 4.5, f"{a:.1f}", ha="center", fontsize=8, fontdict=MONO)
        if cap is not None:
            ax.text(b.get_x() + b.get_width() / 2, -9, f"cap {cap * 100:.0f}%", ha="center", fontsize=7,
                    color=AMBER, fontdict=MONO)
    ax.set_xticks(list(x), [n for _, n, _ in items], fontsize=7.6)
    ax.tick_params(axis="x", pad=14)
    ax.set_ylabel("MATH-500 accuracy (%)")
    ax.set_ylim(0, max(accs) + 16)
    save(fig, "fig6_l1_accuracy.svg")

    fig, ax = plt.subplots(figsize=(6.4, 2.9))
    for k, n, d in items:
        tpc = d["tokens_per_correct"]
        c = GREEN if k.startswith(("base_off", "base_on+", "thoxedge")) else (INK if k.startswith("edit") else GREY)
        ax.scatter(tpc, d["acc"] * 100, s=46, color=c, zorder=3)
        ax.annotate(n.replace("\n", " "), (tpc, d["acc"] * 100), xytext=(6, 3), textcoords="offset points",
                    fontsize=7.5, color=INK)
    ax.set_xscale("log")
    ax.set_xlabel("generated tokens per correct answer (log scale, lower is cheaper)")
    ax.set_ylabel("MATH-500 accuracy (%)")
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v / 1e3:g}k"))
    save(fig, "fig7_l1_cost.svg")


if __name__ == "__main__":
    os.chdir(ROOT)
    for f in (fig_source, fig_e1, fig_e2, fig_e3, fig_patch_forms, fig_l1):
        f()
    sys.exit(0)
