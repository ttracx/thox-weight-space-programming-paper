/**
 * katex_render.cjs: server-side KaTeX rendering for THOX technical reports.
 *
 * Usage: node wp/katex_render.cjs <in.json> <out.json>
 *   in.json  : {"eq1": {"tex": "...", "display": true}, ...}
 *   out.json : {"eq1": "<span class=\"katex-display\">...</span>", ..., "__css__": "<katex css with fonts inlined>"}
 *
 * Fonts referenced by katex.min.css are inlined as woff2 data URIs so the paper is one standalone file.
 * Any TeX error fails the build (throwOnError), so a broken equation can never ship silently.
 */
"use strict";
const fs = require("fs");
const path = require("path");

function main() {
  const [inPath, outPath] = process.argv.slice(2);
  if (!inPath || !outPath) {
    console.error("usage: node katex_render.cjs <in.json> <out.json>");
    process.exit(2);
  }
  const katexDir = path.join(__dirname, "node", "node_modules", "katex");
  const katex = require(path.join(katexDir, "dist", "katex.js"));
  const eqs = JSON.parse(fs.readFileSync(inPath, "utf8"));
  const out = {};
  for (const [id, spec] of Object.entries(eqs)) {
    try {
      out[id] = katex.renderToString(spec.tex, { displayMode: !!spec.display, throwOnError: true, output: "html" });
    } catch (err) {
      console.error(`KaTeX failed for ${id}: ${err.message}`);
      process.exit(1);
    }
  }
  let css = fs.readFileSync(path.join(katexDir, "dist", "katex.min.css"), "utf8");
  // inline only the woff2 sources; drop woff/ttf fallbacks to keep the file small
  css = css.replace(/src:([^;}]*)/g, (m, srcs) => {
    const w2 = srcs.match(/url\((fonts\/[^)]+\.woff2)\)\s*format\("woff2"\)/);
    if (!w2) return m;
    const data = fs.readFileSync(path.join(katexDir, "dist", w2[1])).toString("base64");
    return `src:url(data:font/woff2;base64,${data}) format("woff2")`;
  });
  out.__css__ = css;
  fs.writeFileSync(outPath, JSON.stringify(out));
  console.log(`rendered ${Object.keys(eqs).length} equations`);
}

main();
