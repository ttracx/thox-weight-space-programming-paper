/**
 * qa_pages.cjs: browser QA for the v1.1.0 paper HTML and demo page.
 * For each page, at 1280 and 390 px wide, in light and dark: no console errors, no horizontal scroll; screenshots.
 * For the demo: the loop self-test must report all vectors matching Python, and the main flows are clicked through.
 * Usage: node qa/qa_pages.cjs <outDir> <shotDir>
 */
"use strict";
const path = require("path");
const fs = require("fs");
const { chromium } = require("playwright");

async function main() {
  const [outDir, shotDir] = process.argv.slice(2);
  fs.mkdirSync(shotDir, { recursive: true });
  const browser = await chromium.launch();
  const results = [];
  let failures = 0;
  try {
    for (const file of ["paper.html", "weight-space-programming-demo.html"]) {
      for (const width of [1280, 390]) {
        for (const scheme of ["light", "dark"]) {
          const ctx = await browser.newContext({ viewport: { width, height: 900 }, colorScheme: scheme, deviceScaleFactor: 1 });
          const page = await ctx.newPage();
          const errors = [];
          page.on("pageerror", (e) => errors.push(String(e)));
          page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
          await page.goto("file://" + path.resolve(outDir, file), { waitUntil: "load" });
          await page.waitForTimeout(300);
          const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
          const r = { file, width, scheme, overflow, errors: errors.slice() };
          if (file.includes("demo")) {
            r.selfTest = await page.evaluate(() => window.__thoxSelfTest);
            await page.click("#reveal");
            r.reveal = (await page.textContent("#readOut")).slice(0, 60);
            await page.click("#loopEx");
            r.loop = (await page.textContent("#loopOut")).slice(0, 90);
            await page.fill("#dLo", "2.5"); await page.fill("#dHi", "6"); await page.click("#ruleRun");
            r.rule = (await page.textContent("#ruleOut")).slice(0, 70);
            await page.fill("#pRes", "0");
            r.patchRow = (await page.textContent("#patchTable tbody tr:nth-child(4)")).trim();
            await page.fill("#pRes", "12028");
            r.overflowAfter = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
            if (!r.selfTest || r.selfTest.pass !== r.selfTest.total) failures++;
          }
          await page.screenshot({ path: path.join(shotDir, `${file.replace(".html", "")}_${width}_${scheme}.png`), fullPage: false });
          if (overflow > 0 || (r.overflowAfter || 0) > 0 || errors.length) failures++;
          results.push(r);
          await ctx.close();
        }
      }
    }
  } finally {
    await browser.close();
  }
  console.log(JSON.stringify(results, null, 1));
  console.log(failures ? `QA FAILURES: ${failures}` : "QA PASS");
  process.exit(failures ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
