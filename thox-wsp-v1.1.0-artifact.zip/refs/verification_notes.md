# Reference verification notes

Accessed 2026-11-04. Every entry was checked against its live page (arXiv abs pages plus the arXiv API, Hugging Face API and raw READMEs, raw.githubusercontent.com and git clones, and the blog/article pages). Full records are in `verified_refs.json` (47 objects: 29 draft entries, 18 candidates; entries 3 and 4 are internal and were skipped). Result: 38 verified, 9 corrected, 0 not found, 0 left unreachable (the OpenAI page returned 403, so OpenAI's official RSS feed was used; see B5).

## Discrepancies in the current draft (Part A)

1. **Entry 1 (Takehi et al.)**: title, author order (Takehi, Teoh, Zhang, Khattab) and date (2026-11-02) are correct. "MIT CSAIL blog post" is not quite right. The post is on Rikiya Takehi's personal site (rikiyat.github.io). All four authors list MIT CSAIL as their affiliation, and the post's own BibTeX entry is `@misc`, note "Blog post". Takehi and Teoh are marked with asterisks.
2. **Entry 2 (Qwen3.5-0.8B)**: correct. The pinned revision is today's main, and the license is Apache-2.0. The thinking-loop warning is at README line 856. The recommended thinking-mode text preset is temperature 1.0, top_p 0.95, top_k 20, min_p 0, presence_penalty 1.5, repetition_penalty 1.0. Note for the report: the post's Experiment 8 sampling (temperature 0.6, presence penalty 1.5) is not that preset.
3. **Entry 5 (lm_understand-logs)**: the commit is current main. The README's license table names three licenses, not two: CC BY 4.0 (logs, data, networks), MIT (scripts) and GPL-3.0 (MinAtar source quoted in the Experiment 5 prompts). The repo title and About text use an older title for the post, "LLMs can understand and write neural network weights".
4. **Entry 6 (Honnibal)**: the title is wrong. The live title is "The 'Astra can read and write weights to improve Qwen' post is misleading" (no "massively"). The URL is https://honnibal.dev/blog/astra-read-write-misleading and the date 2026-11-03 is correct.
5. **Entry 8 (wspacetest)**: the repo exists under the user account adiant211 (no display name shown). It has no GitHub description. The default branch is a working branch (claude/zen-dijkstra-w7nc51) and every commit is authored "Claude", so cite a commit SHA. The README title is "Weight-space programming, checked on a CPU".
6. **Entry 9 (RikiyaT HF checkpoint)**: the card says it was built by "akhaliq" with ML Intern on HF Jobs on 2026-11-02. akhaliq's HF display name is **"AK"**. The name "Ahsen Khaliq" comes from the blog's acknowledgement, not from the HF profile.
7. **Entry 15**: the v3 date 2026-10-05 is confirmed. v1 is dated 2025-12-04, so state which year you use.
8. **Entry 16 (HyperNetworks)**: the abs page gives no venue. Use "arXiv preprint", not ICLR 2017.
9. **Entry 18 (Text-to-LoRA)**: the arXiv title is spelled "Instant Transformer **Adaption**". ICML 2025 is confirmed.
10. **Entry 21 (MEMIT)**: the abs page does not state ICLR 2023. Use "arXiv preprint".
11. **Entry 24 (Model soups)**: the full title is "Model soups: averaging weights of multiple fine-tuned models improves accuracy without increasing inference time" (ICML 2022, 11 authors).
12. **Entry 26 (TIES-Merging)**: the full title is "TIES-Merging: Resolving Interference When Merging Models" (NeurIPS 2023).
13. **No venue stated on the abs page, so recorded as arXiv preprint**: 11 (Arditi), 13, 14, 15, 17, 19, 22, 23, 29.
14. **Venues confirmed by abs-page Comments**: 12 ECAI 2020, 20 NeurIPS 2022, 25 ICLR 2023, 27 ICML 2024, 30 NeurIPS 2023 Spotlight, 31 ICLR 2024.
15. **Entry 28**: 25 authors as shown on the page. Published Dec 22, 2021.

## Candidate entries (Part B)

- **B1 OpenWSP**: the draft's calibration table is visible today in the README, in report.md and STATUS.md, and in the summary.json files:
  - base 7.2% (36/500)
  - released edit (p50c) 50.6% (253/500)
  - thinking off 46.8% (234/500), with 0.6% hitting the token cap

  Two caveats:
  - These runs used 1 sample per problem. The blog averaged 4 samples per problem.
  - The repo changes hourly (main is 2265473 at 14:59 UTC today), so pin a SHA.

  GitHub's HTML page, as fetched, showed a stale one-commit view. The git clone and raw files show the current README.
- **B2 Krentsel**: the X post exists (dated 2026-11-02 from its status ID). Its numbers are only in a chart image. OfficeChai (2026-11-03, "OfficeChai Team") gives these figures, against PPO 500M = 1x on Breakout:
  - GPT-5 to GPT-5.5: about 0
  - GPT-5.6 Sol: about 2-3x
  - GPT-6.1 Sol: 18x
  - GPT-6 Astra: 22x
  - Opus 4.5 to 4.8: about 0
  - Opus 5: just above 1x
  - Opus 5.5: 20x

  These are the article's readings of a chart. Attribute them that way.
- **B3 Kingy AI**: the author is Curtis Pyke. Published 2026-11-02, modified 2026-11-04. The draft title matches only the HTML `<title>`. The visible headline is "Weight-Space Programming: How GPT-6 Astra Raised Qwen's MATH-500 Score Sixfold".
- **B4 alphaXiv**: the page is reachable, and Joseph Noble's comment (2026-11-03) reports 10.9% unedited and 61.7% with the released edit. However, it says only "math eval" and **does not name MATH-500**, and it gives no sample count or sampling settings.
- **B5 OpenAI**: the page returned 403. OpenAI's RSS feed gives the title "GPT-6 Astra: A new generation of intelligence", dated 2026-09-03.
- **B6 to B13**: all match the draft. Venues stated on the abs pages: B6 ICML 2023, B7 NeurIPS 2023, B8 NeurIPS 2023 Spotlight, B10 ICLR 2020, B12 NeurIPS 2021, B13 SOSP 2023. B9 (s1) and B11 (Lightman) are arXiv preprints. The MATH-500 provenance for B11 is confirmed by the prm800k README and the HuggingFaceH4/MATH-500 dataset card.
- **B14**: huggingface/Math-Verify has no GitHub description, so use the README's first sentence. Apache-2.0. PyPI shows version 0.9.0.
- **B15 RFC 8032**: confirmed. S. Josefsson and I. Liusvaara, January 2017, IRTF Informational, DOI 10.17487/RFC8032.
- **B16 ThoxEdge-0.8B**:
  - base_model Qwen/Qwen3.5-0.8B; license Apache-2.0.
  - "enable_thinking" is not on the card. It appears only in the Modelfile comment (an empty-think prefill, which is enable_thinking=False).
  - The card says thinking mode is "out of contract" and that the build is served thinking-off at temperature 0 (greedy), with num_ctx 4096.
  - GATE49 is 46/49 on a development set. The card also states that the gate program's own verdict field reads FAIL and that a pre-registered improvement bar was applied instead.
- **B17 thox-micro-125m**:
  - The card says 123M parameters (safetensors: 123,587,328), although the name says 125m.
  - LlamaForCausalLM: 12 layers, hidden size 768, 12 heads with full MHA, FFN 2048, vocab 50,304, context 1024, tied embeddings.
  - License Apache-2.0.
