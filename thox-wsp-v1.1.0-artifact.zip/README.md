# THOX Weight-Space Programming: technical report v1.1.0 artifact bundle

![License](https://img.shields.io/badge/License-Internal-05A451) ![Edition](https://img.shields.io/badge/Edition-v1.1.0-05A451) ![THOX](https://img.shields.io/badge/THOX.ai-Research-05A451) ![CI](https://img.shields.io/badge/CI-local%20checks-05A451)

Reproducibility bundle for *Weight-Space Programming for THOX Edge Models: Evidence Review, Small-Scale Recreation,
and a Signed Patch Channel*, v1.1.0 (internal edition, 2026-11-04), issued by THOX.ai Research. Supersedes v1.0.0.

## Layout

| Path | Contents |
|---|---|
| `Weight-Space-Programming-for-THOX-Edge-Models_v1.1.0.pdf`, `.html` | The report (PDF for print, HTML with light and dark themes) |
| `weight-space-programming-demo_v1.1.0.html` | Companion demo, one file, no network calls |
| `exp/lib/` | Loop metric (`wsp_loop.py`) and its unit tests |
| `exp/jobs/` | L1 GPU job (`l1_eval_main.py`, assembled `l1_eval.py`), builder, launch notes |
| `exp/*.py` | E0-R and P1 (`e0r_patch_forms.py`), A0 (`a0_source_paired.py`), carry step (`carry_v1_0_0.py`), L1 analysis (`analyze_l1.py`) |
| `exp/results/` | Evidence files every number in the report is read from |
| `wp/` | Figures, paper build, KaTeX renderer, PDF printer, demo builder |
| `refs/` | Live reference verification (`verified_refs.json`, `verification_notes.md`) |
| `qa/` | Browser QA script and screenshots |
| `docs/` | Handoff, decision log, validation report, development queue, ecosystem map |

## Quick start

```bash
cd exp/lib && python -m unittest -v test_wsp_loop.py && cd ../..
python -I exp/e0r_patch_forms.py <lm_understand-logs>/exp8_math/runs/p50c/edit exp/results
python -I exp/a0_source_paired.py <lm_understand-logs>/exp8_math/eval exp/results
python wp/figures.py && python wp/build.py
node wp/pdf.cjs wp/out 1.1.0 2026-11-04 && python wp/merge_pdf.py wp/out report.pdf 1.1.0
python wp/demo_build.py && node qa/qa_pages.cjs wp/out qa/shots
```

`wp/` expects `wp/node/node_modules` with `katex@0.16`, `@fontsource/inter@5` and `@fontsource/jetbrains-mono@5`, and
Playwright with Chromium. `<lm_understand-logs>` is a checkout of RikiyaT/lm_understand-logs at commit 4d09ba6.

## Status

Section 5 (the decoding control) is specified, built and tested but not measured: the GPU run was stopped by Hugging
Face billing. See `exp/jobs/README_L1.md` and `docs/HANDOFF_WSP_v1.1.0.md`.

## Licence and notices

Internal THOX.ai LLC material. Third-party content keeps its own licence: the source logs are CC BY 4.0 (data) and MIT
(scripts), with GPL-3.0 MinAtar source quoted only in the source prompts, which this bundle does not include; the
grading functions vendored in `exp/jobs/l1_eval_main.py` come from the MIT-licensed `mathqa.py`; Qwen3.5-0.8B and the
edited checkpoint are Apache-2.0.

Your AI. Your Data. Your Rules.&trade;
