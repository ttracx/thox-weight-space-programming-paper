# ecosystem_map.md: Weight-Space Programming in the THOX stack

```mermaid
flowchart LR
  subgraph Research["THOX.ai Research (this bundle)"]
    E0R["E0-R / P1\nverify + patch forms"]
    L1["L1 decoding control\n(HF Jobs, vLLM)"]
    A0["A0 source per-problem analysis"]
    Paper["Technical report v1.1.0\n+ demo"]
  end
  subgraph Work["ThoxWork"]
    Bench["Patch workbench\nread / diagnose / edit / review / sign"]
  end
  subgraph Mesh["MeshStack"]
    Reg["Patch registry\nsignatures, staged rollout, receipts"]
  end
  subgraph OS["ThoxOS + ThoxMind"]
    Loader["Rust loader\nverify, A/B apply, result hashes, rollback"]
    Harness["Serving harness\nloop interrupt, thinking budget"]
  end
  subgraph Models["Device models"]
    Edge["ThoxEdge-0.8B\n(Qwen3.5-0.8B base)"]
    Micro["thox-micro-125m"]
  end
  E0R --> Paper
  L1 --> Paper
  A0 --> Paper
  Paper -->|gates, Section 8| Bench
  Bench -->|signed manifest| Reg
  Reg -->|kilobyte patches| Loader
  Loader --> Edge
  Loader --> Micro
  L1 -->|baselines| Harness
  Harness --> Edge
```

| Boundary | Upstream | Downstream | Data crossing it |
|---|---|---|---|
| Research to ThoxWork | Source post, released logs, HF Jobs results | Patch workbench | Gate definitions, baselines, decision rule |
| ThoxWork to MeshStack | Editor sessions | Registry | Signed manifest (Ed25519), result hashes, eval report hash |
| MeshStack to ThoxOS | Registry | Rust loader | Factor ops + sparse residual, base pins |
| ThoxOS serving | Loop metric (`exp/lib/wsp_loop.py`) | ThoxEdge, micro models | Decoding defences, no weights changed |
