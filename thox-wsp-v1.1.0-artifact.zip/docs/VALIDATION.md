# Validation report: Weight-Space Programming technical report v1.1.0

Host for everything below except L1: Claude cloud workspace (Linux, 2 vCPU), 2026-11-04.

| Check | Command | Result |
|---|---|---|
| Loop metric unit tests | `cd exp/lib && python -m unittest -v test_wsp_loop.py` | 9/9 pass |
| L1 job script local smoke test (grading, prompts for all four tokenizers, token mapping, system prompt) | see `exp/jobs/README_L1.md` | pass |
| L1 analysis script on synthetic data in the output format | `python exp/analyze_l1.py <synthetic root> <out>` | pass |
| Job script integrity on the dataset | sha256 check at job start | `d33279484d2f...` matched in every launched job |
| L1 GPU run | 4 jobs on HF Jobs | **not completed**: stopped about 15:20 UTC; relaunch refused with HTTP 402 |
| E0-R: hashes, rebuild, rank | `python -I exp/e0r_patch_forms.py <logs>/exp8_math/runs/p50c/edit exp/results` | pass: 130,188 entries; both base and edited SHA-256 match the manifest; rebuild bit-identical; sigma ratios 1,771 and 1,552 |
| P1: factor-form exactness | same script | factor alone reproduces 91.0% and 90.5% of changed entries; 12,028 residual entries; exact patch 80.6 KB |
| A0: authors' per-problem files | `python -I exp/a0_source_paired.py <logs>/exp8_math/eval exp/results` | 7.9% and 48.1% reproduced; paired gain +40.2 points (95% CI 36.8 to 43.5); 306 problems better, 0 worse |
| Carried v1.0.0 numbers | `python -I exp/carry_v1_0_0.py ref/v1.0.0.txt demo_v1.0.0.html exp/results/carried_v1_0_0.json` | 38 values; every phrase found in the v1.0.0 text; demo data consistent with the PDF |
| References | live verification of 47 entries | 38 verified, 9 corrected, 0 not found; OpenAI page returned 403, title and date taken from OpenAI's RSS feed |
| Paper build | `python wp/figures.py && python wp/build.py` | pass: 50 references, 5 figures, 9 tables, 24 equations; no em dashes or placeholders |
| PDF | `node wp/pdf.cjs wp/out 1.1.0 2026-11-04 && python wp/merge_pdf.py ...` | 21 pages, US Letter; every page inspected |
| Browser QA | `node qa/qa_pages.cjs wp/out qa/shots` | pass: no console errors and no horizontal scroll at 1280 and 390 px, light and dark; demo self-test 6/6 |

## Claim limits

- No Section 5 number is stated. The only figure for the decisive comparison is third-party (OpenWSP, one sample per problem).
- E1 to E4 were not re-run for this edition.
- Nothing here is a device measurement; no GGUF or quantised artifact was evaluated.
