# Development queue: Weight-Space Programming program

Priority = (Market Value x 0.4) + (Technical Feasibility x 0.3) + (Time-to-Market x 0.2) + (Strategic Importance x 0.1)

| Rank | Item | MV | TF | TTM | SI | Priority | Owner lane |
|---|---|---|---|---|---|---|---|
| 1 | Restore HF billing, relaunch L1, rebuild as v1.1.1 with Section 5 measured | 8 | 10 | 9 | 9 | 8.9 | Tommy (billing), Claude |
| 2 | Ship streaming loop interrupt and thinking budget in the ThoxMind serving harness | 8 | 9 | 8 | 8 | 8.3 | Codex |
| 3 | Sparse-residual operation in the Rust patch loader (thox-wsp v0.2.0) | 6 | 9 | 8 | 8 | 7.5 | Codex |
| 4 | Push bundle to a THOX-REPO-001 repository; Developers preview at /docs/weight-space-programming | 5 | 9 | 9 | 7 | 7.2 | Hermes, Julian Hale |
| 5 | Loop baselines for every device-target model under its served decoding | 6 | 8 | 6 | 7 | 6.7 | Claude |
| 6 | Merge v1.0.0 E1 to E4 bundle into the repository; re-run on a second host | 4 | 9 | 8 | 7 | 6.6 | Codex |
| 7 | E2' frontier-editor write test on one THOX routing or control task | 6 | 6 | 6 | 8 | 6.2 | Claude |
| 8 | E5 quantisation test of the released edit (Q8_0, Q4_0) | 5 | 7 | 5 | 6 | 5.7 | Codex |

Recommendation: rank 1 first; the whole measured Section 5 depends on it and the pipeline is ready.
