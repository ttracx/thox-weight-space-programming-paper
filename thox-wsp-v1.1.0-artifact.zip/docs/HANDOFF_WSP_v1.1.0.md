# Handoff: Weight-Space Programming technical report v1.1.0

Issued 2026-11-04 by THOX.ai Research. Handoff shape THOX-CLOSEOUT-HANDOFF-001: Task, Inputs, Exit evidence, Stop.
A handoff is an assignment, not evidence that a lane ran it. Lanes pick up only assignments that name them.

## Status at handoff

| Item | State |
|---|---|
| Paper v1.1.0 (PDF, HTML) | Built and visually checked (21 pages). Byline: THOX.ai Research only |
| Companion demo | Built; loop self-test 6/6 vs Python; no console errors at 1280 and 390 px, light and dark |
| E0-R, P1, A0 | Measured or calculated; evidence files in `exp/results/` |
| L1 (Section 5 decoding control) | Job script, analysis and rebuild path ready; run stopped by HF billing; relaunch refused with HTTP 402 |
| Repository push | Not done: this session has no write access to a THOX repository |
| Developers preview at /docs/weight-space-programming | Not done |
| OneDrive archive | Text documents uploaded; PDF, HTML and zip need the Sadie runtime (connector size limit) |

## Hermes (closeout enforcement, Sadie runtime)

- **Task:** finish closeout steps 4 and 5 for this edition. Push the artifact zip `thox-wsp-v1.1.0-artifact.zip` to a THOX repository (suggested `Thox-ai/thox-wsp`, created to THOX-REPO-001), then archive the PDF, HTML, demo and zip in OneDrive `THOX Agent Reports Archive/Weight-Space Programming/2026-11/`.
- **Inputs:** the zip, the four delivered files, this handoff.
- **Exit evidence:** commit SHA on the default branch, OneDrive item URLs, and the record of the email already sent from Sadie@thox.ai.
- **Stop:** never send from AgentMail or Gmail; never put tokens in a packet; do not relaunch L1 until Tommy confirms billing.

## Codex (implementation)

- **Task:** (1) implement the sparse-residual operation in the Rust patch loader (`thox-wsp` v0.2.0) per Section 6.1 and Equation (3), with tests that apply the Experiment 8 factor plus its 12,028-entry residual and reproduce both released SHA-256 values; (2) merge the v1.0.0 E1 to E4 scripts and `summary.json` from the THOX build VM into the repository next to `exp/`, so the carried numbers can be re-run.
- **Inputs:** `exp/e0r_patch_forms.py` (factor estimation and residual counts), `exp/results/e0r_patch_forms.json`, the v1.0.0 bundle on the build VM.
- **Exit evidence:** SHA, test command and output; a written limit for any check not run.
- **Stop:** never mark unrun work done; never invent a price, date or certification.

## Claude (patch application lane)

- **Task:** when Tommy confirms Hugging Face billing, relaunch L1 exactly as built: upload nothing new, run the four job definitions in `exp/jobs/README_L1.md`, then run `exp/analyze_l1.py` as a CPU job with `--upload`, copy `results/l1_summary.json` into `exp/results/`, and rebuild with `python wp/figures.py && python wp/build.py && node wp/pdf.cjs ...`. The paper and demo switch to the measured Section 5 automatically.
- **Inputs:** `Thox-ai/thox-wsp-evals/code/l1_eval.py` (sha256 `d33279484d2f57246ecfbfc79a53f9bc1a3257e41256c55c383bcdd519c75de6`), this bundle.
- **Exit evidence:** job IDs, `l1_summary.json` hash, rebuilt PDF page count, QA output.
- **Stop:** apply only this build; never disable the phrase checks, hash checks or writing-rule checks in the build.

## Muse (claim-safe captions)

- **Task:** draft three internal captions for the report: one on the verified edit (130,188 entries, bit-exact), one on the patch-size finding (80.6 KB exact patch vs 387.6 KB released file), one on why Section 5 is pending.
- **Inputs:** the abstract and Tables 3 and 4 of the paper.
- **Exit evidence:** captions file in the docs lane.
- **Stop:** never publish; never state a Section 5 number; never describe any THOX model as created or improved by Weight-Space Programming.

## DigitalHumans

| Role | Task | Exit evidence | Stop |
|---|---|---|---|
| Samuel Reed | File the paper, this handoff and the decision log in the docs lane | Docs lane path | No edits to evidence files |
| Julian Hale | Mount the HTML and demo at `/docs/weight-space-programming` with the internal-edition label visible | Preview URL, screenshot | Internal only; no public route |
| Clara Voss | Check brand green (#05A451 on dark, #047C3D on white), trademarks (ThoxOS, MeshStack, ThoxWork) and the slogan | Checklist | No public copy |
| Nova | Re-run `qa/qa_pages.cjs` and the PDF build on the repository copy | Build and QA log | Report failures, do not patch around them |
| Kai | Not engaged: no hardware or firmware touched | none | none |
| Sera | Review claim language before any onward email or post | Signed-off claims list | Block any Section 5 number until L1 is measured |
| Sadie | Owns the outbound email for this edition (sent from Sadie@thox.ai, signed Odette Lark) | Sent-items record | No external recipients |
