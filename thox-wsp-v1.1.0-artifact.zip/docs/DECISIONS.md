# Decision log: Weight-Space Programming technical report v1.1.0

| # | Date (CT) | Decision | Basis | Reversible |
|---|---|---|---|---|
| D1 | 2026-11-04 08:55 | Ship v1.1.0 as a revision of v1.0.0, keeping its title and section structure | Tommy: "Review then update your paper and etc" | Yes |
| D2 | 2026-11-04 09:22 | Byline is THOX.ai Research only; Craig Ross and Tommy Xaypanya removed as authors; no AI listed as an author; one AI-assistance note kept in document control | Tommy: "Remove you as authors and regenerate". Read as removing the named authors, because v1.0.0 lists no AI author. If he meant only the AI credit, restore both names in `wp/build.py` (cover byline and Table 8) | Yes, one line |
| D3 | 2026-11-04 | Carry E1 to E4 and patch-channel results from v1.0.0 with phrase checks instead of re-running them | v1.0.0 bundle not available in this session; re-implementation would drift | Yes, once the bundle is merged |
| D4 | 2026-11-04 | Run the decoding control (L1) on Hugging Face Jobs: H200 for thinking-on, A100 for the rest, vLLM 0.33.0, math-verify 0.9.0, source grading vendored | Section 5 was the open control; Autonomous Ship Mode covers testing decisions | Yes |
| D5 | 2026-11-04 | Defences applied to recorded generations (budget 4,096 and 8,192; loop interrupt with rewind) | Causality makes the prefix exact; saves most of the GPU cost | Yes |
| D6 | 2026-11-04 | Pre-register the Section 5 decision rule before any data (edit adds value if the 95% interval low bound exceeds +2 points; decoding dominates below -2; equivalent inside +/-2; otherwise inconclusive) | Prevents reading the result after the fact | No, by design |
| D7 | 2026-11-04 09:30 | Did not relaunch after the first cancellation until asked | Cancellation source unknown at the time; avoided overriding a possible human action | n/a |
| D8 | 2026-11-04 09:33 | Relaunch attempted on Tommy's "Relaunch"; refused with HTTP 402 for GPU and CPU, user and Thox-ai namespaces | Billing, not the jobs | Relaunch after billing is fixed |
| D9 | 2026-11-04 | Publish v1.1.0 with Section 5 marked not measured rather than wait | Ten-second rule; the build regenerates Section 5 automatically when `l1_summary.json` exists | Yes |
| D10 | 2026-11-04 | Correct v1.0.0 patch sizing: factor form uses a float32 direction; exact patches carry a sparse residual (80.6 KB for Experiment 8) | P1 measurement | n/a |
